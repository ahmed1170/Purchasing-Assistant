import json
import pytest
from unittest.mock import patch

from fastapi.testclient import TestClient

from live_test import example_pdf
from purchasing import Criterion, Evidence, Fact, Offer, Offers, OrderPosition, Position, Scope, evaluate, recommendation
from server import create_app
from test_agent import scenario,position


WEIGHTS = {"total_price":80,"distance_km":20}


def test_generic_pdf_records_keep_technical_candidates_without_price():
    from catalog import technical_pdf_candidates
    pos, sources = case(False, "500")
    pos.name = "Gummidichtungen EPDM"
    pos.must = [Criterion(field="Dicke", operator="eq", target="3", unit="mm",
                          evidence=Evidence(source_id="Q1", quote="Dicke 3 mm"))]
    sources["Q1"]["text"] += " Dicke 3 mm."
    pages = [
        {"id": "Q2", "kind": "pdf", "title": "dichtung-tabelle.pdf", "path": "tabelle.pdf", "page": 1,
         "text": "Polywerk Gummidichtungen\nArtikelnummer | Dicke | Werkstoff\nG301 | 3 mm | EPDM\nG501 | 5 mm | NBR"},
        {"id": "Q3", "kind": "pdf", "title": "dichtung-stammdaten.pdf", "path": "stammdaten.pdf", "page": 1,
         "text": "Gummidichtung\nArtikelnummer: DS3\nStammdaten\nArtikelnummer\nHersteller\nDicke\nWerkstoff\nDS3\nDichtungstechnik\n3 mm\nEPDM"},
        {"id": "Q4", "kind": "pdf", "title": "anderes-produkt.pdf", "path": "anderes.pdf", "page": 1,
         "text": "Metallplatten\nArtikelnummer | Dicke | Werkstoff\nP301 | 3 mm | Stahl"},
    ]
    audit = {}
    offers, details = technical_pdf_candidates(pos, pages, audit)
    assert {(offer.supplier, offer.product) for offer in offers} == {("Polywerk", "G301"), ("Dichtungstechnik", "DS3")}
    sources.update({page["id"]: page for page in pages})
    rows = evaluate(pos, offers, sources, [], WEIGHTS, details)
    assert len(rows) == 2 and all(row["technical_status"] == "passend" for row in rows)
    assert all(row["listed_price"] is None and row["must"][0]["fact"]["evidence"]["source_id"] in {"Q2", "Q3"}
               for row in rows)
    assert len(audit) == 2


def test_short_thread_code_requires_an_exact_demand_quote():
    from purchasing import criterion_usable
    criterion = Criterion(field="Gewindegröße", operator="eq", target="M8", unit="",
                          evidence=Evidence(source_id="Q1", quote="M8"))
    assert criterion_usable(criterion, {"Q1": {"kind": "input", "text": "Gewinde M8."}})
    assert not criterion_usable(criterion, {"Q1": {"kind": "input", "text": "Gewinde M80."}})


def test_pdf_price_column_keeps_variant_tax_basis_and_printed_address():
    from catalog import technical_pdf_candidates
    pos, sources = case(False, "500")
    pos.name = "Reduziermuffen"
    pos.must = [Criterion(field="Anschlussdurchmesser", operator="eq", target="25", unit="mm",
                          evidence=Evidence(source_id="Q1", quote="Anschlussdurchmesser 25 mm"))]
    sources["Q1"]["text"] += " Anschlussdurchmesser 25 mm."
    page = {"id": "Q2", "kind": "pdf", "title": "sortiment.pdf", "path": "muffen.pdf", "page": 2,
            "text": "Reduziermuffe | Sortiment\nArtikel-Nr. | Variante | Preis je 100 Stück\n"
                    "RA025 | 25mm | 8,10 €\nRA032 | 32mm | 12,00 €\n"
                    "Alle Preise netto exkl. MwSt.\nMusterwerk GmbH - Hafenweg 17 - 20095 Hamburg - Tel.: 123"}
    offers, details = technical_pdf_candidates(pos, [page], {})
    assert [offer.product for offer in offers] == ["RA025"]
    [row] = evaluate(pos, offers, sources | {"Q2": page}, [], WEIGHTS, details)
    assert row["technical_status"] == "passend"
    assert row["listed_price"]["price_basis"] == "100 Stück"
    assert row["listed_price"]["goods_value"] == 40.50
    assert row["listed_price"]["tax"] == "netto"
    assert any(fact.field == "company_address" and "Hamburg" in fact.value for fact in offers[0].facts)


def test_technical_type_codes_allow_separator_variants_but_not_a_different_series():
    from purchasing import compare
    criterion = Criterion(field="Produkttyp", operator="eq", target="XYZ-3 6/2", unit="",
                          evidence=Evidence(source_id="Q1", quote="XYZ-3 6/2"))
    correct = Fact(field="Produkttyp", value="XYZ-3-6/2", unit="",
                   evidence=Evidence(source_id="Q2", quote="XYZ-3-6/2"))
    wrong = correct.model_copy(update={"value": "XYZ-A-6/2"})
    assert compare(criterion, correct) is True and compare(criterion, wrong) is False


@pytest.mark.parametrize("table", [
    'FIL025 | Innengewinde | 8,10\n1 Zoll | VZ-30 | €*\nFIL032 | Außengewinde | 9,25 €',
    '1 Zoll | VZ-30 | 8,10\nFIL025 | Innengewinde | €*\nFIL032 | Außengewinde | 9,25 €',
])
def test_wrapped_price_and_explicit_sku_stay_with_the_same_pdf_article(table):
    from catalog import technical_pdf_candidates
    pos, sources = case(False, "10")
    pos.name = "Druckfilter"
    pos.must = [Criterion(field="Artikelnummer", operator="eq", target="FIL025", unit="",
                          evidence=Evidence(source_id="Q1", quote="Artikel FIL025"))]
    sources["Q1"]["text"] += " Artikel FIL025."
    page = {"id": "Q2", "kind": "pdf", "title": "filter.pdf", "path": "filter.pdf", "page": 1,
            "text": "Druckfilter\nArtikel-Nr. | Variante | Preis\n" + table + "\nAlle Preise netto exkl. MwSt."}
    offers, details = technical_pdf_candidates(pos, [page], {})
    assert [offer.product for offer in offers] == ["FIL025"]
    [row] = evaluate(pos, offers, sources | {"Q2": page}, [], WEIGHTS, details)
    assert row["technical_status"] == "passend"
    assert row["listed_price"]["value"] == 8.10 and row["listed_price"]["tax"] == "netto"
    assert row["listed_price"].get("goods_value") is None
    assert "\n" in row["listed_price"]["evidence"]["quote"]


def test_catalog_thread_type_does_not_override_proven_nominal_size():
    from catalog import technical_pdf_candidates
    pos, sources = case(False, "10")
    pos.name = "Druckfilter"
    pos.must = [Criterion(field="Gewindegröße", operator="eq", target="1", unit="Zoll",
                          evidence=Evidence(source_id="Q1", quote="1 Zoll"))]
    sources["Q1"]["text"] += " 1 Zoll."
    page = {"id": "Q2", "kind": "pdf", "title": "filter.pdf", "path": "filter.pdf", "page": 1,
            "text": 'Druckfilter\nArtikel-Nr. | Variante | Preis\nFIL025 | 1" Außengewinde | 8,10 €'}
    offers, details = technical_pdf_candidates(pos, [page], {})
    [row] = evaluate(pos, offers, sources | {"Q2": page}, [], WEIGHTS, details)
    assert row["technical_status"] == "passend"
    assert row["must"][0]["fact"]["field"] == "Gewindegröße"


@pytest.mark.parametrize("quantity, expected, expected_order", [
    ("1.000", 16.40, 10),
    ("501", 10.80, 6),
    ("100", 2.48, 1),
])
def test_pdf_quantity_tiers_follow_the_actual_order_quantity(quantity, expected, expected_order):
    from catalog import technical_pdf_candidates
    from workflow import position_questions
    pos, sources = case(False, quantity)
    pos.name = "Verzinkte Sechskantmuttern M8"
    pos.quantity_unit = ""
    pos.scope_evidence = Evidence(source_id="Q1", quote=quantity)
    sources["Q1"]["text"] = f"Ich benötige {quantity} verzinkte Sechskantmuttern M8 zur Lieferung nach Stuttgart."
    questions = position_questions(pos, sources, WEIGHTS, technical_questions=False)
    assert pos.quantity_unit == "Sechskantmuttern"
    assert not any("Mengeneinheit" in question for question in questions)
    page = {"id": "Q2", "kind": "pdf", "title": "Preisblatt.pdf", "path": "blatt.pdf", "page": 1,
            "text": "Sechskantmutter M8\nAnbieter: Musterhandel\nArtikelnummer: M8-100\n"
                    "Preise inkl. 20 % USt., zzgl. Versand.\nMindestmenge (Lose) | Preis in EUR je Los à 100 Stück\n"
                    "1 | 2,48 EUR\n5 | 1,80 EUR\n10 | 1,64 EUR"}
    offers, details = technical_pdf_candidates(pos, [page], {})
    [row] = evaluate(pos, offers, sources | {"Q2": page}, [], WEIGHTS, details)
    price = row["listed_price"]
    assert row["supplier"] == "Musterhandel"
    assert price["goods_value"] == expected and price["order_quantity"] == expected_order
    assert price["tax"] == "brutto" and price["pack_size"] == 100
    assert row["metrics"]["gross_goods_price"]["value"] == expected


def test_variant_table_disqualifies_malformed_title_with_wrong_dimensions():
    p,sources = case(False)
    demand = "Bedarf 4 × 40 mm."
    sources["Q1"]["text"] += " " + demand
    p.must = [Criterion(field="Abmessungen",operator="eq",target="4 × 40",unit="mm",
                        evidence=Evidence(source_id="Q1",quote=demand))]
    offer = candidate(sources,"Werk A","10")
    sid = offer.identity.source_id
    quote = "Durchmesser: 5 mm, Gesamtlänge: 35 mm."
    sources[sid]["text"] += " " + quote
    offer.facts.append(Fact(field="Durchmesser",value="5",unit="mm",evidence=Evidence(source_id=sid,quote=quote)))
    row = evaluate(p,[offer],sources,[],WEIGHTS)[0]
    assert row["status"] == "abweichend"
    assert row["score"] is None and "criterion_points" not in row


def test_screw_title_checks_separately_requested_axes_and_does_not_infer_unshown_length():
    p,sources = case(False,"1000")
    p.name = "Spanplattenschrauben"
    sources["Q1"]["text"] = "Durchmesser 3,5 mm. Länge 4 cm."
    p.must = [Criterion(field=field,operator="eq",target=value,unit=unit,
                        evidence=Evidence(source_id="Q1",quote=f"{value} {unit}"))
              for field,value,unit in (("Schraubendurchmesser","3,5","mm"),("Schraubenlänge","4","cm"))]
    offers = []
    for i,title in enumerate(("Spanplattenschraube 5x60 mm", "Spanplattenschraube 3.5 × 40mm",
                              "Spanplattenschraube Ø 3,5 mm"),2):
        supplier, sid = f"Werk {i}",f"Q{i}"
        identity = f"{supplier} {title}."
        route = "Straßenentfernung nach Berlin: 356,25 km."
        sources[sid] = {"kind":"pdf","text":identity+" "+route}
        offers.append(Offer(supplier=supplier,product=title,identity=Evidence(source_id=sid,quote=identity),
                      facts=[Fact(field="distance_km",value="356,25",unit="km",evidence=Evidence(source_id=sid,quote=route))]))
    rows = {row["supplier"]:row for row in evaluate(p,offers,sources,[],WEIGHTS)}
    assert rows["Werk 2"]["status"] == "abweichend"
    assert [check["result"] for check in rows["Werk 2"]["must"]] == [False,False]
    assert rows["Werk 2"]["partial_score"] is None
    assert [check["result"] for check in rows["Werk 3"]["must"]] == [True,True]
    assert rows["Werk 3"]["partial_score"]["value"] == 14.43
    assert rows["Werk 3"]["partial_score"]["basis"] == {"distance_km":20}
    assert rows["Werk 4"]["must"][1]["result"] is None


def test_search_does_not_split_decimal_dimensions():
    from workflow import public_terms
    assert public_terms("Schrauben 3,5×40 mm") == "Schrauben 3.5x40 mm"


def test_pack_price_is_visible_with_open_tax_and_scored_when_comparable():
    from price_diagnostics import diagnose_prices
    p,sources = case(False,"1000")
    first = candidate(sources,"Werk A","12")
    second = candidate(sources,"Werk B","15")
    for offer,amount,km in ((first,"12","80"),(second,"15","40")):
        sid = offer.identity.source_id
        quote = f"{offer.product}: {amount} EUR brutto je 100 Stück. Packungsgröße 100 Stück."
        distance = f"Straßenentfernung nach Berlin: {km} km."
        sources[sid]["text"] += " " + quote + " " + distance
        offer.facts = [Fact(field="listed_price",value=amount,unit="EUR",evidence=Evidence(source_id=sid,quote=quote)),
                       Fact(field="distance_km",value=km,unit="km",evidence=Evidence(source_id=sid,quote=distance))]
    rows = evaluate(p,[first,second],sources,[],WEIGHTS)
    assert rows[0]["listed_price"]["order_quantity"] == 10
    assert rows[0]["metrics"]["gross_goods_price"]["value"] == 120
    assert rows[0]["score"] == 88.35
    assert rows[0]["criterion_points"]["price"]["points"] == 72
    assert rows[0]["criterion_points"]["distance"]["points"] == 16.35
    assert rows[1]["score"] == 74.27
    first.facts[0].evidence.quote = first.facts[0].evidence.quote.replace("brutto ","")
    sid = first.identity.source_id
    sources[sid]["text"] = sources[sid]["text"].replace("brutto ","")
    rows = evaluate(p,[first],sources,[],WEIGHTS)
    diagnose_prices(rows,[dict(id=key,**value) for key,value in sources.items()])
    assert rows[0]["listed_price"]["goods_value"] == 120
    assert "price" not in rows[0]["criterion_points"]
    assert "netto oder brutto" in rows[0]["reasons"]["material_price"]


def test_tax_is_taken_from_the_matching_price_only():
    p,sources = case(False,"100")
    offer = candidate(sources,"Werk A","10")
    sid = offer.identity.source_id
    dual_price = f"{offer.product}: 11,90 EUR 10,00 EUR exkl. MwSt. je 100 Stück."
    sources[sid]["text"] += " " + dual_price
    offer.facts = [
        Fact(field="listed_price",value="11,90",unit="EUR",evidence=Evidence(source_id=sid,quote=dual_price)),
        Fact(field="price_quantity",value="100",unit="Stück",evidence=Evidence(source_id=sid,quote=dual_price)),
    ]
    row = evaluate(p,[offer],sources,[],WEIGHTS)[0]
    assert row["listed_price"]["tax"] == "offen"
    assert row["listed_price"]["goods_value"] == 11.90
    gross = f"{offer.product}: 11,90 EUR inkl. 19% USt. je 100 Stück."
    sources[sid]["text"] += " " + gross
    offer.facts[0].evidence.quote = gross
    assert evaluate(p,[offer],sources,[],WEIGHTS)[0]["metrics"]["gross_goods_price"]["value"] == 11.90


def test_unlabelled_dimensions_accept_a_reversed_pair_but_named_axes_do_not():
    from purchasing import compare, select_facts
    proof = Evidence(source_id="Q1",quote="Kabelbinder 4,8 x 200 mm; Maß 4,8x200 mm.")
    facts = [Fact(field="Abmessungen",value=value,unit="mm",evidence=proof)
             for value in ("4,8 x 200","4,8x200 mm")]
    selected = select_facts(facts,{"Q1":{"kind":"web","text":proof.quote}})
    target = Criterion(field="Abmessungen",operator="eq",target="200 x 4,8",unit="mm",evidence=proof)
    assert compare(target,selected["Abmessungen"]) is True
    assert compare(target.model_copy(update={"field":"Länge × Breite"}),facts[0]) is False


def test_one_panel_with_area_based_pack_label_is_priced_as_one_item():
    p,sources = case(False,"5")
    source_id = "Q2"
    name = "Bauplatte 2500 x 1250 x 18 mm"
    identity = f"Werk A · {name}"
    quote = f"{identity}: 41,88 EUR Inhalt: 3.125 m² (13,40 EUR / 1 m²) Preise inkl. MwSt."
    sources[source_id] = {"kind":"web","text":quote}
    proof = Evidence(source_id=source_id,quote=quote)
    price = Fact(field="listed_price",value="41,88",unit="EUR",evidence=proof)
    offer = Offer(supplier="Werk A",product=name,identity=Evidence(source_id=source_id,quote=identity),facts=[price])
    row = evaluate(p,[offer],sources,[],WEIGHTS)[0]
    assert row["listed_price"]["goods_value"] == 209.40
    assert row["metrics"]["gross_goods_price"]["value"] == 209.40
    assert "3.125 m² je Stück" in row["listed_price"]["calculation"]
    multi_panel_quote = quote.replace("3.125","6.250")
    sources[source_id]["text"] = multi_panel_quote
    price.evidence.quote = multi_panel_quote
    assert "goods_value" not in evaluate(p,[offer],sources,[],WEIGHTS)[0]["listed_price"]


def test_nearest_verified_branch_beats_headquarters_and_other_branch():
    from workflow import add_routes
    p,sources = case(False)
    offer = candidate(sources,"Werk A","10")
    for field,value,km in (("company_address","Fernstadt","150"),("branch_address","Weststadt","45"),("branch_address","Oststadt","15")):
        sid = f"Q{len(sources)+1}"
        quote = f"Werk A Standort {value}."
        sources[sid] = {"kind":"web","text":quote,"url":f"https://shop.example/{value}",
                        "branch_lookup_destination":p.destination}
        offer.facts.append(Fact(field=field,value=value,unit="",evidence=Evidence(source_id=sid,quote=quote)))
    entries = [dict(id=key,**value) for key,value in sources.items()]
    km_by_town = {"Fernstadt":"150","Weststadt":"45","Oststadt":"15"}
    with patch("workflow.route_distance",side_effect=lambda town,target:("https://route.example/",km_by_town[town],"coords")):
        add_routes([offer],p,entries)
    row = evaluate(p,[offer],{s["id"]:s for s in entries},[],WEIGHTS)[0]
    assert row["distance"]["origin_kind"] == "branch"
    assert row["distance"]["origin"] == "Oststadt"
    assert row["metrics"]["distance_km"]["value"] == 15
    with patch("workflow.route_distance",return_value=None), patch("workflow.air_distance",return_value=None):
        add_routes([offer],p,entries)
    saved = evaluate(p,[offer],{s["id"]:s for s in entries},[],WEIGHTS)[0]
    assert saved["distance"]["origin_kind"] == "branch"
    assert saved["metrics"]["distance_km"]["value"] == 15
    sid = "Q90"
    quote = "Werk A versendet diesen Artikel · Versandstandort: Hafenstadt."
    entries.append(dict(id=sid,kind="web",text=quote,url="https://shop.example/product"))
    offer.facts.append(Fact(field="dispatch_location",value="Hafenstadt",unit="",
                            evidence=Evidence(source_id=sid,quote=quote)))
    km_by_town["Hafenstadt"] = "80"
    with patch("workflow.route_distance",side_effect=lambda town,target:("https://route.example/",km_by_town[town],"coords")):
        add_routes([offer],p,entries)
    rerouted = evaluate(p,[offer],{s["id"]:s for s in entries},[],WEIGHTS)[0]
    assert rerouted["distance"]["origin_kind"] == "dispatch"
    assert rerouted["metrics"]["distance_km"]["value"] == 80


def test_unsuccessful_route_retries_in_followup():
    from workflow import add_routes
    p,sources = case(False)
    offer = candidate(sources,"Werk A","10")
    sid = offer.identity.source_id
    quote = "Werk A Firmenstandort Stuttgart."
    sources[sid]["text"] += " " + quote
    offer.facts.append(Fact(field="company_city",value="Stuttgart",unit="",
                            evidence=Evidence(source_id=sid,quote=quote)))
    entries = [dict(id=key,**source) for key,source in sources.items()]
    with patch("workflow.geocode",return_value=None), patch("workflow.route_distance",return_value=None), \
         patch("workflow.air_distance",return_value=None):
        add_routes([offer],p,entries)
    assert evaluate(p,[offer],{s["id"]:s for s in entries},[],WEIGHTS)[0]["distance"]["status"] == "open"
    with patch("workflow.route_distance",return_value=("https://route.example/","620","coords")) as router:
        add_routes([offer],p,entries)
    router.assert_called_once_with("Stuttgart","Berlin")
    assert evaluate(p,[offer],{s["id"]:s for s in entries},[],WEIGHTS)[0]["metrics"]["distance_km"]["value"] == 620


def test_failed_address_geocodes_proven_city_then_routes():
    from workflow import add_routes
    p,sources = case(False)
    offer = candidate(sources,"Werk A","10")
    sid = offer.identity.source_id
    quote = "Werk A Anschrift Hauptstraße 1, 70173 Stuttgart."
    sources[sid]["text"] += " " + quote
    offer.facts.append(Fact(field="company_address",value="Hauptstraße 1, 70173 Stuttgart",unit="",evidence=Evidence(source_id=sid,quote=quote)))
    entries = [dict(id=key,**value) for key,value in sources.items()]
    with patch("workflow.geocode",side_effect=lambda _,query: None if "Hauptstraße" in query else ((48.7,9.2),"geo")), \
         patch("workflow.route_distance",side_effect=lambda query,_: ("https://route.example/","600","coords") if query=="70173 Stuttgart" else None):
        add_routes([offer],p,entries)
    row = evaluate(p,[offer],{s["id"]:s for s in entries},[],WEIGHTS)[0]
    assert row["distance"]["origin"] == "Stuttgart"
    assert row["metrics"]["distance_km"]["value"] == 600


def test_city_is_sufficient_and_failed_road_route_uses_separate_air_basis():
    from workflow import add_routes
    p,sources = case(False)
    offer = candidate(sources,"Werk A","10")
    sid = offer.identity.source_id
    quote = "Werk A Firmenstandort Stuttgart."
    sources[sid]["text"] += " " + quote
    offer.facts.append(Fact(field="company_city",value="Stuttgart",unit="",evidence=Evidence(source_id=sid,quote=quote)))
    entries = [dict(id=key,**value) for key,value in sources.items()]
    with patch("workflow.route_distance",return_value=None) as road, patch("workflow.air_distance",return_value=(510,"48.7,9.1 → 52.5,13.4","https://geo.example/")):
        add_routes([offer],p,entries)
    road.assert_called_once_with("Stuttgart","Berlin")
    row = evaluate(p,[offer],{s["id"]:s for s in entries},[],WEIGHTS)[0]
    assert row["distance"]["status"] == "ready"
    assert "Luftlinie" in row["distance"]["method"]
    assert "|air|" in row["metrics"]["distance_km"]["basis"]
    assert "Stadtzentrum zu Stadtzentrum" in row["distance"]["label"]
    assert "Versandort unbestätigt" in row["distance"]["label"]


def test_historical_and_current_prices_do_not_share_price_points():
    p,sources = case(False)
    old = candidate(sources,"Alt","10")
    new = candidate(sources,"Neu","20")
    sid = old.identity.source_id
    quote = "Listenstand 15.01.2024."
    sources[sid]["text"] += " " + quote
    old.facts.append(Fact(field="price_date",value="15.01.2024",unit="",evidence=Evidence(source_id=sid,quote=quote)))
    rows = evaluate(p,[old,new],sources,[],WEIGHTS)
    assert sum(bool(row["partial_score"]) for row in rows) == 1
    assert "Vorläufige Empfehlung: Neu" in recommendation(rows)


def test_minimum_quantity_is_rounded_to_a_whole_pack():
    p,sources = case(False,"1000")
    offer = candidate(sources,"Werk A","10")
    sid = offer.identity.source_id
    quote = f"{offer.product}: 10 EUR netto je 100 Stück; Verpackung 500 Stück; Mindestmenge 1200 Stück."
    sources[sid]["text"] += " " + quote
    offer.facts = [Fact(field=field,value=value,unit=unit,evidence=Evidence(source_id=sid,quote=quote))
        for field,value,unit in [("listed_price","10","EUR"),("price_quantity","100","Stück"),
                                 ("pack_size","500","Stück"),("minimum_quantity","1200","Stück")]]
    row = evaluate(p,[offer],sources,[],WEIGHTS)[0]
    assert row["listed_price"]["supplied_quantity"] == 1500
    assert row["metrics"]["net_price"]["value"] == 150


def test_postal_district_falls_back_to_proven_parent_town():
    from research import geocode
    from types import SimpleNamespace
    def response(url,params,**kwargs):
        features = [] if params["q"] == "Reichshof-Heischeid" else [{"properties":{
            "osm_key":"place","type":"city","name":"Reichshof","country":"Deutschland"},
            "geometry":{"coordinates":[7.69,50.95]}}]
        return SimpleNamespace(raise_for_status=lambda:None,json=lambda:{"features":features},url=url+"?q="+params["q"])
    with patch("research.httpx.get",side_effect=response):
        point,url = geocode("https://district-test.example/api","Reichshof-Heischeid")
    assert point == (50.95,7.69)
    assert "q=Reichshof" in url


def test_missing_prices_and_missing_distances_share_one_ranking():
    p,sources = case(False)
    offers = [candidate(sources,"Preis A","10"),candidate(sources,"Preis B","20"),candidate(sources,"Ort C","99",distance="100")]
    offers[-1].facts = [f for f in offers[-1].facts if f.field != "listed_price"]
    rows = evaluate(p,offers,sources,[],WEIGHTS)
    assert rows[0]["supplier"] == "Preis A"
    separate = next(row for row in rows if row["supplier"] == "Ort C")
    assert separate["partial_score"]["value"] == 16.19
    assert separate["partial_score"]["basis"] == {"distance_km":20}
    assert rows[1] == separate
    assert "Vorläufige Empfehlung: Preis A" in recommendation(rows)


def test_missing_distance_caps_score_and_can_still_win():
    p,sources = case(False)
    offers = [candidate(sources,"Günstig","10"),
              candidate(sources,"Nah","13",distance="50"),
              candidate(sources,"Fern","13",distance="500")]
    rows = evaluate(p,offers,sources,[],WEIGHTS)
    assert [row["supplier"] for row in rows] == ["Günstig","Nah","Fern"]
    assert rows[0]["partial_score"] == {"value":72,"basis":{"net_price":80},"components":{"net_price":72}}
    assert rows[1]["components"]["distance_km"] == 16.59
    assert rows[2]["components"]["distance_km"] == 13.6
    assert [row["score"] for row in rows[1:]] == [69.53,66.54]
    assert "Vorläufige Empfehlung: Günstig" in recommendation(rows)


def case(thickness=True,quantity="10"):
    need = "Aluminiumplatten nach Berlin." + (" Gewünschte Dicke 3 mm." if thickness else "")
    p = OrderPosition(name="Aluminiumplatten",material_group="Metall",quantity=quantity,quantity_unit="Stück" if quantity else "",
        destination="Berlin",scope_evidence=Evidence(source_id="Q1",quote=need),
        destination_evidence=Evidence(source_id="Q1",quote=need),must=[],quality=[],search_query="Aluminiumplatten",questions=[])
    if thickness:
        p.must = [Criterion(field="Dicke",operator="eq",target="3",unit="mm",evidence=Evidence(source_id="Q1",quote=need))]
    sources = {"Q1":{"kind":"input","text":need}}
    return p,sources


def test_material_questions_pause_comparison_and_survive_restart(tmp_path):
    from purchasing import MaterialQuestion

    need = "1000 Spanplattenschrauben nach Berlin."
    scoped,_ = case(False,"1000")
    scoped.name = "Spanplattenschrauben"
    scoped.scope_evidence = Evidence(source_id="Q1",quote="1000 Spanplattenschrauben")
    scoped.destination_evidence = Evidence(source_id="Q1",quote="Berlin")
    scoped.search_query = "Spanplattenschrauben"
    second = MaterialQuestion(position=1,field="Durchmesser",options=["4 mm","5 mm"])
    with_length = scoped.model_copy(update={"must":[Criterion(field="Länge",operator="eq",target="40",
                           unit="mm",evidence=Evidence(source_id="Q1",quote="40 mm"))]})
    hits = [{"href":"https://catalog.example/specs", "title":"Schraubenlängen 30 mm und 40 mm",
             "body":"Durchmesser 4 mm und 5 mm."}]
    with TestClient(create_app(tmp_path)) as client, patch("harness.Harness.ask",return_value=Scope(
            positions=[scoped],questions=["Welchen Durchmesser und welche Länge sollen die Schrauben haben?"],material_question=None)), patch("workflow.search_one",return_value=(hits,None)), \
            patch("workflow.discover",side_effect=AssertionError("supplier search before answer")):
        response = client.post("/api/agent/run",data={"need":need,"web":"true"})
        assert response.status_code == 200, response.text
        pending = response.json()
        assert pending["answer_only"] and pending["positions"][0]["quantity"] == "1000"
        assert "30 mm oder 40 mm" in pending["answer"] and "50 mm" not in pending["answer"]
        assert any(source.get("url") == hits[0]["href"] for source in pending["sources"])
    final = Scope(positions=[with_length],questions=[],material_question=MaterialQuestion(
        position=1,field="Oberfläche",options=["verzinkt","blank"]))
    with TestClient(create_app(tmp_path)) as client, patch("harness.Harness.ask",side_effect=[
            Scope(positions=[with_length],questions=[],material_question=second),final]) as model, \
            patch("workflow.search_one",return_value=(hits,None)), patch("workflow.discover",return_value=([],[])) as compare_web:
        search_id = pending["search_id"]
        response = client.post("/api/agent/run",data={"need":"40 mm","search_id":search_id,"web":"true"})
        assert response.status_code == 200, response.text
        assert response.json()["answer_only"] and len(response.json()["material_clarifications"]) == 2
        compare_web.assert_not_called()
        assert model.call_args.args[2]["previous_positions"][0]["quantity"] == "1000"
        response = client.post("/api/agent/run",data={"need":"flexibel","search_id":search_id,"web":"true"})
        assert response.status_code == 200, response.text
        completed = response.json()
        assert "material_clarifications" not in completed
        assert completed["positions"][0]["must"][0]["target"] == "40"
        assert completed["positions"][0]["quantity"] == "1000"
        assert compare_web.called


def test_concrete_material_need_starts_comparison_without_preliminary_lookup(tmp_path):
    scoped,_ = case(True)
    with TestClient(create_app(tmp_path)) as client, patch("harness.Harness.ask",return_value=Scope(
            positions=[scoped],questions=[],material_question=None)), \
            patch("workflow.search_one",side_effect=AssertionError("unnecessary material lookup")), \
            patch("workflow.discover",return_value=([],[])) as discover:
        response = client.post("/api/agent/run",data={
            "need":"Aluminiumplatten nach Berlin. Gewünschte Dicke 3 mm. Legierung EN AW-5754. Format egal.","web":"true"})
    assert response.status_code == 200,response.text
    assert response.json()["positions"][0]["must"][0]["target"] == "3"
    assert "material_clarifications" not in response.json()
    assert discover.called


def test_flexible_format_keeps_alloy_as_the_material_question(tmp_path):
    scoped,_ = case(False,"20")
    scoped.name = "Aluminiumplatten"
    scoped.questions = ["Ist eine bestimmte Aluminiumlegierung erforderlich?"]
    need = "Ich brauche 20 mal 3mm dicke alluminiumplatten. größe ist egal. lieferung nach köln"
    with TestClient(create_app(tmp_path)) as client, patch("harness.Harness.ask",return_value=Scope(
            positions=[scoped],questions=[],material_question=None)), patch("workflow.search_one",return_value=([],None)), \
            patch("workflow.discover",side_effect=AssertionError("supplier search before answer")):
        response = client.post("/api/agent/run",data={"need":need,"web":"true"})
    assert response.status_code == 200,response.text
    result = response.json()
    assert result["material_clarifications"][0]["field"] == "Legierung"
    assert "EN AW-5754" in result["answer"]
    assert not result["positions"][0]["offers"]


def candidate(sources,supplier,price,thickness=None,distance=None):
    source_id = f"Q{len(sources)+1}"
    product = "Aluminiumplatte " + supplier
    identity = f"{supplier} {product}."
    priced = f"{product}: {price} EUR netto je Stück. Versandkosten offen."
    text = identity + " " + priced
    facts = [Fact(field="listed_price",value=price,unit="EUR",evidence=Evidence(source_id=source_id,quote=priced))]
    if thickness is not None:
        quote = f"Dicke {thickness} mm."
        text += " " + quote
        facts.append(Fact(field="Dicke",value=thickness,unit="mm",evidence=Evidence(source_id=source_id,quote=quote)))
    if distance is not None:
        quote = f"Straßenentfernung nach Berlin: {distance} km."
        text += " " + quote
        facts.append(Fact(field="distance_km",value=distance,unit="km",evidence=Evidence(source_id=source_id,quote=quote)))
    sources[source_id] = {"kind":"pdf","text":text}
    return Offer(supplier=supplier,product=product,identity=Evidence(source_id=source_id,quote=identity),facts=facts)


def test_rough_need_shows_candidates_and_a_traceable_selection():
    p,sources = case(False,"")
    offers = [candidate(sources,"Werk A","10"),candidate(sources,"Werk B","20")]
    rows = evaluate(p,offers,sources,["Welche Dicke und Abmessungen benötigen Sie?"],WEIGHTS)
    assert len(rows)==2
    assert rows[0]["partial_score"]["basis"] == {"unit_net_price":80}
    assert rows[0]["partial_score"]["value"] == 72
    text = recommendation(rows,["Welche Dicke und Abmessungen benötigen Sie?"])
    assert "Vorläufige Empfehlung: Werk A" in text and "Ausführung" in text and "Dicke" in text


def test_unknown_thickness_can_win_with_direct_open_check():
    p,sources = case()
    offers = [candidate(sources,"Werk A","10"),candidate(sources,"Werk B","20","3")]
    rows = evaluate(p,offers,sources,[],WEIGHTS)
    assert rows[0]["supplier"]=="Werk A"
    assert rows[0]["must"][0]["result"] is None
    assert "Offene Prüfung direkt für diesen Kandidaten: Dicke" in recommendation(rows)


def test_proven_wrong_thickness_stays_as_deviating_alternative_without_points():
    p,sources = case()
    offers = [candidate(sources,"Werk A","5","5"),candidate(sources,"Werk B","20","3")]
    rows = evaluate(p,offers,sources,[],WEIGHTS)
    wrong = next(row for row in rows if row["supplier"]=="Werk A")
    assert wrong["status"]=="abweichend" and wrong["score"] is None and wrong["partial_score"] is None
    assert "5 statt 3" in wrong["reasons"]["alternative"]
    assert "Werk B" in recommendation(rows)


def test_missing_shipping_does_not_block_goods_price_comparison():
    p,sources = case()
    rows = evaluate(p,[candidate(sources,"Werk A","10","3"),candidate(sources,"Werk B","20","3")],sources,[],WEIGHTS)
    assert rows[0]["metrics"]["net_price"]["value"]==100
    assert rows[1]["metrics"]["net_price"]["value"]==200
    assert rows[0]["partial_score"]["basis"]=={"net_price":80}
    assert [row["partial_score"]["value"] for row in rows]==[72,14.4]
    assert "Materialpreisvergleich ohne Versand" in recommendation(rows)


def test_complete_eighty_twenty_rating_and_no_quality_or_delivery_points():
    offers,sources = scenario()
    for offer in offers:
        total = next(f for f in offer.facts if f.field == "total_price")
        quote = f"100 Stück nach Berlin: Warenpreis netto ohne Versand {total.value} EUR."
        sources[total.evidence.source_id]["text"] += " " + quote
        offer.facts.append(Fact(field="net_price",value=total.value,unit="EUR",evidence=Evidence(source_id=total.evidence.source_id,quote=quote)))
    rows = evaluate(position(),offers[:2],sources,[],WEIGHTS)
    assert [row["score"] for row in rows]==[88.35,78.66]
    assert rows[0]["components"]=={"net_price":72,"distance_km":16.35}
    assert "quality" not in rows[0]["metrics"] and "delivery_days" not in rows[0]["metrics"]
    assert "Empfehlung: Testwerk Nord" in recommendation(rows)


def test_price_basis_is_distinct_from_pack_size_and_order_rounds_up():
    p,sources = case(False,"1100")
    offer = candidate(sources,"Werk A","10")
    source_id = offer.identity.source_id
    quote = f"{offer.product}: 10 EUR netto je 100 Stück, Verpackung 500 Stück."
    sources[source_id]["text"] += " " + quote
    offer.facts = [
        Fact(field="listed_price",value="10",unit="EUR",evidence=Evidence(source_id=source_id,quote=quote)),
        Fact(field="price_quantity",value="100",unit="Stück",evidence=Evidence(source_id=source_id,quote=quote)),
        Fact(field="pack_size",value="500",unit="Stück",evidence=Evidence(source_id=source_id,quote=quote))]
    row = evaluate(p,[offer],sources,[],WEIGHTS)[0]
    assert row["listed_price"]["basis_quantity"]==100 and row["listed_price"]["pack_size"]==500
    assert row["listed_price"]["supplied_quantity"]==1500
    assert row["listed_price"]["order_quantity"]==3
    assert row["metrics"]["net_price"]["value"]==150


def test_followup_adds_alloy_keeps_search_and_marks_old_variant(tmp_path):
    p,sources = case(False,"")
    offers = [candidate(sources,"Werk A","10"),candidate(sources,"Werk B","20")]
    lines = []
    for offer,alloy in zip(offers,["EN AW-1050","EN AW-5754"]):
        quote = "Legierung "+alloy+"."
        offer.facts.append(Fact(field="Legierung",value=alloy,unit="",evidence=Evidence(source_id="Q2",quote=quote)))
        sources[offer.identity.source_id]["text"] += " " + quote
        lines.append(sources[offer.identity.source_id]["text"])
        offer.identity.source_id="Q2"
        for fact in offer.facts: fact.evidence.source_id="Q2"
    pdf = example_pdf([lines])
    with TestClient(create_app(tmp_path)) as client,patch("harness.Harness.ask",side_effect=[Scope(positions=[p],questions=[]),Offers(offers=offers)]):
        initial = client.post("/api/agent/run",data={"need":"Aluminiumplatten nach Berlin","web":"false"},files={"pdfs":("Angebote.pdf",pdf,"application/pdf")})
        assert initial.status_code==200,initial.text
        saved=initial.json()
    update=p.model_copy(deep=True)
    update.must=[Criterion(field="Legierung",operator="eq",target="EN AW-5754",unit="",
                          evidence=Evidence(source_id="Q1",quote="Ergänze Legierung EN AW-5754."))]
    with TestClient(create_app(tmp_path)) as restarted,patch("harness.Harness.ask",side_effect=[Scope(positions=[update],questions=[]),Offers(offers=[])]):
        result=restarted.post("/api/agent/run",data={"need":"Ergänze Legierung EN AW-5754.","search_id":saved["search_id"],"web":"false"})
        assert result.status_code==200,result.text
        report=result.json()
        assert report["weights"]==WEIGHTS and report["search_id"]==saved["search_id"]
        rows={row["supplier"]:row for row in report["positions"][0]["offers"]}
        assert rows["Werk A"]["status"]=="abweichend"
        assert rows["Werk B"]["status"]!="abweichend"


@pytest.mark.parametrize("unit,quantity,price,expected",[("kg","2,5","10",25),("m","12","2,50",30)])
def test_metres_and_kilograms_share_a_verified_unit_basis(unit,quantity,price,expected):
    p,sources=case(False,quantity)
    p.quantity_unit=unit
    offer=candidate(sources,"Werk A",price)
    sid=offer.identity.source_id
    quote=f"{offer.product}: {price} EUR netto je {unit}. Versandkosten offen."
    sources[sid]["text"]+=" "+quote
    offer.facts=[Fact(field="listed_price",value=price,unit="EUR",evidence=Evidence(source_id=sid,quote=quote))]
    row=evaluate(p,[offer],sources,[],WEIGHTS)[0]
    assert row["listed_price"]["basis_unit"]==unit
    assert row["metrics"]["net_price"]["value"]==expected


def test_historical_price_is_visible_without_current_price_points():
    p,sources=case(False)
    offer=candidate(sources,"Werk A","10")
    sid=offer.identity.source_id
    quote="Listenstand 15.01.2024."
    sources[sid]["text"]+=" "+quote
    offer.facts.append(Fact(field="price_date",value="15.01.2024",unit="",evidence=Evidence(source_id=sid,quote=quote)))
    row=evaluate(p,[offer],sources,[],WEIGHTS)[0]
    assert row["listed_price"]["historical"] and row["listed_price"]["value"]==10
    assert row["metrics"]["net_price"]["value"] == 100
    assert "historisch:15.01.2024" in row["metrics"]["net_price"]["basis"]


def test_platform_address_is_not_the_unconfirmed_seller_location():
    p,sources=case(False)
    offer=candidate(sources,"Amazon","10",distance="500")
    offer.marketplace="Amazon"
    sid=offer.identity.source_id
    quote="Amazon Firmenanschrift Beispielstraße 1, 10115 Berlin."
    sources[sid]["text"]+=" "+quote
    offer.facts.append(Fact(field="company_address",value="Beispielstraße 1, 10115 Berlin",unit="",evidence=Evidence(source_id=sid,quote=quote)))
    row=evaluate(p,[offer],sources,[],WEIGHTS)[0]
    assert row["seller_confirmed"] is False
    assert "distance_km" not in row["metrics"] and row["distance"] is None
    assert not any(fact["field"]=="company_address" for fact in row["specs"])
    assert row["listed_price"]["value"]==10


def test_tx_wording_does_not_become_a_false_deviating_alternative():
    from purchasing import compare
    requirement=Criterion(field="Antrieb",operator="eq",target="TX-Antrieb",unit="",evidence=Evidence(source_id="Q1",quote="TX-Antrieb"))
    for wording in ("TX","Torx","TX20"):
        assert compare(requirement,Fact(field="Antrieb",value=wording,unit="",evidence=Evidence(source_id="Q2",quote=wording))) is True


def test_legacy_report_keeps_its_weights_and_new_comparison_uses_eighty_twenty(tmp_path):
    from server import database
    from test_agent import NEED,WEIGHTS as legacy_weights
    offers,sources=scenario()
    pdf=example_pdf([[sources[f"Q{i}"]["text"]] for i in range(2,6)])
    with TestClient(create_app(tmp_path)) as client,patch("harness.Harness.ask",side_effect=[
        Scope(positions=[position()],questions=[]),Offers(offers=offers)]):
        response=client.post("/api/agent/run",data={"need":NEED,"web":"false"},files={"pdfs":("Angebote.pdf",pdf,"application/pdf")})
        assert response.status_code==200,response.text
        legacy=response.json()
        legacy.pop("evaluation_version")
        legacy["weights"]=legacy_weights
        legacy["positions"][0]["offers"]=evaluate(position(),offers,sources,[],legacy_weights)
        with database(tmp_path/"agent_memory.sqlite3") as conn:
            conn.execute("update reports set report_json=? where session_id=?",(json.dumps(legacy),legacy["session_id"]))
        assert client.get(f"/api/agent/reports/{legacy['session_id']}").json()["weights"]==legacy_weights
        with patch("harness.Harness.ask",side_effect=AssertionError("recalculation needs no model")):
            updated=client.post("/api/agent/run",data={"need":"Berechne neu.","web":"false","search_id":legacy["search_id"]})
        assert updated.status_code==200,updated.text
        assert updated.json()["weights"]==WEIGHTS
        old=client.get(f"/api/agent/reports/{legacy['session_id']}").json()
        assert old["weights"]==legacy_weights and old["positions"][0]["offers"][0]["score"]==86.25


def test_single_supplier_has_a_conservative_price_score_even_with_multiple_variants():
    p, sources = case(False)
    offers = [candidate(sources, "Einzelhändler", "10", distance="0"),
              candidate(sources, "Einzelhändler", "11", distance="0")]
    rows = evaluate(p, offers, sources, [], WEIGHTS)
    assert rows[0]["components"] == {"net_price": 56, "distance_km": 17}
    assert rows[0]["score"] == 73
    assert rows[0]["criterion_points"]["price"]["supplier_count"] == 1
    assert rows[1]["score"] < rows[0]["score"]
    assert recommendation(rows).startswith("Vorläufige Empfehlung")
    assert "nur ein vergleichbarer Lieferant" in recommendation(rows)


@pytest.mark.parametrize("length_reply, expected", [("40 mm", {"LS04004011"}),
                                                   ("Flexibel", {"LS04003011","LS04004011"})])
def test_pdf_material_questions_use_rows_and_compare_after_reply(length_reply, expected):
    from workflow import run_workflow
    from unittest.mock import Mock

    need = "1000 Stück nach Berlin"
    scoped, _ = case(False, "1000")
    scoped.name = "Spanplattenschrauben"
    scoped.scope_evidence = Evidence(source_id="Q1", quote="1000 Stück")
    scoped.destination_evidence = Evidence(source_id="Q1", quote="Berlin")
    document = {"kind":"pdf", "title":"Angebot.pdf", "path":"angebot.pdf", "page":2,
                "text":"PDF-Metadaten · Autor: Testwerk\nDatum: | 01.01.2024\n"
                "Artikelnr | Bezeichnung | Verp.-Einh. | Pr.Einh. | VK netto €\n"
                "LS04003011 | Spanplattenschraube 4 x 30 mm | 500 | 100 | 2,30 €\n"
                "LS04004011 | Spanplattenschraube 4 x 40 mm | 500 | 100 | 2,65 €\n"
                "LS05005011 | Spanplattenschraube 5 x 50 mm | 500 | 100 | 3,50 €"}
    harness = Mock()
    harness.ask.side_effect = [Scope(positions=[scoped], questions=[]), Offers(offers=[])]
    files = {"AGENTS.md":"", "role.yaml":""}
    with patch("workflow.search_one", side_effect=AssertionError("Websuche ausgeschaltet")):
        first = run_workflow(harness,files,need,[document],False,[],WEIGHTS)
        assert first["material_clarifications"][0]["options"] == ["4 mm", "5 mm"]
        second = run_workflow(harness,files,"4 mm",[],False,[],WEIGHTS,first,[need,"4 mm"])
        assert set(second["material_clarifications"][-1]["options"]) == {"30 mm","40 mm"}
        assert second["positions"][0]["must"][0]["target"] == "4"
        assert second["pdf_review"][0]["pages"] == [2]
        report = run_workflow(harness,files,length_reply,[],False,[],WEIGHTS,second,[need,"4 mm",length_reply])
    assert {row["product"] for row in report["positions"][0]["offers"]} == expected
    assert any(row["metrics"]["net_price"]["value"] == 26.5 for row in report["positions"][0]["offers"])


@pytest.mark.parametrize(("query", "variant"), [
    ("Schraube 3,5 × 40", "Schraube 3.50 x 40.0 mm"),
    ("Blech 250 × 500 × 2,5", "Blech 250x500x2.50 mm"),
])
def test_pdf_page_selection_prioritizes_the_exact_decimal_dimensions(query, variant):
    from workflow import pdf_selection

    pages = [
        {"kind": "pdf", "path": "tabelle.pdf", "page": index, "text": text}
        for index, text in enumerate(["Katalog", "Schraube 3 x 40. Blech 250x500x2 mm", variant], 1)
    ]
    assert [page["page"] for page in pdf_selection(pages, query, limit=2)] == [1, 3]


def test_pdf_only_comparison_adds_imprint_distance_without_searching_for_offers():
    from unittest.mock import Mock
    from workflow import run_workflow

    need = "1000 Stück Spanplattenschrauben 4 x 40 mm nach Berlin"
    scoped, _ = case(False, "1000")
    scoped.name = "Spanplattenschrauben 4 x 40 mm"
    scoped.scope_evidence = Evidence(source_id="Q1", quote="1000 Stück")
    scoped.destination_evidence = Evidence(source_id="Q1", quote="Berlin")
    document = {"kind": "pdf", "title": "Angebot.pdf", "path": "angebot.pdf", "page": 2,
                "text": "PDF-Metadaten · Autor: Beispielwerk\nwww.beispielwerk.example\nDatum: | 01.01.2024\n"
                        "Artikelnr | Bezeichnung | Verp.-Einh. | Pr.Einh. | VK netto €\n"
                        "LS04004011 | Spanplattenschraube 4 x 40 mm | 500 | 100 | 2,65 €"}
    imprint = {"kind": "web", "url": "https://www.beispielwerk.example/impressum/", "title": "Impressum",
               "text": "Impressum – Beispielwerk Zum Inhalt springen Impressum "
                       "Beispielwerk GmbH Sattlerweg 1 D-84367 Tann Kontakt"}
    harness = Mock()
    harness.ask.return_value = Scope(positions=[scoped], questions=[])
    with patch("workflow.discover", side_effect=AssertionError("Angebotssuche ausgeschaltet")), \
         patch("supplier_locations.fetch", return_value=([imprint], [])) as fetch, \
         patch("workflow.route_distance", return_value=("https://router.example", "125", "1,2; 3,4")):
        report = run_workflow(harness, {"role.yaml": "", "AGENTS.md": ""}, need, [document], False, [], WEIGHTS)
    assert [call.args[0] for call in fetch.call_args_list] == [
        "https://www.beispielwerk.example/", imprint["url"]]
    row = report["positions"][0]["offers"][0]
    assert row["listed_price"]["goods_value"] == 26.5
    assert row["distance"]["distance_km"] == 125
    assert row["distance"]["origin_kind"] == "company"
    assert row["components"]["net_price"] == 56
    source_id = row["distance"]["address_evidence"]["source_id"]
    assert next(source["url"] for source in report["sources"] if source["id"] == source_id) == imprint["url"]


def test_cable_catalog_uses_black_column_and_rotated_price_terms():
    from catalog import catalog_candidates

    position, sources = case(False, "500")
    position.name = "Schwarze Kabelbinder 200 × 4,8 mm"
    position.quantity_unit = "Stück"
    sources["Q2"] = {"id":"Q2","kind":"pdf","path":"kabel.pdf","title":"Kabel.pdf","page":3,
                     "text":"Kabelbinder\nwww.anbieter.de\n"
                     "Type | Länge | Breite | VPE | Weiss | Schwarz | EUR/\n"
                     "mm | mm | Stk. | ArtNr | ArtNr | 100 Stk.\n"
                     "KB200 | 200 | 4,8 | 100 | WEISS200 | BLACK200 | 11,73\n"
                     "KB430 | 430 | 4,8 | 100 | WEISS430 | BLACK430 | 7,47\n"
                     "Preise in Euro, exkl. MwSt., freibleibend. • 01/2025"}
    offers,prices = catalog_candidates(position,list(sources.values()),{})
    rows = evaluate(position,offers,sources,[],WEIGHTS,prices)
    assert [row["product"] for row in rows] == ["BLACK200"]
    price = rows[0]["listed_price"]
    assert price["goods_value"] == 58.65 and price["tax"] == "netto"
    assert price["date"] == "01/2025" and price["basis_evidence"]["source_id"] == "Q2"


def test_descriptive_count_uses_grounded_request():
    from practical_prices import demand_unit

    position, sources = case(False,"500")
    position.name = "Blaue Steckverbinder"
    position.quantity_unit = "Steckverbinder"
    sources["Q1"]["text"] = "Ich benötige 500 blaue Steckverbinder."
    position.scope_evidence = Evidence(source_id="Q1",quote="500 blaue Steckverbinder")
    assert demand_unit(position,sources) == "Stück"
    position.scope_evidence.quote = "500 schwarze Steckverbinder"
    assert demand_unit(position,sources) == ""


def test_official_legacy_imprint_supports_foreign_head_office_and_shop_operator():
    from supplier_locations import imprint_facts

    foreign = {"id":"Q2","url":"https://shop.example/unternehmen/impressum.html",
               "text":"Beispiel GmbH Kontakt Beispiel s.r.o. Klíny 35, 615 00 Brno Tschechische Republik"}
    local = {"id":"Q3","url":"https://shop.example/Impressum%3A_%3A4.html",
             "text":"Beispiel-Shop Alexander Muster e.K. Frankampstraße 188 D-45891 Gelsenkirchen"}
    assert {fact.field:fact.value for fact in imprint_facts("Beispiel",foreign)}["company_country"] == "Tschechische Republik"
    assert imprint_facts("Beispiel-Shop",local)[0].value.endswith("45891 Gelsenkirchen")


def test_geocoding_exact_address_accepts_parenthetical_city_qualifier():
    from geocoding import select_location
    point = (51.4,7.8)
    candidate = {"point":point,"properties":{"city":"Beispielstadt (Region)","postcode":"12345","countrycode":"de"},
                 "names":[""],"street":"Ringstraße","house":"52","kind":"house"}
    assert select_location([candidate],"Ringstraße 52, 12345 Beispielstadt") == ((point,"address"),False)
