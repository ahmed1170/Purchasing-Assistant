# Purchasing Assistant

Lokaler Einkaufsagent für mehrere Materialgruppen. FastAPI führt den Ablauf aus, SQLite speichert Berichte, und die Browseroberfläche zeigt Angebote, Belege und Agentendateien. Die Anwendung benötigt keinen zentralen Trinity-Hub.

## Unter Windows starten

Im Projektordner in PowerShell ausführen.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\start.ps1 -Restart
```

Dann [die lokale Oberfläche öffnen](http://127.0.0.1:8765). Das Skript nutzt Python 3.11+ oder die mit Codex verfügbare Python-Laufzeit, richtet bei Bedarf die virtuelle Umgebung ein und startet den Server auf Loopback.

- Die Oberfläche verwendet **Codex** mit der vorhandenen CLI-Anmeldung und dem Standardmodell. Unter Windows hat `TRINITY_CODEX_EXE` Vorrang. Danach kommen PATH, die Desktop-CLI im lokalen OpenAI-Codex-Verzeichnis und bei Bedarf die CLI des installierten App-Pakets. Fehler beim Start oder bei der Anmeldung erscheinen in der Kopfzeile. Nach einer neuen Anmeldung die Seite neu laden. [OpenAI-Dokumentation zu Codex-Befehlen](https://developers.openai.com/codex/cli/reference)
- Ein **OpenAI-kompatibler** Endpunkt lässt sich über `POST /api/agent/run` mit den Formularfeldern `harness=chat`, `base_url` und `model` verwenden. Beispiele sind `http://localhost:1234/v1` für LM Studio, `http://localhost:11434/v1` für Ollama und `https://api.openai.com/v1` für OpenAI. Der Schlüssel kann als `api_key` mitgegeben werden. Für OpenAI ist auch `OPENAI_API_KEY` verfügbar.

## Einen Bedarf prüfen

Bei ausgeschalteter Angebotssuche prüft Ellis fehlende Firmenstandorte der in PDFs gefundenen Lieferanten auf der offiziellen Website und berechnet bei bekanntem Lieferort die Strecke. „Bitte prüfe Preise und Entfernungen“ startet in einer gespeicherten PDF-Suche zusätzlich eine gezielte Websuche nach den bereits erkannten Artikeln. Angebote für dieselbe Artikelnummer erscheinen unter dem jeweiligen Händler. Historische PDF-Preise bleiben gekennzeichnet. Stadtzentren dienen bei Bedarf als ungefähre Routenpunkte. Wenn keine Straßenroute verfügbar ist, zeigt Ellis eine berechnete Luftlinie an. Entfernungspunkte sind bei gleicher Berechnungsgrundlage vergleichbar. Die Standorttabelle nennt Ort, Quelle und Standorttyp.

Alle berechneten Vergleichsentfernungen verwenden denselben OSRM-Dienst, das Pkw-Profil und denselben Zielpunkt. Firmenstandorte mit unbekanntem Versandort und Lieferorte ohne genaue Straße werden als ungefähre Entfernung mit **ca. … km** angezeigt. Diese gekennzeichneten Straßenrouten können in die Entfernungswertung eingehen. Werte von verschiedenen Routingdiensten oder ungeklärter Berechnungsgrundlage teilen keine Entfernungswertung. Wenn eine genaue Adresse im Geocoder fehlt, kann Ellis ausdrücklich veröffentlichte Koordinaten derselben belegten Adresse mit eigener Quelle verwenden. Fehlende Adress- oder Routennachweise erscheinen mit einem offenen Grund.

Bei Schraubenkatalogen übernimmt Ellis erkannte Artikelzeilen und Abschnittsmerkmale direkt in den Vergleich. Ausgewiesene Verpackungs- und Preiseinheiten werden getrennt gelesen. Ein hochgerechneter Warenwert aus einer datierten Preisliste bleibt beim Listenstand und fließt nicht als aktueller Angebotspreis in die Rangfolge ein.

Mehrere PDFs lassen sich nacheinander am Eingabefeld hinzufügen. Die Dateiprüfung zeigt pro Datei den Status. Der nächste gesendete Chatbeitrag speichert die Anhänge in der Suche. Defekte oder gesperrte Dateien bleiben einzeln entfernbar, während gültige PDFs ausgewertet werden. **Entfernen** wirkt bei gespeicherten Suchen sofort auf zukünftige Antworten. Frühere Antworten behalten ihre Quellen.

Ellis indexiert die Textschicht aller PDF-Seiten und wählt relevante Seiten pro Bedarf und Produkt zur Vertiefung aus. Tabellenzeilen und PDF-Seitennummern bleiben im Quellenbeleg erhalten. **PDFs in dieser Antwort** zeigt, welche Seiten dem Modell vorlagen und welche gekürzt wurden. Bei Seiten ohne Textschicht meldet Ellis, ob `tesseract` und `pdftoppm` lokal erkannt wurden. Die gemeldeten Seiten können separat per OCR oder manuell geprüft werden.

Technische Datenblätter können bereits eine Vorauswahl belegen. Ellis berücksichtigt Artikelzeilen und Stammdatenblöcke auch ohne Preis. Wenn der Hersteller nur grafisch erkennbar ist, kann die Datei als Herkunft des Artikels erscheinen. Für eine Kaufempfehlung prüft Ellis zusätzlich, welche Konditionen belegt sind.

Unter **Gespeicherte Suchen** lässt sich ein Verlauf öffnen und fortsetzen. **Neue Suche** startet einen leeren Chat. Ergänzungen und Korrekturen als neue Nachricht senden. Ellis verwendet die vorhandenen Belege und zeigt die Änderungen in seiner Antwort. Früher gespeicherte Einzelberichte erscheinen als Suchen mit einer Nachricht.

Erklärungsfragen beantwortet Ellis aus den vorhandenen Befunden. Eine kombinierte Nachricht kann eine Erklärung, Korrektur, Neuberechnung und gezielte Nachrecherche anstoßen. Eine reine Erklärung ruft weder das Modell noch die Websuche erneut auf. Bei einer Nachrecherche bleiben Bedarf, Kandidaten und eingestellte Gewichte erhalten.

Der Vergleich bewertet den Materialpreis ohne Versand und die ungefaehre Stadt-zu-Stadt-Entfernung. Belegte Firmenorte reichen aus. Luftlinien und Strassenrouten werden auf getrennten Grundlagen bewertet.

Zum normalen Neustart genügt `powershell -NoProfile -ExecutionPolicy Bypass -File .\start.ps1 -Restart`. Das Windows-Startskript verwendet standardmäßig Photon und OSRM sowie Nominatim als Geocoder-Ersatzdienst. Bei einem eigenen primären Geocoder kann der Ersatzdienst separat gesetzt werden. Die bisherige Option `-OnlineRouting` wird weiterhin akzeptiert. Bei aktiver Websuche erhalten die Dienste die Ortsangaben beziehungsweise Koordinaten. Die öffentlichen Dienste sind für gelegentliche Anfragen gedacht. Eigene Dienste lassen sich über `TRINITY_GEOCODER_URL` (Nominatim-Basis-URL oder Photon-Endpunkt mit `/api`) und `TRINITY_ROUTER_URL` (OSRM-Basis-URL) konfigurieren. Eigene Werte haben Vorrang.

Material oder Produkt pro Position benennen. Bekannte Mengen, Zielorte und technische Anforderungen ergänzen. Der Agent sucht auch bei offenen Angaben und fragt nach den für die Auswahl fehlenden Daten. Technische Spezifikationen und Lieferantenangebote können als PDF angehängt werden. Alternativ lassen sich belegbare Angebotsangaben direkt in das Textfeld schreiben. Die Websuche verwendet DuckDuckGo Lite und bei Bedarf Bing. Sie ruft Trefferseiten ab und startet eine gezielte Nachweisrunde zu offenen Fakten. Die Suchanfragen und Quellen erscheinen im Bericht.

Belege für vergleichbare Angebote sollten beispielsweise so formuliert sein.

- Gesamtpreis netto für 100 Stück, z. B. „100 Stück nach Berlin: Gesamtpreis netto 50,00 EUR inkl. aller Nebenkosten“.
- Warenpreis ohne Versand für 1.000 Stück, z. B. „1.000 Stück: Warenpreis netto 80,00 EUR ohne Versand“. Auch ausdrücklich belegte Netto-Einzelpreise je passender Mengeneinheit können getrennt verglichen werden.
- Lieferzeit in Kalendertagen zum Zielort, z. B. „Lieferzeit nach Berlin: 4 Kalendertage“.
- Belegte Straßenentfernung zum Zielort, z. B. „Straßenentfernung nach Berlin: 80 km“.

Bei Längenware mit belegtem Preisbezug berechnet Ellis die Bestellmenge aus der benötigten Gesamtlänge. Sind mehrere Rollen oder Packungen erlaubt, rundet der Code auf ganze Verkaufseinheiten auf. Ein Preis je Stück einer 6-m-Packung wird dabei von einem Preis je Meter unterschieden. Warenwert, belegter Steuerstatus und Versand bleiben getrennt sichtbar. Beispielsweise ergeben vier Verkaufseinheiten à 6 m zu je 7,25 EUR einen Warenwert von 29,00 EUR für 24 m vor Versand. Enthält eine Verkaufseinheit zwei Rollen à 3 m, bleibt dieser Packungsinhalt als eigener Beleg sichtbar.

Pro Suche sind bis zu fünf aktive PDFs à 8 MiB und sechs Bedarfspositionen vorgesehen. Das gewählte Modell erhält Bedarfstext und extrahierten Quellenkontext. Die Websuche erhält die im Bericht angezeigten Suchanfragen und lässt sich pro Nachricht ausschalten. Quellenabrufe laufen parallel mit Zeitlimit. Bei fehlenden Angebotsdaten prüft Ellis gezielt Preisbezug, technische Nachweise und belegte Standorte.

## Bewertungslogik

Ellis bewertet für neue Antworten ausschließlich **Preis 80 %** und **Entfernung 20 %** als Standard. Beide Gewichte lassen sich pro Suche in ganzen Prozentpunkten einstellen und müssen zusammen 100 % ergeben. Technische Merkmale ordnen ein Produkt dem Bedarf zu. Lieferzeiten bleiben Zusatzinformationen.

Material oder Produkt und Lieferort reichen für eine erste Suche. Fehlende Menge, Legierung oder Abmessungen führen zu einer vorläufigen Auswahl und gezielten Rückfragen. Beispielausführungen erscheinen als Auswahlannahmen. Eine gewünschte, unbestätigte Eigenschaft bleibt offen und kann eine vorläufige Empfehlung mit sichtbarem Prüfhinweis erhalten. Ein belegter Widerspruch erscheint als **abweichende Alternative** mit konkreter Abweichung und wird in der passenden Auswahl nicht bepunktet.

Bei aktiver Websuche und noch unklarer Produktauswahl stellt Ellis vor dem Lieferantenvergleich bis zu zwei kurze Materialfragen im selben Chat. Eine Kurzrecherche prüft konkrete Beispielwerte. Ein eigener Wert ist möglich, „flexibel“ gibt das jeweilige Merkmal frei und „Suche starten“ überspringt weitere Materialfragen. Eine konkrete Anfrage läuft direkt in den Vergleich.

Für häufige Materialfälle prüft die Software offene Merkmale auch dann, wenn das Modell keine strukturierte Rückfrage liefert, etwa Länge und Durchmesser bei Schrauben oder die Legierung bei Aluminiumblechen. Im Vergleich steht zunächst das erste nach Punkten sortierte Angebot jedes Lieferanten. Weitere Varianten können eingeblendet werden.

Bei Schrauben bieten belegte PDF-Artikelzeilen Maße zur Auswahl an. Wenn der Durchmesser feststeht, stammen Längenvorschläge aus Zeilen mit diesem Durchmesser. Eigene Maße und „Flexibel“ sind möglich. Explizite Maße aus Rückfragen fließen in die Produktsuche ein. Ein belegtes nominales Schraubenmaß wie 3,5 × 40 mm wird in Durchmesser und Länge zerlegt und mit den geforderten Achsen verglichen. Bekannte Abweichungen werden von der Punktewertung ausgeschlossen und unter den weiteren Angeboten angezeigt, wenn auch passende oder offene Kandidaten vorliegen.

Die Preise werden der konkreten Variante und Bezugsmenge zugeordnet. Verpackungsgröße und Preiseinheit bleiben getrennt. Bei belegter Menge werden ganze Packungen aufgerundet und der Warenwert berechnet. Ohne Bedarfsmenge können belegte Stück-, Meter- oder Kilogrammpreise verglichen werden. Steuerstatus, Bezugsmenge und zugrunde gelegte Ausführung müssen zusammenpassen. Versandkosten dürfen für einen Warenpreisvergleich offen bleiben. Historische Listenpreise behalten ihren Stand und fließen nicht als aktuelle Preise in die Bewertung ein.

Ellis liest zusätzlich die Verkaufseinheit im Bestellfeld und veröffentlichte Packungsstaffeln im Kaufbereich, wenn der Bezug zur ausgewählten Variante eindeutig ist. Fehlt eine vergleichbare Preisbasis für eine grobe Anfrage, sucht Ellis nach weiteren konkreten Produktseiten mit Preis und Mengeneinheit.

Standardisierte Angebots- und Adressdaten werden direkt aus Produkt- und Kontaktseiten übernommen. Preisbezug und Verpackungsgröße bleiben auch in strukturierten Daten getrennt. Preise in unterschiedlichen Währungen werden separat verglichen. Öffentlich abrufbare Seiten werden bis zu zwei Minuten mit dem ursprünglichen Abrufzeitpunkt wiederverwendet. Angebots- und Standortabfragen beim Modell verwenden gezielte Ausschnitte aus den Originalquellen.

Die Wertung verwendet den niedrigsten vergleichbaren Materialpreis als Preisreferenz. Für die Entfernung gilt dieselbe Kilometerkurve für alle Angebote auf gemeinsamer Grundlage. Gemischte Währungen, technische Ausführungen, historische Preisstände und verschiedene Entfernungsmethoden werden gemeinsam nur bei belegter Vergleichbarkeit gewertet. Werte außerhalb der gewählten Grundlage bleiben sichtbar.

| Kriterium | Standardgewicht | Berechnung |
| --- | ---: | --- |
| Materialpreis ohne Versand | 80 % | Bei mehreren vergleichbaren Lieferanten erhält der niedrigste Preis 90 % des Preisgewichts, bei einem Lieferanten 70 %. Das sind 72 beziehungsweise 56 von 80 Punkten. Die Obergrenze wird durch (1 + (relativer Mehrpreis ÷ 0,5)²) geteilt. Bei 50 % Mehrpreis halbiert sich der jeweilige Ausgangswert. |
| Ungefähre Entfernung | 20 % | 85 % des Entfernungsgewichts ÷ (1 + Kilometer ÷ 2.000). Bei 0 km ergeben sich 17 von 20 Punkten, bei 356,25 km 14,43 und bei 500 km 13,60. |

Die Teilpunkte werden auf zwei Nachkommastellen gerundet und als Summe mit der Summe der anhand der Daten bewertbaren Gewichte angezeigt. Die Gewichte bilden den Nenner. Die jeweiligen Punktedeckel liegen darunter. Ein Angebot ohne Preis zeigt bei 80/20 beispielsweise 14,43 von 20 Punkten. Für die Reihenfolge zählt die erreichte Punktzahl. Ellis empfiehlt das Angebot mit der höchsten Summe vorläufig, wenn relevante Daten offen sind. Bei Punktgleichstand steht die höhere Datenabdeckung zuerst. Gespeicherte Antworten behalten ihre damalige Berechnung. Beim Fortsetzen einer Suche gilt für neue Vergleiche die aktuelle Berechnung. Berichte und PDF-Kopien liegen im Verzeichnis `memory/`.

Bei Marktplätzen wird die Firmenadresse nur einem belegten tatsächlichen Verkäufer zugeordnet. Ein ungeklärter Verkäufer lässt den Preis sichtbar und die Entfernung offen. Eine Plattform- oder Herstelleranschrift ersetzt keinen Verkäufernachweis.

## Tests ausführen

```powershell
.\.venv\Scripts\python.exe -m pip install "pytest>=8,<10"
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe live_test.py --web
.\.venv\Scripts\python.exe live_test.py --partial --url http://127.0.0.1:8765
```

Der Live-Test nutzt die echte Codex-Anmeldung, öffentliche Websuche und ein im Arbeitsspeicher erzeugtes fünfseitiges PDF mit fiktiven Angeboten. Er prüft zwei Materialgruppen, Ausschluss und offene Nachweise, die berechnete Rangfolge, gespeicherte Berichte und Feedback. Ohne `--web` prüft er den Modell- und PDF-Pfad ohne Websuche.

`--partial` prüft Aluminium EN AW-5754 mit offenen Maßen und SPAX-Schrauben mit offenem Zielort. `--url` führt den Modellaufruf über einen bereits gestarteten Server aus und speichert die Testberichte in dessen SQLite-Datenbank. Ohne `--url` wird ein temporäres Gedächtnis verwendet.


## Vereinfachter Vergleich
Bewertet werden ausschließlich Materialpreis ohne Versand (Standard 80 %) und ungefähre Entfernung (20 %). Versandkosten sind keine Bewertungsvoraussetzung. Die Bestellmenge wird auf belegte Verpackungseinheiten aufgerundet; Preisbasis und Verpackungseinheit werden getrennt behandelt. Datierte Listenpreise bilden eine ausdrücklich historische Vergleichsgruppe mit eigenem Listenstand und werden nicht mit aktuellen Preisen gleichgesetzt.
Eine belegte Firmenstadt reicht für die Geokodierung. Die ungefähre Route wird ab Stadtzentrum berechnet; bei fehlendem Straßenrouting erfolgt eine gesondert gekennzeichnete Haversine-Luftlinie. Unterschiedliche Entfernungsmethoden werden nicht gemeinsam bepunktet. Der Firmenstandort ist kein bestätigter Versandstandort.


## Geokodierung und Entfernung

Ellis verarbeitet Stadt, PLZ mit Stadt und vollständige Anschriften. Adress-, PLZ- und Stadtauflösung bleiben im Routenbeleg unterscheidbar. Wenn eine Adresse keine eindeutige Hausnummer liefert, versucht Ellis eine belegte Ortsangabe mit vorhandenem PLZ-, Regions- oder Landeskontext. Mehrere nahe Kartenobjekte desselben Orts können einen gemeinsamen Treffer bilden. Bei ungeklärter Gleichnamigkeit fragt Ellis nach Land, Region oder PLZ.

`TRINITY_DEFAULT_COUNTRY` ist standardmäßig `DE` und dient nur zur Auswahl unter Treffern in verschiedenen Ländern. Ein mitgelieferter PLZ-, Länder- oder Regionskontext hat Vorrang. Ein leerer Wert deaktiviert die Länderannahme.

`TRINITY_GEOCODER_URL` wählt den primären Dienst. `TRINITY_GEOCODER_FALLBACK_URL` kann einen alternativen Photon- oder Nominatim-kompatiblen Dienst angeben. Öffentliche Geodienste eignen sich für gelegentliche, manuell gestartete Suchen. Der öffentliche Nominatim-Dienst ist optional und auf höchstens eine Anfrage pro Sekunde beschränkt. Für regelmäßige Nutzung einen eigenen oder vertraglich geeigneten Endpunkt konfigurieren. [Nominatim-Nutzungsregeln](https://operations.osmfoundation.org/policies/nominatim/) · [Photon-Dokumentation](https://github.com/komoot/photon#demo-server).

Erfolgreiche Treffer werden sieben Tage lokal in `memory/geocodes.sqlite3` gespeichert. Ein Lauf teilt Zielkoordinaten zwischen den Lieferanten und fragt einen temporär fehlgeschlagenen Treffer im nächsten Lauf erneut ab. Straßenkilometer und Luftlinie bilden getrennte Bewertungsgrundlagen. Im Bericht stehen OpenStreetMap-Quelle, Standorttyp und Routenmethode.
