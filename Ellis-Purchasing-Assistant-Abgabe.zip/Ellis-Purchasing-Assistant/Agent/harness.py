from run_metrics import timed, measured_run
"""Model adapters for the local Codex CLI and Chat Completions."""
import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from tempfile import TemporaryDirectory
from urllib.parse import urlsplit

import httpx
from pydantic import ValidationError


class ModelError(RuntimeError):
    pass


def codex_executable():
    return os.environ.get("TRINITY_CODEX_EXE") or shutil.which("codex.exe") or shutil.which("codex")


CODEX_STATUS = {
    "missing": "Codex nicht gefunden. Prüfen Sie die Installation oder TRINITY_CODEX_EXE.",
    "start_failed": "Codex konnte nicht gestartet werden. Prüfen Sie den Programmpfad.",
    "signed_out": "Codex gefunden, aber nicht angemeldet. Melden Sie sich in Codex an.",
    "ready": "Codex gefunden und angemeldet.",
    "unknown": "Codex gefunden. Der Anmeldestatus konnte nicht geprüft werden.",
}


def codex_status():
    exe = codex_executable()
    if not exe:
        return "missing"
    try:
        result = subprocess.run([exe, "login", "status"], capture_output=True, encoding="utf-8",
                                errors="replace", timeout=5, check=False)
    except OSError:
        return "start_failed"
    except subprocess.TimeoutExpired:
        return "unknown"
    if result.returncode == 0:
        return "ready"
    output = (result.stdout + "\n" + result.stderr).casefold()
    return "signed_out" if "not logged in" in output else "unknown"


class Harness:
    def __init__(self, backend, model, base_url, api_key):
        self.backend = backend
        self.model = model
        self.resolved_model = model or "Codex-Standard"
        self.base_url = base_url
        self.api_key = api_key

    @timed("model")
    def ask(self, system, task, payload, contract):
        instructions = system + "\n\nAufgabe:\n" + task
        content = json.dumps(payload, ensure_ascii=False)
        schema = contract.model_json_schema()
        if contract.__name__ == "Offers":
            schema["properties"]["offers"]["maxItems"] = 4
            schema.get("$defs",{}).get("Offer",{}).get("properties",{}).get("facts",{})["maxItems"] = 10
        from run_metrics import active
        collector = active.get()
        request_info = {"contract":contract.__name__,"input_characters":len(instructions)+len(content),
                        "sources":[{"id":s.get("id"),"characters":len(s.get("text",""))} for s in payload.get("sources",[])]}
        if collector is not None:
            collector.setdefault("model",{"seconds":0.0,"calls":0,"requests":[]}).setdefault("requests",[]).append(request_info)
        pending = [schema]
        while pending:
            item = pending.pop()
            if isinstance(item, dict):
                item.pop("default", None)
                if item.get("type") == "object" and "properties" in item:
                    item["required"] = list(item["properties"])
                pending.extend(item.values())
            elif isinstance(item, list):
                pending.extend(item)
        try:
            if self.backend == "codex":
                raw = self._codex(instructions + "\n\nDatensatz (JSON):\n" + content, schema)
            else:
                raw = self._chat(instructions, content, schema)
            request_info["output_characters"] = len(raw)
            return contract.model_validate_json(raw)
        except ValidationError as exc:
            fields = ", ".join(".".join(map(str, error["loc"])) or "JSON" for error in exc.errors()[:5])
            raise ModelError(f"Modellantwort entspricht dem erwarteten Format nicht ({fields}).") from exc

    def _codex(self, prompt, schema):
        exe = codex_executable()
        if not exe:
            raise ModelError(CODEX_STATUS["missing"])
        with TemporaryDirectory(prefix="trinity-model-") as folder:
            directory = Path(folder)
            schema_path = directory / "schema.json"
            answer = directory / "answer.json"
            schema_path.write_text(json.dumps(schema), encoding="utf-8")
            args = [
                exe, "-a", "never", "exec", "--ignore-user-config", "--ephemeral",
                "--skip-git-repo-check", "--sandbox", "read-only", "--color", "never",
                "--output-schema", str(schema_path), "--output-last-message", str(answer),
            ]
            if self.model:
                args.extend(["--model", self.model])
            effort = os.getenv("TRINITY_REASONING_EFFORT","low")
            if effort in {"low","medium","high","xhigh"}:
                args.extend(["-c", f'model_reasoning_effort="{effort}"'])
            args.append("-")
            try:
                result = subprocess.run(args, cwd=folder, input=prompt, capture_output=True,
                                        encoding="utf-8", errors="replace", timeout=150, check=False)
            except subprocess.TimeoutExpired as exc:
                raise ModelError("Codex hat das Zeitlimit von 150 Sekunden überschritten.") from exc
            except OSError as exc:
                raise ModelError(CODEX_STATUS["start_failed"]) from exc
            if result.returncode or not answer.is_file():
                # Extract only generic diagnostics. Codex also echoes the confidential input on stderr.
                diagnostics = result.stderr.casefold()
                if "not logged in" in diagnostics:
                    raise ModelError(CODEX_STATUS["signed_out"])
                if any(term in diagnostics for term in ("401", "unauthorized", "not logged in", "refresh token")):
                    raise ModelError("Codex-Anmeldung prüfen: 'codex login status', gegebenenfalls 'codex login'.")
                if any(term in diagnostics for term in ("usage limit", "rate limit", "429")):
                    raise ModelError("Codex meldet ein Nutzungs- oder Ratenlimit.")
                raise ModelError("Codex konnte keine strukturierte Antwort liefern. Prüfen Sie Modell und Anmeldung.")
            match = re.search(r"^model: ([\w.-]+)\s*$", result.stderr, re.MULTILINE)
            if match:
                self.resolved_model = match[1]
            return answer.read_text(encoding="utf-8-sig")

    def _chat(self, instructions, content, schema):
        if not self.model:
            raise ModelError("Für Chat Completions wird ein Modellname benötigt.")
        try:
            parsed = urlsplit(self.base_url)
            safe = (parsed.scheme == "https" or
                    (parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1", "::1"}))
            if not safe or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
                raise ModelError("Base-URL benötigt HTTPS oder einen lokalen Loopback-Endpunkt.")
            key = self.api_key
            if not key and parsed.hostname == "api.openai.com":
                key = os.environ.get("OPENAI_API_KEY", "")
            headers = {"Authorization": f"Bearer {key}"} if key else {}
            prompt = instructions + "\nGib ausschließlich ein JSON-Objekt nach diesem Schema zurück:\n" + json.dumps(schema)
            response = httpx.post(self.base_url.rstrip("/") + "/chat/completions", headers=headers,
                                  timeout=120, follow_redirects=False, trust_env=False, json={
                                      "model": self.model,
                                      "messages": [{"role": "system", "content": prompt},
                                                   {"role": "user", "content": content}],
                                  })
            response.raise_for_status()
            return response.json()["choices"][0]["message"]["content"]
        except httpx.HTTPStatusError as exc:
            raise ModelError(f"Chat-Endpunkt antwortet mit HTTP {exc.response.status_code}. Prüfen Sie Modell und Zugang.") from exc
        except (httpx.HTTPError, KeyError, IndexError, TypeError, ValueError) as exc:
            raise ModelError("Chat-Endpunkt nicht erreichbar oder Antwortformat ungültig.") from exc
