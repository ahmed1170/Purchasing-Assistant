"""Validated model contracts and deterministic purchasing decisions."""
import os
import re
from urllib.parse import urlsplit
from decimal import Decimal, InvalidOperation, ROUND_CEILING
from itertools import combinations
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Contract(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class Weights(Contract):
    total_price: int = Field(ge=0, le=100)
    distance_km: int = Field(ge=0, le=100)

    @model_validator(mode="after")
    def total(self):
        if sum(self.model_dump().values()) != 100:
            raise ValueError("Die Summe der Gewichte muss 100 % betragen.")
        return self


class Evidence(Contract):
    source_id: str
    quote: str


class Criterion(Contract):
    field: str
    operator: Literal["eq", "contains", "gte", "lte"]
    target: str
    unit: str
    evidence: Evidence


class Position(Contract):
    name: str
    material_group: str
    quantity: str
    quantity_unit: str
    destination: str
    scope_evidence: Evidence
    destination_evidence: Evidence
    must: list[Criterion]
    quality: list[Criterion]
    search_query: str
    questions: list[str]
    assumptions: list[str] = Field(default_factory=list)


class OrderPosition(Position):
    whole_packs_allowed: bool = False


class MaterialQuestion(Contract):
    position: int = Field(ge=1)
    field: str = Field(min_length=1, max_length=65)
    options: list[str] = Field(min_length=2, max_length=4)


class Scope(Contract):
    positions: list[Position]
    questions: list[str]
    material_question: MaterialQuestion | None = None


class Fact(Contract):
    field: str
    value: str
    unit: str
    evidence: Evidence


class Offer(Contract):
    supplier: str
    product: str
    identity: Evidence
    facts: list[Fact]
    marketplace: str = ""


class Offers(Contract):
    offers: list[Offer]


class DocumentFinding(Contract):
    field: str
    value: str
    variant: str
    evidence: Evidence


class DocumentOffers(Offers):
    findings: list[DocumentFinding]


METRICS = {
    "total_price": "Gesamtpreis netto inkl. Nebenkosten",
    "net_price": "Warenpreis netto ohne Versand",
    "unit_net_price": "Netto-Einzelpreis ohne Versand",
    "gross_goods_price": "Warenwert brutto vor Versand",
    "unit_gross_price": "Bruttopreis je Bezugsmenge ohne Versand",
    "gross_total_price": "Bestellpreis brutto inkl. Versand",
    "delivery_days": "Lieferzeit in Tagen",
    "distance_km": "Straßenentfernung in km",
}
UNITS = {"total_price": "EUR", "net_price": "EUR", "unit_net_price": "EUR", "delivery_days": "d", "distance_km": "km"}
PRICE_BASIS = ("total_price", "gross_total_price", "net_price", "gross_goods_price", "unit_net_price", "unit_gross_price")


def normalize(text):
    return " ".join(text.translate(str.maketrans({"‐":"-", "‑":"-", "−":"-"})).split()).casefold()


def literal_in(value, quote):
    value = normalize(value)
    if not value:
        return False
    # A value of 20 must never match 200, A20 or the 20 in 20,5.
    for match in re.finditer(r"(?<!\w)" + re.escape(value) + r"(?!\w)", normalize(quote)):
        text = match.string
        start, end = match.span()
        if value[0].isdigit() and start and text[start - 1] in "-−":
            continue
        if value[0].isdigit() and start > 1 and text[start - 1] in ".," and text[start - 2].isdigit():
            continue
        if value[-1].isdigit() and end + 1 < len(text) and text[end] in ".," and text[end + 1].isdigit():
            continue
        return True
    return False


def grounded(evidence, sources, *values, min_length=5):
    source = sources.get(evidence.source_id)
    return (
        source is not None
        and source["kind"] != "search"
        and min_length <= len(normalize(evidence.quote)) <= 700
        and normalize(evidence.quote) in normalize(source["text"])
        and all(literal_in(value, evidence.quote) for value in values)
    )


def offer_grounded(offer, sources):
    if grounded(offer.identity, sources, offer.supplier, offer.product):
        return True
    page = sources.get(offer.identity.source_id,{})
    if (page.get("kind") == "web" and not marketplace_name(offer,sources)
            and grounded(offer.identity,sources,offer.product) and literal_in(offer.supplier,page["text"])):
        return True
    seller = next((fact for fact in offer.facts if fact.field == "actual_seller"
                   and normalize(fact.value) == normalize(offer.supplier)),None)
    if (seller and grounded(offer.identity,sources,offer.product) and check_fact(seller,sources)
            and seller.evidence.source_id == offer.identity.source_id
            and re.search(r"verkauf durch|verkauf & versand|verkäufer|seller",normalize(seller.evidence.quote))):
        return True
    origin = sources.get(offer.identity.source_id)
    return bool(origin and origin["kind"] == "pdf" and origin.get("path") and grounded(offer.identity, sources, offer.product)
                and (offer.supplier == origin["title"] or any(
                    source.get("path") == origin["path"] and literal_in(offer.supplier, source["text"])
                    for source in sources.values())))


def number(value):
    value = value.strip()
    if re.fullmatch(r"-?\d{1,3}(?:\.\d{3})+,\d+", value):
        value = value.replace(".", "")
    elif re.fullmatch(r"-?\d{1,3}(?:,\d{3})+\.\d+", value):
        value = value.replace(",", "")
    elif re.fullmatch(r"-?\d+[.,]\d{3}", value):
        return None  # Ambiguous decimal versus thousands separator.
    if not re.fullmatch(r"-?\d{1,14}(?:[.,]\d{1,8})?", value):
        return None
    try:
        return Decimal(value.replace(",", "."))
    except InvalidOperation:
        return None


def quantity_number(value):
    # Quantities use German thousands grouping. Other numeric fields retain
    # the existing ambiguity check for a single separator and three digits.
    value = value.strip()
    if re.fullmatch(r"\d{1,3}(?:\.\d{3})+", value):
        value = value.replace(".", "")
    return number(value)


def criterion_usable(criterion, sources):
    unit = normalize(criterion.unit)
    if unit in LENGTH_UNITS and number(criterion.target) is not None:
        target = re.escape(normalize(criterion.target.strip()))
        if (criterion.field.strip() and grounded(criterion.evidence,sources,min_length=3)
                and re.search(rf"(?<![\w.,]){target}\s*{unit}(?!\w)",normalize(criterion.evidence.quote))):
            return True
    values = [criterion.target]
    if criterion.unit:
        values.append(criterion.unit)
    short_code = re.fullmatch(r"(?:[A-Za-z]{1,4}[- ]?\d{1,3}|TX|PH|PZ)", criterion.target, re.I)
    source = sources.get(criterion.evidence.source_id, {})
    return (
        bool(criterion.field.strip())
        and grounded(criterion.evidence, sources, *values, min_length=2 if short_code else 5)
        and (not short_code or literal_in(criterion.evidence.quote, source.get("text", "")))
        and (criterion.operator not in {"gte", "lte"} or number(criterion.target) is not None)
    )


def check_fact(fact, sources):
    values = [fact.value]
    unit_literals = {"EUR": ("EUR", "€"), "USD": ("USD", "$"), "GBP": ("GBP", "£"),
                     "d": ("Tage", "Tagen", "Kalendertage", "Kalendertagen", "Tag", "days", "day", "d"), "km": ("km",)}
    if fact.unit:
        units = unit_literals.get(fact.unit, (fact.unit,))
        tight_measure = normalize(fact.unit) in LENGTH_UNITS and re.search(
            r"(?<![\w.,])" + re.escape(normalize(fact.value)) + re.escape(normalize(fact.unit)) + r"\b",
            normalize(fact.evidence.quote))
        if normalize(fact.unit) == "zoll":
            tight_measure = re.search(r'(?<![\w.,/])' + re.escape(fact.value) + r'\s*["″]', fact.evidence.quote)
        if not tight_measure and not any(literal_in(unit, fact.evidence.quote) for unit in units):
            return False
        if tight_measure:
            return grounded(fact.evidence, sources)
    return grounded(fact.evidence, sources, *values)


DIMENSION_LABELS = {"abmessung","abmessungen","maße","masse","größe","format"}


def dimension_values(value):
    text = normalize(value.strip())
    parts = re.split(r"\s*[x×]\s*",text)
    if len(parts) not in {2,3} or any(not re.fullmatch(r"\d+(?:[.,]\d+)?(?:\s*mm)?",part) for part in parts):
        return None
    values = tuple(number(part.removesuffix("mm").strip()) for part in parts)
    return values if all(value is not None for value in values) else None


LENGTH_UNITS = {"mm":Decimal("1"),"cm":Decimal("10"),"m":Decimal("1000")}
AXIS_FIELDS = (r"(?:(?:schrauben|nenn|gewinde|gesamt)[ -]?)?durchmesser|(?:nominal |thread )?diameter",
               r"(?:(?:schrauben|gesamt|nenn|produkt)[ -]?)?länge|(?:overall |nominal )?length")


def nominal_axis(field):
    return next((i for i,pattern in enumerate(AXIS_FIELDS) if re.fullmatch(pattern,normalize(field))),None)


def screw_title_measurement(offer, criterion, sources):
    axis = nominal_axis(criterion.field)
    if not re.search(r"schraube|screw|bolt|gewindestange",normalize(offer.product)):
        return None,None
    match = re.search(r"(?<![\w.,])M?((\d+(?:[.,]\d+)?)\s*[x×]\s*(\d+(?:[.,]\d+)?))\s*(mm|cm|m)\b",
                      offer.product,re.I)
    if not match or not grounded(offer.identity,sources,match[0]):
        return None,None
    if axis is None and not dimension_values(criterion.target):
        return None,None
    evidence = Fact(field="Maße",value=match[0],unit=match[4],evidence=offer.identity)
    if axis is not None:
        return compare(criterion,evidence.model_copy(update={"value":match[axis+2]})),evidence
    # A screw's two nominal dimensions have the order diameter × length.
    requested = dimension_values(criterion.target)
    target_unit = LENGTH_UNITS.get(normalize(criterion.unit) or "mm")
    if len(requested) != 2 or not target_unit or criterion.operator not in {"eq","contains"}:
        return None,None
    actual = (number(match[2]),number(match[3]))
    if None in actual:
        return None,None
    return (tuple(value * target_unit for value in requested)
            == tuple(value * LENGTH_UNITS[match[4].lower()] for value in actual)),evidence


def title_standard(offer, criterion, sources):
    if not re.search(r"norm|standard", normalize(criterion.field)):
        return None, None
    pattern = r"\b(?:DIN(?:\s+EN)?(?:\s+ISO)?|EN(?:\s+ISO)?|ISO|ASTM)\s*[A-Z]?\s*\d+(?:-\d+)*\b"
    requested = re.findall(pattern, criterion.target, re.I)
    published = re.findall(pattern, offer.product, re.I)
    if len(requested) != 1 or len(published) != 1 or not grounded(offer.identity, sources, published[0]):
        return None, None
    key = lambda value: re.sub(r"\s+", "", value).casefold()
    expected, actual = map(key, (requested[0], published[0]))
    if re.match(r"[a-z]+", expected)[0] != re.match(r"[a-z]+", actual)[0]:
        return None, None
    # A family designation and a particular part are not direct contradictions.
    if expected.startswith(actual + "-") or actual.startswith(expected + "-"):
        return None, None
    return expected == actual, Fact(field=criterion.field,value=published[0],unit="",evidence=offer.identity)


def compare(criterion, fact):
    if fact is None:
        return None
    target_unit,actual_unit = normalize(criterion.unit),normalize(fact.unit)
    field = normalize(criterion.field)
    if re.search(r"^anschluss(?:mass|grösse|durchmesser)", field) and criterion.operator == "eq":
        required = dimension_values(re.sub(r"\bauf\b", "x", criterion.target, flags=re.I))
        measured = dimension_values(fact.value)
        if required and measured and target_unit == "mm" and (actual_unit == "mm" or normalize(fact.value).endswith("mm")):
            return required == measured
    if target_unit != actual_unit:
        if target_unit not in LENGTH_UNITS or actual_unit not in LENGTH_UNITS:
            return None
        target,actual = number(criterion.target),number(fact.value)
        if target is None or actual is None:
            return None
        target *= LENGTH_UNITS[target_unit]
        actual *= LENGTH_UNITS[actual_unit]
        return {"eq":actual==target,"contains":actual==target,"gte":actual>=target,"lte":actual<=target}[criterion.operator]
    expected, actual = normalize(criterion.target), normalize(fact.value)
    if field in {"baureihe", "serie", "modellreihe"} and criterion.operator in {"eq", "contains"}:
        expected = expected.replace("®", "").replace("™", "")
        actual = actual.replace("®", "").replace("™", "")
    is_model_code = field == "produkttyp" and re.fullmatch(r"[a-z]{2,}[- ]+[a-z0-9]+(?:[-/ ]+[a-z0-9]+){1,4}", expected)
    if (field in {"typbezeichnung", "modellbezeichnung", "artikelnummer", "sku"} or is_model_code) and criterion.operator == "eq":
        if re.search(r"\d", expected) and re.search(r"\d", actual):
            return re.sub(r"[\s-]+", "", expected) == re.sub(r"[\s-]+", "", actual)
    if re.search(r"oberfläche|beschichtung|finish|coating", normalize(criterion.field)) and criterion.operator in {"eq", "contains"}:
        if re.fullmatch(r"verzinkt(?:e[snmr]?)?", expected):
            if re.search(r"\b(?:nicht|un)verzinkt\b|\b(?:nicht\s+verzinkt|blank|unbeschichtet)\b", actual):
                return False
            return True if re.search(r"verzinkt|verzinkung", actual) else None
    if normalize(criterion.field) in {"norm", "standard", "produktnorm"} and criterion.operator in {"eq", "contains"}:
        pattern = r"\b(?:DIN(?:\s+EN)?(?:\s+ISO)?|EN(?:\s+ISO)?|ISO|ASTM)\s*[A-Z]?\s*\d+(?:-\d+)*\b"
        if re.fullmatch(pattern, expected, re.I):
            compact = re.sub(r"\s", "", expected)
            listed = {re.sub(r"\s", "", match) for match in re.findall(pattern, actual, re.I)}
            return True if compact in listed else None
    if normalize(criterion.field) in {"farbe", "farbton", "color", "colour"} and criterion.operator in {"eq", "contains"}:
        actual = re.sub(r"\s+\([a-z]{1,4}\)$", "", actual)
        base, inflected = sorted((expected, actual), key=len)
        if re.fullmatch(r"[^\W\d_]{3,}", base) and inflected.startswith(base) and inflected[len(base):] in {
                "e", "en", "em", "er", "es"}:
            return True
    if normalize(criterion.field) in {"produktart","produkttyp","schraubenart","materialgruppe","produktform","mutternform"}:
        def terms(text):
            return {word[:-2] if word.endswith("ungen") else
                    word.removesuffix("n") if word.endswith(("en", "ern")) else word for word in
                    re.findall(r"[^\W\d_]+",text)}
        return True if terms(expected) and terms(expected) <= terms(actual) else None
    target_alloy = re.search(r"\ben\s*[- ]?\s*aw\s*[- ]?\s*(\d{4})\b",expected)
    if target_alloy:
        actual_alloy = re.search(r"\ben\s*[- ]?\s*aw\s*[- ]?\s*(\d{4})\b",actual)
        return target_alloy[1] == actual_alloy[1] if actual_alloy else None
    if "antrieb" in normalize(criterion.field):
        expected_tx = re.search(r"\b(?:tx|torx|innensechsrund)\s*[- ]?(?:antrieb\s*)?(\d+)?",expected)
        actual_tx = re.search(r"\b(?:tx|torx|innensechsrund)\s*[- ]?(?:antrieb\s*)?(\d+)?",actual)
        if expected_tx:
            if actual_tx:
                return (expected_tx[1] == actual_tx[1] if expected_tx[1] and actual_tx[1]
                        else None if expected_tx[1] else True)
            return False if re.search(r"\b(?:pz|ph|pozidriv|kreuzschlitz|schlitz)\b",actual) else None
    target_size = dimension_values(expected)
    if target_size and criterion.operator in {"eq", "contains"}:
        actual_size = dimension_values(actual)
        if not actual_size:
            return None
        if normalize(criterion.field) in DIMENSION_LABELS:
            return sorted(target_size) == sorted(actual_size)
        return target_size == actual_size
    if criterion.operator in {"eq", "contains"}:
        if re.fullmatch(r"selbstklebend(?:e[smnr]?)?", expected):
            if re.search(r"nicht[- ]selbstklebend|ohne klebeschicht", actual):
                return False
            return True if re.search(r"\bselbstklebend(?:e[smnr]?)?\b", actual) else None
        for pattern in (r"\b(?:epdm|pvc|tpe|silikon|nbr)(?=\b)", r"\b([a-z])[- ]?profil\b"):
            target = re.findall(pattern, expected)
            if target:
                if re.search(r"\bnicht\b|\bohne\b", actual) and literal_in(target[0], actual):
                    return False
                known = set(re.findall(pattern, actual))
                if pattern.endswith("profil\\b") and re.fullmatch(r"[a-z]", actual) and "profil" in normalize(criterion.field):
                    known = {actual}
                return target[0] in known if len(known) == 1 else None
    if criterion.operator == "contains":
        if re.search(r"\b(?:kein\w*|nicht|ohne|no|not|without)\b", actual):
            return False
        return literal_in(expected, actual)
    if criterion.operator == "eq":
        a, b = number(actual), number(expected)
        if a is not None and b is not None:
            return a == b
        return re.sub(r"schrauben\b", "schraube", actual) == re.sub(r"schrauben\b", "schraube", expected)
    a, b = number(actual), number(expected)
    if a is None or b is None:
        return None
    return a >= b if criterion.operator == "gte" else a <= b


def select_facts(facts, sources):
    """Resolve exact duplicates and leave conflicting field values open."""
    groups = {}
    for fact in facts:
        if check_fact(fact, sources):
            key = (normalize(fact.value), normalize(fact.unit))
            numeric = number(fact.value)
            if numeric is not None:
                key = (numeric, key[1])
            elif normalize(fact.field) in DIMENSION_LABELS:
                dimensions = dimension_values(fact.value)
                if dimensions:
                    key = (tuple(sorted(dimensions)),key[1])
            group = groups.setdefault(fact.field, {})
            if fact.field == "listed_price" and key in group:
                signals = r"inkl\.|mwst|netto|brutto|pro\s+|\bje\s+|/\s*(?:st|m|rolle)"
                def evidence_quality(quote):
                    text = normalize(quote)
                    return bool(re.search(r"steuerstatus: (?:brutto|netto)\b",text)),len(re.findall(signals,text))
                if evidence_quality(fact.evidence.quote) < evidence_quality(group[key].evidence.quote):
                    continue
            group[key] = fact
    return {field: next(iter(values.values())) for field, values in groups.items() if len(values) == 1}


def comparable(key, fact, position):
    if fact is None or fact.unit != UNITS.get(key):
        return False
    quote = normalize(fact.evidence.quote)
    if key in PRICE_BASIS:
        qty = quantity_number(position.quantity)
        quantities = [position.quantity, format(qty.normalize(), "f")] if qty and qty > 0 else []
        if quantities and qty == qty.to_integral_value():
            quantities.append(f"{int(qty):,}".replace(",", "."))
        named_unit = normalize(position.quantity_unit)
        unit = (r"(?:stück|stk|"+ re.escape(named_unit) + r")" if re.fullmatch(r"[\w-]*schrauben?", named_unit)
                else re.escape(named_unit))
        amount = re.escape(normalize(fact.value))
        if not literal_in("netto", quote) or not re.search(r"(?<![\w.,])" + amount + r"\s*(?:eur\b|€)", quote):
            return False
        excludes_shipping = re.search(r"(?:ohne|zzgl\.?|zuzüglich|exkl\.?)\s+(?:der\s+)?versand(?:kosten)?", quote)
        if key == "unit_net_price":
            return bool(unit and excludes_shipping and re.search(r"(?:\bpro\s+|\bje\s+|/\s*)" + unit + r"(?!\w)", quote))
        quantity_matches = unit and any(re.search(r"(?<![\w.,])" + re.escape(value) + r"\s+" + unit + r"(?!\w)", quote)
                                       for value in quantities)
        if not quantity_matches:
            return False
        if key == "net_price":
            return bool(re.search(r"warenpreis|warenwert|zwischensumme|gesamtpreis|gesamtbetrag", quote)
                        and excludes_shipping)
        return bool(literal_in(position.destination, quote)
                    and re.search(r"gesamtpreis|gesamtbetrag|gesamt netto", quote)
                    and re.search(r"inkl\.?\s+(?:aller\s+)?(?:nebenkosten|zusatzkosten|versandkosten)|keine (?:nebenkosten|zusatzkosten)", quote)
                    and not excludes_shipping)
    if key == "delivery_days":
        return (
            literal_in(position.destination, quote)
            and bool(re.search(r"\bkalendertag(?:e|en)?\b", quote))
            and bool(re.search(r"\blieferzeit\b|\blieferung\b", quote))
        )
    return literal_in(position.destination, quote) and bool(re.search(r"strassenentfernung|fahrstrecke", quote))


def listed_offer(offer, facts, position):
    """Calculate only from an explicitly priced unit/pack and delivery terms."""
    price = facts.get("listed_price")
    if not price:
        return {}, None
    quote = normalize(price.evidence.quote)
    currency = {"EUR": r"(?:eur\b|€)", "USD": r"(?:usd\b|\$)", "GBP": r"(?:gbp\b|£)"}.get(price.unit)
    amount = number(price.value)
    amount_match = re.search(r"(?<![\w.,])" + re.escape(price.value) + r"\s*" + currency, quote) if currency else None
    if amount is None or amount <= 0 or not amount_match or not literal_in(offer.product, price.evidence.quote):
        return {}, None
    if re.search(r"(?:\b(?:ab|from)\s*|\d\s*[-–]\s*)$", quote[:amount_match.start()]):
        return {}, None
    tax = "brutto" if re.search(r"brutto|(?:inkl\.?|mit)\s*(?:der\s+)?(?:mwst|ust)", quote) else (
        "netto" if re.search(r"\bnetto\b|(?:exkl\.?|zzgl\.?)\s*(?:mwst|ust)", quote) else "offen")
    pack = re.search(r"(\d{1,6})\s*(?:stück|stk\.?)\s*(?:pro|je|/)\s*(?:packung|pack|karton)", quote)
    if not pack and re.search(r"(?:pro|je|/)\s*pack\b|preis der variante|regulärer preis|inhalt", quote):
        pack = re.search(r"\b(\d{1,6})\s*stück(?:\s+pro\s+packung)?$", normalize(offer.product))
    per_unit = re.match(r"\s*(?:(?:netto|brutto)\s+)?(?:pro\s+|je\s+|/\s*)(?:1\s+)?stück\b",
                        quote[amount_match.end():])
    pack_size = 1 if per_unit else int(pack[1]) if pack else None
    info = {"value": float(amount), "raw": price.value, "currency": price.unit, "pack_size": pack_size,
            "tax": tax, "evidence": price.evidence.model_dump()}
    qty = quantity_number(position.quantity)
    if normalize(position.quantity_unit) in {"m", "meter", "metern"}:
        return length_price(info, offer.product, quote, amount_match.end(), position, qty, amount, price,
                            facts.get("shipping_cost"))
    if (price.unit != "EUR" or tax != "netto" or not pack_size or normalize(position.quantity_unit) not in {"stück", "stk"}
            or qty is None or qty <= 0 or qty != qty.to_integral_value()):
        return info, None
    packs = (int(qty) + pack_size - 1) // pack_size
    subtotal = amount * packs
    # Extra units or quantity tiers may change the commercial comparison.
    if packs * pack_size != qty:
        info["order_note"] = f"Nur ganze Packungen: {packs} × {pack_size} = {packs * pack_size} Stück."
        return info, None
    if not re.search(r"(?:ohne|zzgl\.?|zuzüglich|exkl\.?)\s+(?:der\s+)?versand", quote):
        return info, None
    metrics = {"net_price": {"value": float(subtotal), "fact": price.model_dump(),
                             "calculation": f"{packs} × {amount} EUR netto ohne Versand für {int(qty)} Stück"}}
    shipping = facts.get("shipping_cost")
    if shipping and position.destination and shipping.unit == "EUR":
        freight = number(shipping.value)
        freight_quote = normalize(shipping.evidence.quote)
        if (freight is not None and freight >= 0 and literal_in(position.destination, freight_quote)
                and literal_in(offer.product, freight_quote) and literal_in(position.quantity, freight_quote)
                and re.search(r"versandkosten.*netto|netto.*versandkosten", freight_quote)
                and re.search(r"keine (?:weiteren )?(?:neben|zusatz)kosten", freight_quote)
                and re.search(r"(?<![\w.,])" + re.escape(shipping.value) + r"\s*(?:eur\b|€)", freight_quote)):
            metrics["total_price"] = {"value": float(subtotal + freight), "fact": shipping.model_dump(),
                                      "calculation": f"{packs} × {amount} EUR + {freight} EUR Versand netto"}
    return info, metrics


def length_price(info, product, quote, price_end, position, quantity, amount, price, shipping):
    """A metre price and a price for a packaged length use different order units."""
    per_metre = re.match(r"\s*\*?\s*(?:pro\s+|je\s+|/\s*)(?:1\s+)?(?:m\b|meter\b)", quote[price_end:])
    unit = re.search(r"(?:pro\s+|je\s+|/\s*)(rolle|st(?:ück|k)?\b|packung)", quote)
    length = re.search(r"\b(\d+(?:[.,]\d+)?)\s*m(?:eter)?\b", normalize(product))
    size = Decimal(1) if per_metre else quantity_number(length[1]) if unit and length else None
    if not size or size <= 0:
        return info, None
    label = ("m" if per_metre else "Rolle" if unit[1] == "rolle" or re.search(r"\brolle\b", quote)
             else "Packung" if unit[1] == "packung" else "Stück")
    info["price_basis"] = label if per_metre else f"{label} à {size:g} m"
    if not quantity or quantity <= 0:
        return info, None
    packs = quantity if per_metre else (quantity / size).to_integral_value(rounding=ROUND_CEILING)
    if not per_metre and packs > 1 and not getattr(position, "whole_packs_allowed", False):
        return info, None
    subtotal = amount * packs
    info.update(order_quantity=float(packs), order_unit=label, supplied_length=float(size * packs),
                goods_value=float(subtotal),
                calculation=f"{packs:g} × {amount:.2f} {price.unit} = {subtotal:.2f} {price.unit} vor Versand.")
    if price.unit == "EUR" and info["tax"] in {"netto", "brutto"}:
        key = "net_price" if info["tax"] == "netto" else "gross_goods_price"
        metrics = {key: {"value": float(subtotal), "fact": price.model_dump(), "calculation": info["calculation"]}}
        if shipping and shipping.unit == price.unit and position.destination:
            freight = number(shipping.value)
            terms = normalize(shipping.evidence.quote)
            order = re.escape(f"{packs:g}") + r"\s+" + (r"(?:m|meter)" if per_metre else
                    r"(?:rolle[n]?|st(?:ück|k)?|packung(?:en)?)")
            if (freight is not None and freight >= 0 and literal_in(product, terms)
                    and literal_in(position.destination, terms) and literal_in(info["tax"], terms)
                    and re.search(r"(?<![\w.,])" + order + r"\b", terms)
                    and re.search(r"keine (?:weiteren )?(?:neben|zusatz)kosten", terms)):
                info["shipping_value"] = float(freight)
                info["delivered_value"] = float(subtotal + freight)
                if info["tax"] == "netto":
                    metrics["total_price"] = {"value": float(subtotal + freight), "fact": shipping.model_dump(),
                                              "calculation": f"{subtotal:.2f} + {freight:.2f} = {subtotal + freight:.2f} EUR netto"}
        return info, metrics
    return info, None


def evaluate(position, offers, sources, questions, weights, catalog=None):
    modern = not ({"quality","delivery_days"} & weights.keys())
    weights = {key: value for key, value in weights.items() if value}
    rows = []
    for offer in offers:
        if not offer_grounded(offer, sources):
            continue
        facts = select_facts(offer.facts, sources)
        known_seller = seller_confirmed(offer,sources)
        catalog_key = (offer.supplier, offer.product)
        from_catalog = catalog is not None and catalog_key in catalog
        from shop_evidence import conflicts_for_source
        variant_conflicts = conflicts_for_source(offer.identity.source_id,sources) if modern else []
        if modern:
            from practical_prices import practical_price
            listed,calculated = practical_price(offer,facts,position,sources)
            if from_catalog and catalog[catalog_key]:
                price = catalog[catalog_key]
                qty = quantity_number(position.quantity)
                pack = Decimal(str(price["pack"]))
                basis = Decimal(str(price["basis"]))
                amount = number(price["value"])
                from practical_prices import demand_unit
                if qty and demand_unit(position,sources) == "Stück" and amount is not None and basis > 0 and pack > 0:
                    supplied = (qty / pack).to_integral_value(rounding=ROUND_CEILING) * pack
                    goods = (supplied / basis * amount).quantize(Decimal(".01"))
                    tax = price["tax"]
                    date = price.get("date")
                    calc = (f"{supplied:g} Stück ({supplied / pack:g} Packungen à {pack:g}) ÷ {basis:g} × "
                            f"{amount:g} EUR = {goods:.2f} EUR vor Versand.")
                    listed = {"value":float(amount),"raw":price["value"],"currency":"EUR","tax":tax,
                              "pack_size":float(pack),"price_basis":f"{basis:g} Stück","goods_value":float(goods),
                              "calculation":calc,"evidence":price["evidence"],"shipping":"offen",
                              "supplied_quantity":float(supplied),"supplied_unit":"Stück",
                              "order_quantity":float(supplied / pack),"order_unit":"Packungen",
                              "basis_evidence":price["header"],"pack_evidence":price["evidence"],
                              "historical":bool(date),"date":date or "","date_evidence":price.get("date_evidence")}
                    # Use dated historical net prices in their own comparison group.
                    if tax == "netto" and date:
                        calculated = {"net_price":{"value":float(goods),
                            "fact":{"field":"listed_price","value":price["value"],"unit":"EUR","evidence":price["evidence"]},
                            "basis":f"order|netto|EUR|Stück|{qty:g}|historisch:{date}","calculation":calc}}
        else:
            listed, calculated = listed_offer(offer, facts, position)
        if variant_conflicts:
            listed,calculated = {},{}
        route_fact = facts.get("distance_route") or facts.get("route_issue")
        route = sources.get(route_fact.evidence.source_id, {}).get("route") if route_fact else None
        if route:
            origin = next((fact for fact in offer.facts if fact.field in {"dispatch_location","company_city","company_address","branch_address"}
                           and fact.value == route["origin"] and fact.evidence.model_dump() == route["address_evidence"]
                           and check_fact(fact,sources)), None)
            if (not origin or origin.value != route["origin"] or route["destination"] != position.destination
                    or route["address_evidence"] != origin.evidence.model_dump()):
                route = None
        if modern and not known_seller:
            route = None

        def checks(criteria):
            items = []
            for criterion in criteria:
                fact = facts.get(criterion.field)
                axis = nominal_axis(criterion.field)
                if modern and fact is None and axis is not None:
                    fact = next((item for field,item in facts.items() if nominal_axis(field)==axis),None)
                if modern and fact is None:
                    for alias in (r"dicke|stärke|staerke",r"legierung|werkstoff|material",
                                  r"oberfläche|beschichtung|finish|coating", r"^(?:norm|standard|produktnorm)$",
                                  r"^(?:gewinde(?:nenn)?grösse|nenngrösse|thread size)$",
                                  r"^(?:produkttyp|produktart|materialgruppe|produktform|mutternform)$",
                                  r"^(?:abmessungen?|maße|masse|größe|format)$"):
                        if re.search(alias,normalize(criterion.field)):
                            fact = next((item for field,item in facts.items() if re.search(alias,normalize(field))),None)
                            break
                if modern and fact is None and re.search(r"anschluss(?:durchmesser|grösse|mass)|dimension|abmessung|^masse$", normalize(criterion.field)):
                    fact = facts.get("Dimension")
                result = None
                if criterion_usable(criterion, sources):
                    result = compare(criterion, fact)
                    if modern and result is None:
                        result,title_fact = screw_title_measurement(offer,criterion,sources)
                        fact = title_fact or fact
                    if modern and result is None:
                        result, title_fact = title_standard(offer,criterion,sources)
                        fact = title_fact or fact
                    if modern and result is None and re.fullmatch(r"gewinde(?:nenn)?grösse", normalize(criterion.field)):
                        page = sources[offer.identity.source_id]
                        # Many catalogue tables put the thread before several variant SKUs.
                        pitch_row = re.match(r"^\s*(M\d+(?:[,.]\d+)?)\s*[x×]\s*\d+(?:[,.]\d+)?\s*\|",
                                             offer.identity.quote, re.I)
                        if page["kind"] == "pdf" and pitch_row and grounded(offer.identity, sources, offer.product):
                            fact = Fact(field=criterion.field, value=pitch_row[1], unit="", evidence=offer.identity)
                            result = compare(criterion, fact)
                    # Some shop titles contain malformed dimensions. The
                    # selected variant can still prove a mismatch in its table.
                    pair = re.fullmatch(r"(\d+(?:[.,]\d+)?)\s*[x×]\s*(\d+(?:[.,]\d+)?)(?:\s*mm)?",
                                        normalize(criterion.target))
                    if modern and result is None and pair and criterion.operator in {"eq","contains"} and normalize(criterion.unit) in {"","mm"}:
                        for index,pattern in enumerate((r"^(?:nenn)?durchmesser$",r"^(?:gesamt|nenn)?länge$"),1):
                            mismatch = next((item for field,item in facts.items()
                                             if re.search(pattern,normalize(field)) and normalize(item.unit) == "mm"
                                             and number(item.value) is not None and number(item.value) != number(pair[index])),None)
                            if mismatch:
                                result,fact = False,mismatch
                                break
                    if variant_conflicts:
                        result = None
                    if from_catalog:
                        from catalog import catalog_check
                        structured_result, structured_fact = catalog_check(criterion, facts)
                        if structured_result is not None or fact is None:
                            result, fact = structured_result, structured_fact
                items.append({
                    "field": criterion.field, "operator": criterion.operator, "target": criterion.target,
                    "unit": criterion.unit, "result": result,
                    "requirement": criterion.evidence.model_dump(),
                    "fact": fact.model_dump() if fact else None,
                })
            return items

        must = checks(position.must)
        quality = [] if modern else checks(position.quality)
        must_results = [item["result"] for item in must]
        missing = [item["field"] for item in must + quality if item["result"] is None]
        values = {}
        for key, label in METRICS.items():
            if modern and key == "delivery_days":
                continue
            fact = facts.get(key)
            value = number(fact.value) if comparable(key, fact, position) else None
            if variant_conflicts and key in PRICE_BASIS:
                value = None
            if modern and key == "distance_km" and not known_seller:
                value = None
            if key == "distance_km" and value is not None and sources[fact.evidence.source_id]["kind"] in {"web", "web_pdf"}:
                origin = facts.get("dispatch_location")
                if not origin or not literal_in(origin.value, fact.evidence.quote):
                    value = None
            if calculated and key in calculated and value is None:
                values[key] = calculated[key]["value"]
            elif value is None or value < 0 or (key in PRICE_BASIS and value == 0):
                if key not in PRICE_BASIS or key == "total_price":
                    missing.append(label)
            else:
                values[key] = value
        if quality and all(item["result"] is not None for item in quality):
            values["quality"] = Decimal(sum(item["result"] for item in quality)) / len(quality)
        if route and route["status"] == "ready":
            values["distance_km"] = route["distance_km"]
            missing = [item for item in missing if item != METRICS["distance_km"]]
        status = ("abweichend" if modern else "ausgeschlossen") if False in must_results else "offen"
        if status not in {"ausgeschlossen","abweichend"} and None not in must_results and not questions and weights.keys() <= values.keys():
            status = "geeignet"
        if not position.destination:
            missing.append("Versandkosten")
        if not any(key in values for key in PRICE_BASIS):
            missing.append(METRICS["net_price"])
        reasons = {}
        if "total_price" not in values:
            note = facts.get("price_note")
            reasons["total_price"] = ("Versandkosten und Gesamtpreis zum Lieferort bestätigen." if listed.get("goods_value") else note.value if note else
                "Steuerstatus, Packungsbezug oder Versandkosten für den Zielort prüfen." if listed else
                "Konkrete Variante und Menge auswählen und den ausgewiesenen Preis prüfen.")
        if "distance_km" not in values:
            reasons["distance_km"] = ("Tatsächlicher Verkäufer des Marktplatzangebots noch nicht belegt."
                                      if modern and not known_seller else
                                      route["reason"] if route and route["status"] == "open" else
                                      "Lieferort fehlt." if not position.destination else
                                      "Geschätzte Entfernung ab Lieferantenstandort. Versandort bestätigen."
                                      if facts.get("distance_estimate") and not facts.get("dispatch_location") else
                                      "Nur eine Luftlinie verfügbar." if facts.get("distance_estimate") else
                                      "Adresssuche: Kein belegter Versand-, Filial- oder Firmenstandort gefunden."
                                      if not any(facts.get(field) for field in ("company_address", "branch_address", "dispatch_location")) else
                                      "Routingdienst oder Geokodierung ist nicht konfiguriert." if not all(
                                          os.getenv(name) for name in ("TRINITY_ROUTER_URL", "TRINITY_GEOCODER_URL")) else
                                      "Geokodierung ohne eindeutigen Adresstreffer oder Routingdienst ohne gültige Route.")
        if not modern and "delivery_days" not in values:
            reasons["delivery_days"] = "Liefertermin für Variante, Menge und Zielort bestätigen lassen."
        if from_catalog and "total_price" not in values:
            reasons["total_price"] = ("Aktuellen Nettopreis für die angefragte Menge anfragen."
                                      if catalog[catalog_key] else "Preis und Verpackungseinheit für die Menge anfragen.")
            if not facts.get("shipping_cost"):
                reasons["shipping_cost"] = "Versandkosten zum Lieferort anfragen."
        rows.append({
            "supplier": offer.supplier, "product": offer.product, "identity": offer.identity.model_dump(),
            **({"evaluation_version":2,"marketplace":marketplace_name(offer,sources),
                "seller_confirmed":seller_confirmed(offer,sources),
                "selection_basis":listed.get("configuration") or
                    " · ".join(f"{fact.field} {fact.value} {fact.unit}".strip() for fact in facts.values()
                               if re.search(r"legierung|werkstoff|material|dicke|stärke|breite|länge|maße|antrieb|kopf|profil|gewinde|durchmesser",
                                            normalize(fact.field)))[:500] or offer.product}
               if modern else {}),
            "status": status, "must": must, "quality": quality,
            "metrics": {key: (calculated[key] if calculated and key in calculated
                              and not comparable(key, facts.get(key), position) else
                              {"value": float(value), "fact": route_fact.model_dump(), "basis": route["basis"].rsplit("|",1)[0] if modern and route["basis"].endswith(("|address","|city-centers")) else route["basis"]}
                              if key == "distance_km" and route and route["status"] == "ready" else
                              {"value": float(value), "fact": facts[key].model_dump() if key in METRICS else None})
                        for key, value in values.items()},
            "distance": route | {"evidence": route_fact.evidence.model_dump()} if route else None,
            "listed_price": listed or None, "reasons": reasons,
            "technical_status": (("abweichend" if modern else "ausgeschlossen") if False in must_results else
                                 "Beispielausführung" if modern and not must_results else
                                 "passend" if must_results and all(must_results) else "Nachweis offen"),
            **({"catalog_price": catalog[catalog_key]} if from_catalog else {}),
            "missing": list(dict.fromkeys(missing)), "score": None, "components": {},
            "partial_score": None, "specs": [
                fact.model_dump() for field, fact in facts.items()
                if field not in METRICS and field not in {"listed_price","branch_address"} and field not in {item["field"] for item in must + quality}
                and not (modern and not known_seller and field in {
                    "company_address","branch_address","dispatch_location","distance_route","location_coordinates","route_issue"})
            ] + ([fact.model_dump() for fact in offer.facts if fact.field == "branch_address" and check_fact(fact,sources)]
                 if known_seller else []),
        })
    if modern:
        from price_ranking import rank_prices
        return rank_prices(rows,weights)
    eligible = [row for row in rows if row["status"] == "geeignet"]
    distance_bases = {row["metrics"].get("distance_km", {}).get("basis", "quoted-road") for row in eligible
                      if "distance_km" in row["metrics"]}
    if "distance_km" in weights and len(distance_bases) > 1:
        for row in eligible:
            row["status"] = "offen"
            row["reasons"]["distance_km"] = "Entfernungen mit verschiedenen Berechnungsgrundlagen. Einheitliche Straßenrouten fehlen."
        eligible = []
    if eligible:
        assign_points(eligible, weights, "score")
    pending = [row for row in rows if row["status"] != "ausgeschlossen" and row["metrics"]
               and (not eligible or row["status"] == "offen")]
    if len(pending) >= 2:
        participants, basis = partial_comparison(pending, weights)
        if basis:
            assign_points(participants, basis, "partial_score")
    for row in rows:
        if row["status"] == "ausgeschlossen" or row["score"] is not None or row["partial_score"]:
            continue
        covered = sum(weight for key, weight in weights.items() if key in row["metrics"]
                      or key == "total_price" and any(price in row["metrics"] for price in PRICE_BASIS))
        row["reasons"]["score"] = (f"{covered} % Datenabdeckung. "
                                  "Für Vergleichspunkte fehlt ein zweites Angebot auf derselben bewertbaren Grundlage."
                                  if covered else "0 % Datenabdeckung der gewichteten Kriterien. Technische Muss-Nachweise bleiben separat sichtbar.")
    order = {"geeignet": 0, "offen": 1, "ausgeschlossen": 2}
    rows.sort(key=lambda row: (
        order[row["status"]], -(row["score"] if row["score"] is not None else
                                 row["partial_score"]["value"] if row["partial_score"] else -1),
        row["supplier"].casefold(), row["product"].casefold(),
    ))
    return rows


def partial_comparison(rows, weights):
    """Choose one shared basis, covering as many candidates as possible."""
    nonprice = {key: weight for key, weight in weights.items() if key != "total_price"}
    participants, basis = [], {}
    for price in PRICE_BASIS if "total_price" in weights else (None,):
        available = {price: weights["total_price"], **nonprice} if price else nonprice
        for size in range(1, len(available) + 1):
            for keys in combinations(available, size):
                group = [row for row in rows if all(key in row["metrics"] for key in keys)]
                if "distance_km" in keys:
                    groups = {}
                    for row in group:
                        route_basis = row["metrics"]["distance_km"].get("basis", "quoted-road")
                        groups.setdefault(route_basis, []).append(row)
                    group = max(groups.values(), key=len, default=[])
                common = {key: available[key] for key in keys}
                if len(group) >= 2 and (len(group), sum(common.values())) > (len(participants), sum(basis.values())):
                    participants, basis = group, common
    return participants, basis


def assign_points(rows, basis, output, *, decimals=4):
    minima = {key: min(row["metrics"][key]["value"] for row in rows) for key in basis}
    for row in rows:
        components = {}
        for key, weight in basis.items():
            value = row["metrics"][key]["value"]
            fraction = value if key == "quality" else minima[key] / value if value else 1
            components[key] = round(weight * fraction, decimals)
        score = round(sum(components.values()), 2)
        if output == "score":
            row["components"] = components
            row["score"] = score
        else:
            row["partial_score"] = {"value": score, "basis": basis, "components": components}


def merge_offers(*batches):
    offers = {}
    for batch in batches:
        for offer in batch:
            key = (normalize(offer.supplier), normalize(offer.product))
            if key in offers:
                offers[key].facts.extend(offer.facts)
            else:
                offers[key] = offer.model_copy(deep=True)
    return list(offers.values())


def recommendation(rows, questions=()):
    if any(row.get("evaluation_version") == 2 for row in rows):
        from price_ranking import recommend
        return recommend(rows,questions)
    ranked = [row for row in rows if row["status"] == "geeignet"]
    if not ranked:
        partial = [row for row in rows if row["partial_score"]]
        if len(partial) < 2 or partial[0]["partial_score"]["value"] == partial[1]["partial_score"]["value"]:
            matching = [row for row in rows if row.get("technical_status") == "passend"]
            if len(matching) == 1:
                row = matching[0]
                basis = ", ".join(item["field"] for item in row["must"])
                return (f"Technische Vorauswahl: {row['supplier']} ({row['product']}) ist der einzige belegte passende Artikel. "
                        f"Belegt: {basis}. Gesamtpreis inklusive Versand und Liefertermin bestätigen.")
            if matching:
                names = ", ".join(f'{row["supplier"]} {row["product"]}' for row in matching)
                return (f"Technische Shortlist: {names}. Die Muss-Kriterien sind belegt. "
                        "Für diese Artikel aktuelle Preise inklusive Versand und die Lieferzeit anfragen.")
            pending = [row for row in rows if row["status"] != "ausgeschlossen"]
            if pending:
                return "Vorauswahl zur Prüfung: " + " · ".join(
                    f"{row['supplier']} ({row['product']}): "
                    + (", ".join(item["field"] for item in row["must"] if item["result"] is None) or "Konditionen")
                    + " bestätigen" for row in pending[:3]) + "."
            return "Keine belastbare Empfehlung. Die nächsten Prüfschritte stehen bei den Kandidaten."
        best = partial[0]
        score = best["partial_score"]
        labels = METRICS | {"quality": "Qualität"}
        criteria = ", ".join(labels[key] for key in score["basis"])
        runner = partial[1]["partial_score"]["components"]
        differentiator = max(score["components"], key=lambda key: score["components"][key] - runner[key])
        impact = []
        open_questions = " ".join(questions).lower()
        if "Versandkosten" in best["missing"]:
            impact.append("Der Lieferort kann Versandkosten, Gesamtpreis und Entfernung verändern.")
        if "maß" in open_questions or "toleranz" in open_questions:
            impact.append("Die erforderlichen Maße oder Toleranzen können die Produktauswahl ändern.")
        elif questions and not impact:
            impact.append("Die offenen Bedarfsangaben können die Auswahl ändern.")
        if best["missing"]:
            impact.append(f"Offene Angebotsnachweise: {', '.join(best['missing'])}.")
        fewer = sum(row["status"] == "offen" and row["partial_score"] is None for row in rows)
        caveat = " Weitere Kandidaten haben keine Werte auf dieser Punktbasis." if fewer else ""
        return (
            f"Vorläufige Empfehlung: {best['supplier']} ({best['product']}) mit "
            f"{score['value']:.2f} von {sum(score['basis'].values())} Teilpunkten "
            f"auf gemeinsamer Datengrundlage ({criteria}).{caveat} "
            f"Größter Vorsprung: {labels[differentiator]}. "
            + " ".join(impact)
        )
    best = ranked[0]
    tied = [row for row in ranked if row["score"] == best["score"]]
    if len(tied) > 1:
        options = ", ".join(f'{row["supplier"]} ({row["product"]})' for row in tied)
        return f"Gleichstand mit {best['score']:.2f} von 100 Punkten: {options}. Bitte manuell entscheiden."
    metrics = best["metrics"]
    context = "Einziges vollständig belegtes Angebot" if len(ranked) == 1 else "Höchste gewichtete Punktzahl"
    details = {
        "total_price": lambda value: f"Gesamtpreis netto {value:.2f} EUR",
        "quality": lambda value: f"{value:.0%} der Soll-Kriterien erfüllt",
        "delivery_days": lambda value: f"{value:g} Tage",
        "distance_km": lambda value: f"{value:g} km",
    }
    summary = ", ".join(details[key](metrics[key]["value"]) for key in best["components"])
    return (
        f"Kaufempfehlung: {best['supplier']} ({best['product']}) mit {best['score']:.2f} von 100 Punkten. {context}. "
        f"Alle Muss-Kriterien erfüllt. {summary}."
    )


def marketplace_name(offer, sources):
    if offer.marketplace:
        return offer.marketplace
    host = urlsplit(sources.get(offer.identity.source_id,{}).get("url","")).hostname or ""
    return next((name for name in ("Amazon","eBay","Kaufland","Manomano","voelkner") if name.casefold()+"." in host),"")


def seller_confirmed(offer, sources):
    source = sources.get(offer.identity.source_id, {})
    if source.get("kind") == "pdf" and offer.supplier == source.get("title"):
        return False
    if not marketplace_name(offer,sources):
        return True
    return any(fact.field == "actual_seller" and normalize(fact.value) == normalize(offer.supplier)
               and check_fact(fact,sources) and re.search(r"verkauf durch|verkauf & versand|verkäufer|seller",normalize(fact.evidence.quote))
               for fact in offer.facts)
