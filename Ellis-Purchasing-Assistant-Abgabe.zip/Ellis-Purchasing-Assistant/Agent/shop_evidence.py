"""Read bounded shop product records; never join neighbouring product cards."""
import re
import json
from decimal import Decimal
from urllib.parse import urljoin, urlsplit, urlunsplit

PIECES = r"(\d[\d.]*)\s*(?:Stück|Stk\.?|St\.|pieces|pcs)(?!\w)"
PACK_TITLE = r"\b(?:Beutel|Packung|Paket|Pack)\s+(?:(?:von|mit|à)\s+)?(\d[\d.]*)(?![\w.])"
ROLL_LENGTH = r"\b(?:rolle|ring|spule|trommel)\s*:?\s*(?:à\s*)?(\d+(?:[.,]\d+)?)\s*m(?:eter)?\b"
UNIT_CODES = {"C62":"Stück","H87":"Stück","EA":"Stück","MTR":"m","KGM":"kg","MTK":"m²","LTR":"l",
              "STÜCK":"Stück","STK":"Stück","M":"m","KG":"kg","L":"l","M²":"m²"}


def schema_type(node):
    kinds = node.get("@type",[])
    return {kind.rsplit("/",1)[-1].removeprefix("schema:") for kind in
            ([kinds] if isinstance(kinds,str) else kinds or []) if isinstance(kind,str)}


def linked_data(soup):
    pending = []
    for script in soup.select('script[type="application/ld+json"]')[:30]:
        try:
            pending.append(json.loads(script.get_text()))
        except ValueError:
            continue
    while pending:
        node = pending.pop()
        if isinstance(node,list):
            pending.extend(node)
        elif isinstance(node,dict):
            yield node
            pending.extend(node[key] for key in ("@graph","mainEntity","hasVariant","publisher") if key in node)


def published_price(offer):
    """Extract an exact price and its reference unit from a single offer."""
    specs = offer.get("priceSpecification") or []
    specs = [specs] if isinstance(specs,dict) else specs
    specs = [spec for spec in specs if isinstance(spec,dict) and not spec.get("priceType")]
    exact = lambda value: bool(re.fullmatch(r"\d{1,12}(?:[.,]\d{1,4})?",str(value)))
    price,currency = offer.get("price"),offer.get("priceCurrency")
    if not exact(price):
        current = [item for item in specs if exact(item.get("price")) and item.get("priceCurrency")]
        if len(current) != 1:
            return None
        price,currency = current[0]["price"],current[0]["priceCurrency"]
    if not isinstance(currency,str) or not re.fullmatch(r"[A-Z]{3}",currency):
        return None
    matching = [item for item in specs if not item.get("price") or
                exact(item["price"]) and Decimal(str(item["price"]).replace(",",".")) == Decimal(str(price).replace(",","."))
                and item.get("priceCurrency",currency) == currency]
    specification = matching[0] if len(matching) == 1 else {}
    included = specification.get("valueAddedTaxIncluded",offer.get("valueAddedTaxIncluded"))
    reference = specification.get("referenceQuantity")
    basis = None
    if isinstance(reference,dict):
        unit = UNIT_CODES.get(str(reference.get("unitCode") or reference.get("unitText") or "").upper().rstrip("."))
        if unit and exact(reference.get("value")) and Decimal(str(reference["value"]).replace(",",".")) > 0:
            basis = {"value":str(reference["value"]),"unit":unit}
    return str(price),currency,included,basis


def organization_lines(soup, url):
    """Keep each structured postal address attached to its named organization."""
    lines = []
    host = (urlsplit(url).hostname or "").removeprefix("www.")
    for node in linked_data(soup):
        if not schema_type(node) & {"Organization","Corporation","OnlineStore"}:
            continue
        name,address = node.get("name"),node.get("address")
        prefix = node.get("url") or node.get("@id") or ""
        if (not isinstance(name,str) or not isinstance(address,dict) or not isinstance(prefix,str)
            or prefix and (urlsplit(urljoin(url,prefix)).hostname or "").removeprefix("www.") != host):
            continue
        country = address.get("addressCountry","")
        country = country.get("name","") if isinstance(country,dict) else country
        values = [name, address.get("streetAddress",""),address.get("postalCode",""),
                  address.get("addressLocality",""),address.get("addressRegion",""),country]
        values = [clean(value) if isinstance(value,str) else "" for value in values]
        if values[3] and all(len(value)<180 and " · " not in value for value in values):
            fields = ["Organisation","Straße","PLZ","Ort","Region","Land"]
            formatted = " ".join(filter(None,(values[1],values[2],values[3],values[5])))
            lines.append("Adressdaten · " + " · ".join(f"{key}: {value}" for key,value in zip(fields,values))
                         + " · Anschrift: " + formatted)
    return list(dict.fromkeys(lines))[:8]


def canonical(url):
    parsed = urlsplit(url)
    return urlunsplit((parsed.scheme,parsed.netloc,parsed.path.rstrip('/'),parsed.query,''))


def clean(value):
    return re.sub(r"\s+"," ",value).strip()


def detail_price_label(soup, amount, currency):
    """Match the selected buy box's amount before taking its tax disclosure."""
    if currency != "EUR":
        return ""
    prices = soup.select_one(".pdp__order-price")
    if prices:
        gross = prices.select_one(".price:not(.price--vat) [data-price]")
        net = prices.select_one(".price--vat [data-price]")
        if gross and net and re.search(r"exkl\.?\s*MwSt",prices.get_text(" ",strip=True),re.I):
            parts = [gross.get("data-price",""),net.get("data-price","")]
            if all(re.fullmatch(r"\d+(?:\.\d+)?",part) for part in parts):
                gross_value,net_value = map(Decimal,parts)
                current = Decimal(amount.replace(",","."))
                if gross_value > net_value > 0:
                    if current == gross_value:
                        return "inkl. MwSt."
                    if current == net_value:
                        return "exkl. MwSt."
    box = soup.select_one('[data-testid="product-informations"] [data-testid="prices"]')
    if not box:
        return ""
    pattern = r"Preis\s*[—–:-]?\s*(\d+[.,]\d{2})\s*€.*(?:inkl|zzgl|exkl)\.?\s*(?:MwSt|USt)"
    for value in box.stripped_strings:
        label = clean(value)
        match = re.match(pattern,label,re.I)
        if match and Decimal(match[1].replace(",",".")) == Decimal(amount.replace(",",".")):
            return label
    return ""


def visible_pack_price(soup, name, amount, currency):
    """Verify price, piece price and advertised pack in the primary product section."""
    heading = soup.select_one("h1")
    pack = re.search(PACK_TITLE,name,re.I)
    if currency != "EUR" or not heading or clean(heading.get_text(" ",strip=True)) != clean(name) or not pack:
        return None,"",[]
    pieces = int(pack[1].replace(".",""))
    if pieces < 1:
        return None,"",[]
    parent = heading.parent
    for _ in range(4):
        if parent.name in {"body","html"}:
            break
        text = clean(parent.get_text(" ",strip=True))
        match = re.search(r"\bPackung (?:von|mit)\s+" + re.escape(pack[1]) +
                          r"\s+(\d+[,.]\d{2})\s*€\s+(\d+[,.]\d{2})\s*€\s+pro Stück\s+"
                          r"(Inkl\.?\s*(?:MwSt|USt)\.?)",text[:1000],re.I)
        if match:
            total,unit = (Decimal(part.replace(",",".")) for part in match.groups()[:2])
            if total == Decimal(amount.replace(",",".")) and abs(total / pieces - unit) <= Decimal(".005"):
                tiers = []
                region = next((ancestor for ancestor in [parent,*list(parent.parents)[:3]]
                               if ancestor.name not in {"body","html"} and len(ancestor.select("h1")) == 1
                               and ancestor.find(string=re.compile(r"^\s*Mehr kaufen, mehr sparen\s*$",re.I))),parent)
                for label in region.find_all(string=re.compile(r"^\s*[1-9]\d*\+\s+Einheiten\s*$",re.I),limit=20):
                    line = clean(label.parent.parent.get_text(" ",strip=True))
                    tier = re.fullmatch(r"(\d+)\+ Einheiten (\d+[,.]\d{2}) € (\d+[,.]\d{2}) €",line,re.I)
                    if tier and Decimal(tier[2].replace(",",".")) == total and 0 < Decimal(tier[3].replace(",",".")) < total:
                        tiers.append(f"{tier[1]}+ Einheiten {tier[3]} EUR")
                return pack[1],"Preis: "+match[0],list(dict.fromkeys(tiers))
        parent = parent.parent
    return None,"",[]


def shopware_order_unit(box):
    qty = box.select_one('input[name^="lineItems["][name$="[quantity]"][type="number"]')
    if not qty or not re.fullmatch(r"[1-9]\d*",qty.get("min","")):
        return None
    for region in list(qty.parents)[:4]:
        if region.select_one('button[type="submit"]'):
            break
        for label in region.select("span, label"):
            if re.fullmatch(r"(?:ST\.?|Stk\.?|Stück)",label.get_text(" ",strip=True),re.I):
                return {"unit":"Stück","minimum":qty["min"],"label":label.get_text(" ",strip=True)}
    return None


def conflicts_for_source(source_id, sources):
    source=sources.get(source_id,{})
    url=source.get('product_url') or source.get('url')
    if not url:return []
    target=canonical(url)
    records=[record for page in sources.values() for record in page.get('shop_products',[])
             if canonical(record['product_url'])==target]
    conflicts=[value for record in records for value in record.get('conflicts',[])]
    sizes={str(record['pack_size']).replace('.','') for record in records if record.get('pack_size')}
    if len(sizes)>1:
        conflicts.append('Packungsgröße zwischen Produktkarte und Detailseite widersprüchlich: '+', '.join(sorted(sizes))+' Stück.')
    return list(dict.fromkeys(conflicts))


def store_name(soup, url, data, product_name):
    host = (urlsplit(url).hostname or "").removeprefix("www.")
    shops = [node for node in data if schema_type(node) & {"OnlineStore","Organization","Corporation"}
             and isinstance(node.get("name"),str) and node["name"].strip()
             and isinstance(node.get("url"),str)
             and (urlsplit(urljoin(url,node["url"])).hostname or "").removeprefix("www.") == host]
    site = soup.find("meta",property="og:site_name")
    label = clean(site.get("content","")) if site else ""
    # Some shops put the product and price in this Open Graph field.
    product_label = bool(label and (label.casefold() == product_name.casefold()
                                   or re.search(r"[€£$]|\d+[.,]\d{2}\s*(?:EUR|GBP|USD)",label,re.I)))
    if label and not product_label and not re.match(r"https?://",label,re.I):
        return label
    named_store = next((node for node in shops if "OnlineStore" in schema_type(node)),None)
    name = (named_store or next(iter(shops),{})).get("name")
    title = soup.title.get_text(" ",strip=True) if soup.title else ""
    if not name and "|" in title:
        suffix = clean(title.rsplit("|",1)[1])
        host_key = re.sub(r"[^a-z0-9]","",host.split(".")[0].lower())
        suffix_key = re.sub(r"[^a-z0-9]","",suffix.lower())
        if 4 <= len(host_key) and 0 < len(suffix) <= 100 and suffix_key.startswith(host_key):
            name = suffix
    return clean(name or host)


def visible_purchase_price(soup):
    """Read the price actually published in the primary JTL offer block."""
    box = soup.select_one("#product-offer .price_wrapper, .product-offer[itemprop=offers] .price_wrapper")
    amount = box.select_one(".price-row strong.price, div.price") if box else None
    if not amount:
        return None
    text = clean(amount.get_text(" ",strip=True))
    match = re.fullmatch(r"(?:ab\s+)?(?:€\s*)?(\d+(?:\.\d{3})*,\d{2})\s*€?",text,re.I)
    if not match or "€" not in text:
        return None
    tax = box.select_one(".vat_info")
    raw = " ".join([text,tax.get_text(" ",strip=True) if tax else ""])
    order = None
    offer = box.find_parent(id="product-offer") or box.find_parent(class_="product-offer")
    qty = offer.select_one('input[name="anzahl"][type="number"]') if offer else None
    if qty and qty.get("step") == "1":
        group = qty.find_parent(class_="choose_quantity")
        unit = group.select_one(".unit") if group else None
        minimum = qty.get("min", "1")
        if unit and re.fullmatch(r"(?:Stk\.?|Stück)", clean(unit.get_text(" ", strip=True)), re.I) and minimum.isdecimal():
            order = {"minimum": str(max(1, int(minimum))), "label": clean(unit.get_text(" ", strip=True))}
    identifiers = {clean(node.get_text(" ", strip=True)).casefold()
                   for node in soup.select('[data-js-product-sku][itemprop="sku"]')}
    return {"price":match[1].replace(".",""),"currency":"EUR","raw":raw,
            "order":order, **({"identifiers": list(identifiers)} if len(identifiers) == 1 else {}),
            "price_from":bool(box.select_one(".pricestarting") or re.match(r"ab\b",raw,re.I))}


def sales_pack(soup, amount, currency):
    """Read an explicit sales unit tied to the same price in the buy table."""
    if currency != "EUR":
        return None
    for label in soup.find_all(string=re.compile(r"^\s*Verkaufseinheit:\s*$", re.I), limit=5):
        table = label.find_parent("table")
        if not table:
            continue
        text = clean(table.get_text(" ", strip=True))
        sizes = re.findall(r"Verkaufseinheit:\s*([1-9][\d.]*)\s*(?:Stück|Stk\.?)", text, re.I)
        prices = re.findall(r"(\d+[,.]\d{2})\s*(?:EUR|€)\s*\(\s*(\d+[,.]\d{2})\s*(?:EUR|€)\s*inkl\.\s*(?:MwSt|USt)\.?\s*\)", text, re.I)
        if len(sizes) == len(prices) == 1:
            net, gross = prices[0]
            if Decimal(net.replace(",", ".")) == Decimal(amount.replace(",", ".")) < Decimal(gross.replace(",", ".")):
                return {"verified_pack": sizes[0], "price": gross, "raw": "inkl. MwSt.",
                        "basis": {"value": sizes[0], "unit": "Stück"}}
    return None


def seller_card(soup, url, heading):
    """A selected merchant card needs the same advertised price and pack unit."""
    if not heading or not re.search(PIECES, heading, re.I):
        return None
    cards = soup.select("article.js_condition_offer_card")
    if len(cards) != 1:
        return None
    price = cards[0].select_one(".selectionCard__item__header__label__content__price")
    seller = cards[0].select_one(".seller__info__link")
    label = cards[0].select_one(".seller__label")
    if not price or not seller or not label or clean(label.get_text()) != "Verkauf & Versand:":
        return None
    amount = re.fullmatch(r"(\d+,\d{2})\s*€", clean(price.get_text()))
    if not amount:
        return None
    region = cards[0].parent.parent
    text = clean(region.get_text(" ", strip=True))
    gross = re.search(r"(\d+)\s*,\s*(\d{2})\s*€\s*inkl\.\s*MwSt\.\s*zzgl\.\s*Versand\s+Pack\b", text, re.I)
    merchant = clean(seller.get_text())
    if not gross or gross[1] + "," + gross[2] != amount[1] or not merchant:
        return None
    return dict(name=heading, product_url=url, seller=merchant, properties={}, raw=gross[0],
                kind="Produktdetail · Händlerangebot", price=amount[1], currency="EUR",
                seller_label="Verkauf & Versand: " + merchant)


def article_buy_box(heading, url):
    """Read the selected article from a form with a visible SKU and buy price."""
    form = heading.find_parent("form") if heading else None
    if not form or urlsplit(urljoin(url, form.get("action", ""))).hostname != urlsplit(url).hostname:
        return None
    skus = {clean(node.get_text(" ", strip=True)) for node in form.select('[itemprop="sku"]')}
    prices = form.select(".productprice")
    if len(skus) != 1 or not next(iter(skus)) or len(prices) != 1:
        return None
    amount = re.fullmatch(r"(\d+[,.]\d{2})\s*(?:EUR|€)", clean(prices[0].get_text(" ", strip=True)))
    if not amount:
        return None
    raw = clean(prices[0].parent.get_text(" ", strip=True))
    name = clean(heading.get_text(" ", strip=True))
    return dict(name=name, product_url=url, seller=urlsplit(url).hostname.removeprefix("www."), properties={}, raw=raw,
                kind="Produktdetail · Kaufbereich", price=amount[1], currency="EUR",
                identifiers=[next(iter(skus)).casefold()])


def shop_records(soup, url):
    records = []
    heading = soup.select_one('h1')
    heading_name = clean(heading.get_text(" ",strip=True)) if heading else ""
    data = list(linked_data(soup))
    seller = store_name(soup,url,data,heading_name)
    purchase = visible_purchase_price(soup)
    for node in data:
        name = node.get("name")
        if "Product" not in schema_type(node) or not isinstance(name,str) or not name:
            continue
        offers = node.get("offers",[])
        for offer in offers if isinstance(offers,list) else [offers]:
            if not isinstance(offer,dict) or "Offer" not in schema_type(offer):
                continue
            item = offer.get("itemOffered")
            if isinstance(item,dict) and any(item.get(key) and item[key]!=node.get(key) for key in ("name","sku")):
                continue
            urls = [item for item in (node.get("url"),offer.get("url")) if isinstance(item,str) and item]
            if any(canonical(urljoin(url,item)) != canonical(url) for item in urls):
                continue
            if not urls and heading_name and clean(name).casefold() != heading_name.casefold():
                continue
            pricing = published_price(offer)
            if not pricing:
                continue
            price,currency,included,basis = pricing
            price_label = detail_price_label(soup,price,currency) if included is None else ""
            verified_pack, pack_label, tiers = visible_pack_price(soup,name,price,currency)
            tax = "inkl. MwSt." if included is True else "netto" if included is False else price_label or pack_label
            merchant = offer.get("seller")
            merchant = merchant.get("name") if isinstance(merchant,dict) else None
            properties = {}
            extra = node.get("additionalProperty",[])
            for prop in (extra if isinstance(extra,list) else [extra])[:20]:
                if not isinstance(prop,dict) or not isinstance(prop.get("name"),str):
                    continue
                label,value = prop["name"],prop.get("value")
                if isinstance(value,(str,int,float)) and len(label) <= 60 and len(str(value)) <= 120:
                    text = clean(f"{value} {prop.get('unitText') or ''}")
                    if label in properties and text != properties[label]:
                        text = properties[label] + " / " + text
                    properties[label] = text
            specification = offer.get("priceSpecification")
            ranged = bool(offer.get("minPrice") or isinstance(specification,dict) and specification.get("minPrice"))
            brand = node.get("brand")
            brand = brand.get("name") if isinstance(brand, dict) else brand
            record = dict(name=name,product_url=url,seller=merchant or seller,properties=properties,kind="Produktdetail · JSON-LD",
                          price=price,currency=currency,raw=tax,verified_pack=verified_pack,tiers=[] if included is False else tiers,basis=basis,
                          price_from=ranged, brand=brand if isinstance(brand, str) else "",
                          identifiers=[str(node[key]).strip().casefold() for key in ("sku", "mpn")
                                       if isinstance(node.get(key), (str, int))])
            pack_offer = sales_pack(soup, price, currency) if not basis and not ranged and not verified_pack else None
            if pack_offer:
                record.update(pack_offer, kind="Produktdetail · Kaufbereich")
            if purchase:
                # The current buy box supersedes stale or family-level JSON-LD.
                record.update(purchase,kind="Produktdetail · Kaufbereich")
                if record["price_from"]:
                    record.update(basis=None,tiers=[])
            records.append(record)
    if not records and purchase and heading:
        records.append(dict(purchase,name=heading_name,product_url=url,seller=seller,properties={},
                            kind="Produktdetail · Kaufbereich"))
    if merchant_offer := seller_card(soup, url, heading_name):
        records.append(merchant_offer)
    if not records and (item := article_buy_box(heading, url)):
        records.append(item)
    # Microdata is an equivalent public format on shops without JSON-LD.
    if heading and not records:
        product = heading.find_parent(attrs={"itemtype":re.compile(r"(^|/)Product(?:\s|$)")})
        offer = product.select_one('[itemprop="offers"][itemtype$="/Offer"]') if product else None
        if offer and len(product.select('[itemprop="offers"]')) == 1:
            prices = offer.select('[itemprop="price"]')
            currency = offer.select_one('[itemprop="priceCurrency"]')
            tax = offer.select_one('[itemprop="valueAddedTaxIncluded"]')
            link = offer.select_one('[itemprop="url"]')
            target = (link.get("href") or link.get("content") or url) if link else url
            if len(prices) == 1 and currency and canonical(urljoin(url,target)) == canonical(url):
                def value(tag):
                    return clean(tag.get("content") or tag.get_text(" ",strip=True)) if tag else ""

                amount, code = value(prices[0]), value(currency)
                if re.fullmatch(r"\d{1,12}(?:[.,]\d{1,4})?",amount) and re.fullmatch(r"[A-Z]{3}",code):
                    included = value(tax).casefold()
                    raw = {"true":"inkl. MwSt.","false":"netto"}.get(included,"")
                    price_box = prices[0].parent.parent
                    box_text = clean(price_box.get_text(" ",strip=True))
                    price_from = bool(re.search(r"\bab\s+(?:€\s*)?\d",box_text,re.I))
                    if not raw and "*" in box_text:
                        disclosures = {clean(node.parent.get_text(" ", strip=True))
                                       for node in soup.find_all(string=lambda text: text and text.strip().startswith("*"))
                                       if re.match(r"\*\s*(?:inkl|exkl|zzgl)\.?\s+(?:\d+\s*%\s*)?(?:MwSt|USt)",
                                                   clean(node.parent.get_text(" ", strip=True)), re.I)}
                        if len(disclosures) == 1:
                            raw = disclosures.pop()
                    basis = None
                    roll = re.search(ROLL_LENGTH, heading_name, re.I)
                    if re.search(r"(?:€|\bEUR)\s*\*?\s*(?:je\s+|pro\s+|/)\s*(?:1\s+)?m(?:eter)?\b",box_text,re.I):
                        basis = {"value":"1","unit":"m"}
                    elif roll and not price_from and not re.search(r"\b(?:preis pro|preis je|grundpreis)\b",box_text,re.I):
                        basis = {"value":roll[1],"unit":"m"}
                    sku = product.select_one('[itemprop="sku"]')
                    records.append(dict(name=heading_name,product_url=url,seller=seller,properties={},
                                        kind="Produktdetail · Microdata",price=amount,currency=code,
                                        raw=raw, basis=basis, price_from=price_from,
                                        identifiers=[value(sku).casefold()] if value(sku) else []))
    # Shopware current-variant buy box. Configurator lists never supply properties.
    box = soup.select_one('.product-detail-buy')
    if heading and box:
        name = clean(heading.get_text(' ',strip=True))
        price = box.select_one('.product-detail-price-container [itemprop="price"]')
        currency = box.select_one('[itemprop="priceCurrency"]')
        properties = {}
        for row in soup.select('.product-detail-properties-table tr'):
            label,value = row.select_one('th'),row.select_one('td')
            if label and value:
                key,val = clean(label.get_text(' ',strip=True)).rstrip(':'),clean(value.get_text(' ',strip=True))
                if key in properties and properties[key] != val:
                    properties[key] += ' / ' + val
                else:
                    properties[key] = val
        pricing = box.select_one('.product-detail-price-container')
        price_text = clean(pricing.get_text(' ',strip=True)) if pricing else ''
        purl = box.select_one('[itemprop="offers"] [itemprop="url"]')
        linked = urljoin(url,purl.get('content','')) if purl else url
        if canonical(linked) == canonical(url):
            content_pack = re.search(r"\bInhalt:\s*" + PIECES, price_text, re.I)
            record = dict(name=name,product_url=linked,seller=seller,properties=properties,
                          kind='Produktdetail · ausgewählte Variante',price=price.get('content') if price else None,
                          currency=currency.get('content') if currency else None,raw=price_text,order=shopware_order_unit(box),
                          verified_pack=content_pack[1] if content_pack else None)
            records.append(record)
    # Older Shopware pages use a different buy box and keep related prices elsewhere.
    legacy_box = soup.select_one(".buybox--inner")
    if heading and legacy_box:
        price = legacy_box.select_one(".price--content [itemprop=price]")
        currency = legacy_box.select_one("[itemprop=priceCurrency]")
        tax = legacy_box.select_one(".product--tax")
        if price and currency and tax and price.get("content") and currency.get("content"):
            records.append(dict(name=clean(heading.get_text(" ",strip=True)), product_url=url,
                seller=seller,properties={},kind="Produktdetail · ausgewählte Variante",price=price["content"],
                currency=currency["content"],raw=clean(tax.get_text(" ",strip=True))))
    # A bounded card with exactly one product target is an independent shop price source.
    for card in soup.select('[data-testid="article-card"], .product-box, article.product-card'):
        links = card.select('a[href]')
        products = [(a,urljoin(url,a['href'])) for a in links if re.search(r'/(?:p|product|produkt)/',a['href']) or 'product-name' in a.get('class',[])]
        targets = {canonical(target) for _,target in products}
        if len(targets) != 1:
            continue
        title = card.select_one('[data-testid="article-title"],.product-name')
        title = title or next((a for a,_ in products if len(a.get_text(strip=True))>10),None)
        if not title:
            continue
        name = clean(title.get_text(' ',strip=True))
        raw = clean(card.get_text(' ',strip=True))
        # The accessible price includes the tax footnote, unlike a base-price label.
        accessible = [tag.get('aria-label','') for tag in card.select('[aria-label]')]
        pricing = raw + ' ' + ' '.join(accessible)
        match = re.search(r'Preis\s*[—–:-]?\s*(\d+[.,]\d{2})\s*€',pricing,re.I)
        if not match:
            price_node = card.select_one('[itemprop="price"],.product-price')
            match = re.search(r'(\d+[.,]\d{2})',price_node.get('content','') or price_node.get_text(' ',strip=True)) if price_node else None
        records.append(dict(name=name,product_url=products[0][1],seller=seller,properties={},
            kind='Shop-Produktkarte',price=match[1] if match else None,currency='EUR' if match else None,raw=pricing))
    result=[]
    for record in records:
        if not record['name'] or len(record['name'])>350:
            continue
        props=record['properties']
        pack=re.search(PIECES,props.get('Inhalt (VPE)','') or record['name'],re.I)
        record['pack_size']=pack[1] if pack else record.get('verified_pack')
        rate = r"(?:\d+(?:[.,]\d+)?\s*%\s*)?"
        record['tax']='brutto' if re.search(r'inkl\.?\s*'+rate+r'(?:MwSt|USt)',record['raw'],re.I) else 'netto' if re.search(r'netto|(?:zzgl|exkl)\.?\s*'+rate+r'(?:MwSt|USt)',record['raw'],re.I) else 'offen'
        record['conflicts']=[]
        for field in ('Inhalt (VPE)','Durchmesser','Gesamtlänge'):
            if ' / ' in props.get(field,''):
                record['conflicts'].append(f'{field}: mehrere widersprüchliche Werte in den Variantentabellen.')
        title_pack=re.search(r'\b(\d[\d.]*)\s+Stück',record['name'],re.I) or re.match(r'(\d[\d.]*)\s+\w',record['name'])
        if pack and title_pack and pack[1].replace('.','')!=title_pack[1].replace('.',''):
            record['conflicts'].append('Packungsgröße im Produkttitel widerspricht Inhalt (VPE) der ausgewählten Variante.')
        dimension=re.search(r'(\d+(?:[,.]\d+)?)\s*[x×]\s*(\d+(?:[,.]\d+)?)',record['name'],re.I)
        for key,part in [('Durchmesser',1),('Gesamtlänge',2)]:
            if dimension and props.get(key):
                actual=re.search(r'\d+(?:[,.]\d+)?',props[key])
                if actual and float(actual[0].replace(',','.'))!=float(dimension[part].replace(',','.')):
                    record['conflicts'].append(f'{key}: Produkttitel und Variantentabelle widersprechen sich.')
        title_head=re.search(r'Senkkopf|Pan-Head|Halbrundkopf',record['name'],re.I)
        head=props.get('Kopfform','')
        if title_head and head:
            expected=title_head[0].lower().replace('pan-head','halbrundkopf')
            if expected not in head.lower():record['conflicts'].append('Kopfform: Produkttitel und ausgewählte Variante widersprechen sich.')
        drive=re.search(r'\b(?:TX|Torx)\s*(\d+)\b',record['name'],re.I)
        actual_drive=props.get('Antrieb Größe','')
        if drive and actual_drive.isdigit() and int(drive[1])!=int(actual_drive):
            record['conflicts'].append('Antriebsgröße: Produkttitel und ausgewählte Variante widersprechen sich.')
        fields=[f"Anbieter: {record['seller']}",f"Produkt: {record['name']}"]
        if record.get("identifiers"):
            fields.append("Artikelnummer: " + ", ".join(record["identifiers"]))
        if record.get("seller_label"):
            fields.append(record["seller_label"])
        if record['price'] and record['currency']:
            label = 'Preis der Variante'
            if record['kind'] == 'Shop-Produktkarte' and not re.search(r'(?:pro|je|/)\s*Pack(?:ung)?\b',record['raw'],re.I):
                label = 'Ausgewiesener Preis'
            if record.get("price_from"):
                label = "Einstiegspreis ab"
            fields.append(f"{label}: {record['price']} {record['currency']}")
        if record['pack_size']:
            fields.append(f"Packungsgröße: {record['pack_size']} Stück")
        if record.get("basis"):
            fields.append(f"Preisbezug: {record['basis']['value']} {record['basis']['unit']}")
        elif not record["pack_size"] and record.get("order"):
            order = record["order"]
            fields.extend(["Preisbezug: 1 Stück",f"Mindestmenge: {order['minimum']} Stück",
                           f"Verkaufseinheit im Bestellfeld: {order['label']}"])
        fields.append('Steuerstatus: '+record['tax'])
        if (record['kind']=="Produktdetail · Kaufbereich" or record['kind']=='Produktdetail · JSON-LD' and record['raw'].startswith('Preis')
                or record['kind']=="Produktdetail · Microdata" and record['raw']):
            fields.append('Preisangabe im Kaufbereich: '+record['raw'])
        fields.append(f"Produktlink: {record['product_url']}")
        fields.extend(f'{key}: {value}' for key,value in props.items())
        fields.extend('Variantenkonflikt: '+value for value in record['conflicts'])
        if record.get("tiers"):
            fields.append("Preisstaffeln (Packung): "+"; ".join(record["tiers"]))
        record['quote']=record['kind']+' · '+' · '.join(fields)
        if not any(other["quote"] == record["quote"] for other in result):
            result.append(record)
    return result


def record_offers(sources):
    from purchasing import Offer,Fact,Evidence,literal_in
    offers=[]
    for source in sources:
        for record in source.get('shop_products',[]):
            if record["kind"] == "Shop-Produktkarte" and not record["price"]:
                continue
            if record['quote'] not in source['text']:
                continue
            ev=Evidence(source_id=source['id'],quote=record['quote'][:650])
            # Each fact has a short exact transcript, independent of model quoting.
            def fact(field,value,unit=''):
                evidence=ev
                if not literal_in(value,evidence.quote):
                    found=re.search(r'(?<!\w)'+re.escape(value)+r'(?!\w)',record['quote'],re.I)
                    start=found.start() if found else record['quote'].find(value)
                    evidence=Evidence(source_id=source['id'],quote=record['quote'][max(0,start-70):start+len(value)+130])
                return Fact(field=field,value=value,unit=unit,evidence=evidence)
            facts=[]
            if record.get("seller_label"):
                facts.append(fact("actual_seller", record["seller"]))
            if record['price'] and record['currency'] and not record['conflicts']:
                facts.append(fact("price_from" if record.get("price_from") else "listed_price",
                                  record["price"],record["currency"]))
                if record['pack_size']:
                    facts.append(fact('pack_size',record['pack_size'],'Stück'))
                    if not (record.get("basis") or record.get("price_from")) and (record['kind'] != 'Shop-Produktkarte' or re.search(r'(?:pro|je|/)\s*Pack(?:ung)?\b',record['raw'],re.I)):
                        facts.append(fact('price_quantity',record['pack_size'],'Stück'))
                elif record.get("order"):
                    facts.append(fact("price_quantity","1","Stück"))
                    facts.append(fact("minimum_quantity",record["order"]["minimum"],"Stück"))
                if record.get("basis"):
                    facts.append(fact("price_quantity",record["basis"]["value"],record["basis"]["unit"]))
                if record['tax']!='offen':facts.append(fact('tax_status',record['tax']))
                if record.get("tiers"):
                    value = "; ".join(record["tiers"])
                    quote = "Preisstaffeln (Packung): " + value
                    facts.append(Fact(field="price_tiers",value=value,unit="",
                                      evidence=Evidence(source_id=source["id"],quote=quote)))
            if record['conflicts']:
                facts.append(fact('price_note','Variantenkonflikt'))
            props=record['properties']
            for field,keys in {'Kopfform':['Kopfform'],'Antrieb':['Antrieb Kürzel','Antrieb'],
                               'Durchmesser':['Durchmesser'],'Länge':['Gesamtlänge'],
                               'Werkstoff':['Werkstoffgruppe'],'Oberfläche':['Oberfläche'],'Gewindeart':['Gewindeausführung']}.items():
                value=next((props[key] for key in keys if props.get(key)),None)
                if value:
                    numeric=re.fullmatch(r'(\d+(?:[.,]\d+)?)\s*(mm)',value)
                    facts.append(fact(field,numeric[1],numeric[2]) if numeric else fact(field,value))
            for label,value in props.items():
                if value and " / " not in value and not any(f.field==label for f in facts):
                    numeric = re.fullmatch(r"(\d+(?:[.,]\d+)?)\s*(mm|cm|m|kg|g|l)",value,re.I)
                    facts.append(fact(label,numeric[1],numeric[2]) if numeric else fact(label,value))
            # Concrete attributes explicitly in the card title remain usable.
            for field,pattern in [('Kopfform',r'Senkkopf|Pan-Head|Halbrundkopf'),('Antrieb',r'TX\d*|Torx|T-Star'),('Maße',r'\d+(?:[,.]\d+)?\s*[x×]\s*\d+(?:[,.]\d+)?\s*(?:mm)?')]:
                match=re.search(pattern,record['name'],re.I)
                if match and not any(f.field==field for f in facts):facts.append(fact(field,match[0]))
            dimension=re.search(r'(\d+(?:[,.]\d+)?)\s*[x×]\s*(\d+(?:[,.]\d+)?)',record['name'])
            if dimension and 'mm' in record['quote'] and re.search(r"schraub|\bscrews?\b|\bbolts?\b", record['name'], re.I):
                for field,part in [('Durchmesser',1),('Länge',2)]:
                    if not any(f.field==field for f in facts):facts.append(fact(field,dimension[part],'mm'))
            offers.append(Offer(supplier=record['seller'],product=record['name'],identity=ev,facts=facts))
    return offers


def reconcile_web_offers(parsed, inferred, sources):
    from purchasing import marketplace_name, merge_offers, normalize

    lookup = {source["id"]: source for source in sources}
    def key(offer):
        source = lookup.get(offer.identity.source_id, {})
        url = source.get("product_url") or source.get("url")
        return (canonical(url), normalize(offer.product)) if url and source["kind"] == "web" else None

    identities = {}
    for offer in parsed:
        if key(offer) and not marketplace_name(offer, lookup):
            identities.setdefault(key(offer), []).append(offer)
    reconciled = []
    purchase_fields = {"listed_price", "price_quantity", "pack_size", "tax_status", "price_tiers"}
    for offer in inferred:
        matches = identities.get(key(offer), [])
        if not matches or marketplace_name(offer, lookup) or len({normalize(match.supplier) for match in matches}) != 1:
            reconciled.append(offer)
            continue
        verified = matches[0]
        authoritative = any(
            fact.field == "price_from" or fact.field == "listed_price" and "Produktdetail · Kaufbereich" in fact.evidence.quote
            for match in matches for fact in match.facts
        )
        facts = [fact for fact in offer.facts if not (
            authoritative and fact.field in purchase_fields
            and fact.evidence.source_id == offer.identity.source_id
        )]
        reconciled.append(offer.model_copy(update={"supplier": verified.supplier, "product": verified.product,
                                                   "identity": verified.identity, "facts": facts}))
    return merge_offers(parsed, reconciled)
