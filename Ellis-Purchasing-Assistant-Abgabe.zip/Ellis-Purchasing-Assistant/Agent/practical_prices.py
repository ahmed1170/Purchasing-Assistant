"""Evidence-based price units, pack rounding and comparable configurations."""
import re
from datetime import date
from decimal import Decimal, ROUND_CEILING

from purchasing import grounded, literal_in, normalize, number, quantity_number

CURRENCIES = {"EUR":r"eur\b|€","USD":r"usd\b|\$","GBP":r"gbp\b|£","CHF":r"chf\b",
              **{code:code.lower()+r"\b" for code in ("AUD","CAD","PLN","SEK","NOK","DKK","CZK")}}
MONEY = r"(?<![\w.,])\d+(?:[.,]\d+)?\s*(?:" + "|".join(CURRENCIES.values()) + ")"
TAX_RATE = r"(?:\d+(?:[.,]\d+)?\s*%\s*)?"
GROSS = r"\bbrutto\b|(?:inkl\.?|inklusive|mit|incl\.?|including)\s*(?:der\s+)?" + TAX_RATE + r"(?:gesetzl\.?\s+)?(?:mwst|ust|vat)"
NET = r"\bnetto\b|(?:zzgl\.?|exkl\.?|excl\.?|excluding)\s*(?:der\s+)?" + TAX_RATE + r"(?:gesetzl\.?\s+)?(?:mwst|ust|vat)"


def price_tax(quote,match):
    tail = re.split(MONEY,quote[match.end():],maxsplit=1)[0][:200]
    tail = re.split(r"produktlink:|anbiet(?:er|ername):",tail,maxsplit=1)[0]
    before = quote[:match.start()]
    if not re.search(MONEY,before):
        label = re.search(r"\b(netto|brutto)(?:preis)?\s*:?\s*$",before)
        if label:
            tail += " " + label[1]
    flags = (bool(re.search(GROSS,tail)),bool(re.search(NET,tail)))
    if flags == (False,False):
        statement = quote[match.end():match.end()+240]
        if re.search(r"\b(?:alle\s+)?preise\s+(?:"+GROSS+r")",statement):
            return "brutto"
    return {(True,False):"brutto",(False,True):"netto"}.get(flags,"offen")


def unit_name(value):
    unit = normalize(value).rstrip(".")
    if unit in {"stück","stk","st","stücken","stueck","pc","pcs","piece","pieces"} or re.fullmatch(r"[\w-]*(?:schrauben?|platten|bleche)",unit):
        return "Stück"
    return {"m":"m","meter":"m","metern":"m","lfm":"m","kg":"kg","kilogramm":"kg",
            "l":"l","liter":"l","litern":"l","m²":"m²","m2":"m²","quadratmeter":"m²"}.get(unit,"")


def demand_unit(position,sources):
    unit = unit_name(position.quantity_unit)
    if unit:
        return unit
    value = normalize(position.quantity_unit)
    source = sources.get(position.scope_evidence.source_id,{})
    count = re.escape(normalize(position.quantity))
    if (value and re.fullmatch(r"[^\W\d_]+(?:[- ][^\W\d_]+)*",value)
            and literal_in(value,normalize(position.name)) and source.get("kind") == "input"):
        direct = re.search(r"(?<![\w.,])"+count+r"\s+"+re.escape(value)+r"(?!\w)",normalize(source["text"]))
        descriptive = (grounded(position.scope_evidence,sources,position.quantity,position.quantity_unit,min_length=1)
                       and re.search(r"(?<![\w.,])"+count+r"\s+(?:[^\W\d_]+\s+){0,4}"+re.escape(value)+r"(?!\w)",
                                     normalize(position.scope_evidence.quote)))
        if direct or descriptive:
            return "Stück"
    return ""


def area_per_item(title, tail):
    # A package area is the area of one item only when both values agree.
    dimensions = re.search(r"(\d+(?:[.,]\d+)?)\s*[x×]\s*(\d+(?:[.,]\d+)?)(?:\s*[x×]\s*\d+(?:[.,]\d+)?)?\s*mm\b",title)
    coverage = re.search(r"\b(?:inhalt|packungsinhalt)\s*:\s*(\d+(?:[.,]\d+)?)\s*m²",tail)
    if dimensions and coverage:
        width,length = (Decimal(part.replace(",",".")) for part in dimensions.groups())
        area = Decimal(coverage[1].replace(",","."))
        if area > 0 and abs(width * length / Decimal(1_000_000) - area) <= Decimal(".0005"):
            return area
    return None


def configuration(position, offer, facts, unit):
    traits = {}
    aliases = {"Dicke":r"dicke|stärke|staerke", "Legierung":r"legierung|werkstoff|material",
               "Breite":r"breite", "Länge":r"^(?:nenn)?länge$", "Profil":r"profilform|querschnitt",
               "Durchmesser":r"durchmesser|gewindegröße","Kopf":r"kopfform","Antrieb":r"antrieb"}
    for name,pattern in aliases.items():
        criterion = next((item for item in position.must if re.search(pattern,normalize(item.field))),None)
        fact = next((item for field,item in facts.items() if re.search(pattern,normalize(field))),None)
        if name == "Länge" and unit in {"m","kg"} and not criterion:
            continue
        if criterion:
            traits[name] = normalize(criterion.target + " " + criterion.unit)
        elif fact:
            value = number(fact.value)
            traits[name] = (f"{value.normalize():f}" if value is not None else normalize(fact.value)) + " " + normalize(fact.unit)
    if not traits or re.search(r"schraub",normalize(offer.product)):
        dimensions = re.search(r"\d+(?:[.,]\d+)?\s*[x×]\s*\d+(?:[.,]\d+)?(?:\s*[x×]\s*\d+(?:[.,]\d+)?)?",normalize(offer.product))
        if dimensions:
            parts = re.split(r"\s*[x×]\s*",dimensions[0])
            traits["Maße"] = "x".join(f"{value.normalize():f}" if (value := number(part)) is not None else part
                                     for part in parts)
    return " · ".join(f"{name} {value.strip()}" for name,value in sorted(traits.items())) or "Ausführung noch unbestätigt"


def pdf_tier_schedule(text):
    """Read one explicitly labelled threshold table on a single-article sheet."""
    lines = text.splitlines()
    headers = [(i, match) for i, line in enumerate(lines) if (match := re.fullmatch(
        r"Mindestmenge\s*\((Stück|Stk\.?|Lose|Packungen|Gebinde)\)\s*\|\s*Preis in (EUR|CHF|GBP|USD) je "
        r"(Stück|Stk\.?|(?:Los|Packung|Gebinde)\s*[àa]\s*[1-9]\d*\s*Stück)", line, re.I))]
    if len(headers) != 1:
        return None
    index, header = headers[0]
    currency = header[2].upper()
    pack = re.search(r"[àa]\s*([1-9]\d*)", header[3], re.I)
    if bool(pack) == bool(unit_name(header[1])):
        return None
    if pack and normalize(header[1]) != {"los": "lose", "packung": "packungen", "gebinde": "gebinde"}[normalize(header[3]).split()[0]]:
        return None
    rows = []
    for line in lines[index + 1:]:
        match = re.fullmatch(r"(\d[\d.]*)\s*\|\s*(\d+(?:[,.]\d+)?)\s*" + currency, line, re.I)
        if not match:
            if "|" in line:
                return None
            break
        minimum, amount = quantity_number(match[1]), number(match[2])
        if minimum is None or amount is None or minimum <= 0 or amount <= 0 or rows and minimum <= rows[-1][0]:
            return None
        rows.append((minimum, amount, match[2]))
    if len(rows) < 2:
        return None
    return currency, Decimal(pack[1]) if pack else Decimal(1), header[1], rows, index + len(rows)


def practical_price(offer, facts, position, sources):
    price = facts.get("listed_price")
    schedule = facts.get("pdf_price_schedule")
    selected_tier = None
    packing_from_tier = None
    tier_name = ""
    if schedule and schedule.evidence.source_id == offer.identity.source_id:
        page = sources[schedule.evidence.source_id]
        parsed = pdf_tier_schedule(schedule.evidence.quote) if page["kind"] == "pdf" else None
        if parsed and literal_in(offer.product, schedule.evidence.quote):
            from purchasing import Fact
            currency, packing_from_tier, tier_name, rows, _ = parsed
            qty = quantity_number(position.quantity)
            order = (qty / packing_from_tier).to_integral_value(rounding=ROUND_CEILING) if qty and demand_unit(position, sources) == "Stück" else None
            selected_tier = max((row for row in rows if order is not None and row[0] <= order), default=rows[0])
            price = Fact(field="listed_price", value=selected_tier[2], unit=currency, evidence=schedule.evidence)
    if not price:
        return {}, {}
    amount = number(price.value)
    quote = normalize(price.evidence.quote)
    currency_pattern = CURRENCIES.get(price.unit)
    amount_pattern = r"(?<![\w.,])" + re.escape(normalize(price.value))
    match = re.search(amount_pattern+r"\s*(?:"+currency_pattern+")",quote) if currency_pattern else None
    page = sources[price.evidence.source_id]
    if not match and currency_pattern and page["kind"] == "pdf":
        lines = price.evidence.quote.splitlines()
        if len(lines) == 2 and "|" in lines[0] and re.search(r"\|\s*" + amount_pattern + r"$", normalize(lines[0])):
            last_cell = normalize(lines[1].rsplit("|", 1)[-1])
            if re.fullmatch(r"(?:" + currency_pattern + r")\s*\*?", last_cell):
                quote = normalize(lines[0]) + " " + last_cell
                match = re.search(amount_pattern + r"\s*(?:" + currency_pattern + ")", quote)
    if (amount is None or amount <= 0 or not match or not literal_in(offer.product,price.evidence.quote)
            or re.search(r"\b(?:ab|from)\s*:?\s*$",quote[:match.start()])):
        return {}, {}
    records = [r for r in page.get("shop_products",[]) if normalize(r["name"]) == normalize(offer.product)]
    if records and all(record.get("price_from") for record in records):
        return {}, {}
    tax_fact = facts.get("tax_status")
    tax = price_tax(quote,match)
    if selected_tier:
        tax = "brutto" if re.search(GROSS, quote) and not re.search(NET, quote) else "netto" if re.search(NET, quote) and not re.search(GROSS, quote) else "offen"
    if tax_fact:
        first,second = sources[price.evidence.source_id],sources[tax_fact.evidence.source_id]
        if tax == "offen" and (first is second or first.get("url") and first.get("url") == second.get("url")
                                or first.get("path") and first.get("path") == second.get("path")):
            tax_quote = normalize(tax_fact.evidence.quote)
            matching_amount = [item for item in re.finditer(MONEY,tax_quote)
                               if number(re.match(r"[\d.,]+",item[0])[0]) == amount]
            if len(matching_amount) == 1:
                tax = price_tax(tax_quote,matching_amount[0])
            elif not re.search(MONEY,tax_quote) and len(re.findall(MONEY,quote)) == 1:
                gross,net = bool(re.search(GROSS,tax_quote)),bool(re.search(NET,tax_quote))
                tax = {(True,False):"brutto",(False,True):"netto"}.get((gross,net),"offen")
    info = {"value":float(amount),"raw":price.value,"currency":price.unit,"tax":tax,"pack_size":None,
            "evidence":price.evidence.model_dump(),"shipping":"offen"}
    if tax_fact:
        info["tax_evidence"] = tax_fact.evidence.model_dump()
    dated = facts.get("price_date")
    if dated:
        info["date"],info["date_evidence"] = dated.value,dated.evidence.model_dump()
        years = re.findall(r"\b20\d{2}\b",dated.value)
        info["historical"] = bool(years and int(years[-1]) < date.today().year)
    tail = quote[match.end():]
    # A later base-price amount must not become the unit of the first price.
    later_price = re.search(MONEY,tail)
    if later_price:
        tail = tail[:later_price.start()]
    basis = re.search(r"(?:pro\s+|je\s+|/\s*)(?:(\d+(?:[.,]\d+)?)\s*)?(stück|stk\.?|st\b|m²|m2\b|quadratmeter|meter|m\b|kilogramm|kg\b|liter|l\b|rolle|packung|pack\b)",tail[:180])
    priced_amount = quantity_number(basis[1]) if basis and basis[1] else Decimal(1)
    priced_unit = unit_name(basis[2]) if basis else ""
    package = bool(basis and not priced_unit)
    basis_fact = facts.get("price_quantity")
    if basis_fact and unit_name(basis_fact.unit) and quantity_number(basis_fact.value):
        priced_amount,priced_unit,package = quantity_number(basis_fact.value),unit_name(basis_fact.unit),False
        info["basis_evidence"] = basis_fact.evidence.model_dump()
    elif not priced_unit and (note := facts.get("price_basis_note")) and note.evidence.source_id == price.evidence.source_id:
        documented = re.fullmatch(r"(?:pro\s+|je\s+|per\s+|/\s*)(?:(\d+(?:[.,]\d+)?)\s*)?(stück|stk\.?|pcs|m²|kg|m|l)", normalize(note.value))
        if documented:
            priced_amount = quantity_number(documented[1]) if documented[1] else Decimal(1)
            priced_unit, package = unit_name(documented[2]), False
            info["basis_evidence"] = note.evidence.model_dump()
    pack_fact = facts.get("pack_size")
    pack_amount = quantity_number(pack_fact.value) if pack_fact else None
    pack_unit = unit_name(pack_fact.unit) if pack_fact else ""
    if selected_tier:
        priced_amount, priced_unit = packing_from_tier, "Stück"
        pack_amount, pack_unit = packing_from_tier, "Stück"
        info["tier_evidence"] = schedule.evidence.model_dump()
        info["basis_evidence"] = schedule.evidence.model_dump()
    if not pack_amount:
        explicit_pack = re.search(
            r"(?:packungsgrösse|packungsinhalt|vpe|verpackungseinheit)\s*[:=]?\s*(\d[\d.,]*)\s*(stück|stk\.?|meter|kg)\b",
            quote,
        )
        if explicit_pack:
            pack_amount,pack_unit = quantity_number(explicit_pack[1]),unit_name(explicit_pack[2])
            info["pack_evidence"] = price.evidence.model_dump()
    title = normalize(offer.product)
    titled_pack = re.search(r"(\d+(?:[.,]\d+)?)\s*(stück|stk\.?|meter|m\b|kilogramm|kg\b)",title)
    if not pack_amount and titled_pack:
        pack_amount,pack_unit = quantity_number(titled_pack[1]),unit_name(titled_pack[2])
    if not priced_unit and ("preis der variante" in quote or package):
        priced_amount,priced_unit = (pack_amount,pack_unit) if pack_amount and pack_unit else (
            (None,""))
    requested_unit = demand_unit(position,sources)
    area = area_per_item(title,tail) if requested_unit == "Stück" else None
    if area and priced_unit in {"","m²"}:
        priced_amount,priced_unit = Decimal(1),"Stück"
        info["basis_evidence"] = price.evidence.model_dump()
    if not priced_unit or not priced_amount or priced_amount <= 0:
        return info, {}
    info.update(basis_quantity=float(priced_amount),basis_unit=priced_unit,
                price_basis=f"{priced_amount:g} {priced_unit}",
                configuration=configuration(position,offer,facts,priced_unit))
    info["pack_size"] = float(pack_amount) if pack_amount and pack_unit == "Stück" else None
    if pack_fact:
        info["pack_evidence"] = pack_fact.evidence.model_dump()
    price_per_unit = amount / priced_amount
    qty = quantity_number(position.quantity)
    metrics = {}
    required = " · ".join(f"{item.field} {item.target} {item.unit}" for item in position.must)
    geometry = [part for part in info["configuration"].split(" · ")
                if not part.startswith("Legierung ") and not part.startswith("Ausführung ")
                and priced_unit != "kg"]
    if re.search(r"schraub",title) and any(part.startswith("Maße ") for part in geometry):
        # The screw's nominal dimensions and drive family form the price basis.
        # Head thickness and bit numbers from richer tables are additional details.
        geometry = [part for part in geometry if not part.startswith(("Durchmesser ","Länge ","Dicke ","Kopf ","Antrieb "))]
        if re.search(r"\b(?:tx|torx)\s*\d*",title) or any(
                part.startswith(("Antrieb tx","Antrieb torx")) for part in info["configuration"].split(" · ")):
            geometry.append("Antrieb tx")
        if re.search(r"\b(?:pan[- ]head|halbrundkopf)\b",title):
            geometry.append("Kopfausführung Halbrundkopf")
        if "flansch" in title or "sperrkant" in title:
            geometry.append("Kopfausführung " + ("Flansch" if "flansch" in title else "Sperrkant"))
    if any(re.search(r"\d\s*[x×]\s*\d",item.target) for item in position.must):
        # A requested 4 x 40 mm already defines the geometry for both records.
        # A supplier's additional separate diameter/length fields are not a
        # different product basis from an equivalent dimension in a card title.
        geometry = [part for part in geometry if not part.startswith(("Maße ","Durchmesser ","Länge ","Breite "))]
    info["comparison_configuration"] = required + " | " + " · ".join(geometry)
    basis_key = f"{tax}|{price.unit}|{priced_unit}|{info['comparison_configuration']}|" + ("historisch:" + info["date"] if info.get("historical") else "aktuell")
    if tax != "offen":
        key = "unit_net_price" if tax == "netto" else "unit_gross_price"
        metrics[key] = {"value":float(price_per_unit),"fact":price.model_dump(),
                        "basis":"unit|"+basis_key,
                        "calculation":f"{amount:g} {price.unit} ÷ {priced_amount:g} {priced_unit} = {price_per_unit:.4f} {price.unit}/{priced_unit} ({tax}), Versand offen."}
    if qty and qty > 0 and requested_unit == priced_unit:
        minimum = facts.get("minimum_quantity") or facts.get("minimum_order_quantity")
        needed = qty
        if selected_tier:
            needed = max(qty, selected_tier[0] * packing_from_tier)
        if minimum and unit_name(minimum.unit) == priced_unit:
            minimum_amount = quantity_number(minimum.value)
            if minimum_amount and minimum_amount > 0:
                needed = max(qty,minimum_amount)
                info["minimum_evidence"] = minimum.evidence.model_dump()
        packing = pack_amount if pack_amount and pack_unit == priced_unit else priced_amount if package else Decimal(1) if priced_unit == "Stück" else None
        supplied = (needed / packing).to_integral_value(rounding=ROUND_CEILING) * packing if packing else needed
        order_amount = supplied / packing if packing else needed
        tier_note = f" Preisstaffel ab {selected_tier[0]:g} {tier_name}." if selected_tier else ""
        tiers = facts.get("price_tiers")
        if (tiers and tiers.evidence.source_id == price.evidence.source_id and priced_amount == packing
                and packing and "Preisstaffeln (Packung): " in tiers.evidence.quote):
            applicable = [(int(threshold),number(value)) for threshold,value in
                          re.findall(r"(\d+)\+ Einheiten (\d+[.,]\d{2}) EUR",tiers.value)
                          if int(threshold) <= order_amount]
            if applicable:
                threshold, tier_price = max(applicable)
                price_per_unit = tier_price / priced_amount
                amount = tier_price
                info["tier_evidence"] = tiers.evidence.model_dump()
                tier_note = f" Veröffentlichte Preisstaffel ab {threshold} Packungen."
        subtotal = (supplied * price_per_unit).quantize(Decimal(".01"))
        info.update(order_quantity=float(supplied / packing) if packing else float(qty),
                    order_unit=(tier_name if selected_tier and packing != 1 else "Packungen") if packing and packing != 1 else priced_unit,
                    supplied_quantity=float(supplied),supplied_unit=priced_unit,
                    goods_value=float(subtotal),calculation=(
                        f"Bestellmenge {supplied:g} {priced_unit}"
                        + (f" ({supplied / packing:g} Packungen à {packing:g} {priced_unit})" if packing and packing != 1 else "")
                        + f" ÷ {priced_amount:g} × {amount:g} {price.unit} = {subtotal:.2f} {price.unit} {tax} vor Versand."
                        + (f" Der ausgewiesene Gebindepreis deckt {area:g} m² je Stück ab." if area else "") + tier_note))
        if tax != "offen":
            key = "net_price" if tax == "netto" else "gross_goods_price"
            metrics[key] = {"value":float(subtotal),"fact":price.model_dump(),
                            "basis":f"order|{basis_key}|{qty:g}","calculation":info["calculation"]}
    return info,metrics
