import json
from unittest.mock import Mock, patch

import pytest
from bs4 import BeautifulSoup

from shop_evidence import shop_records,record_offers
from price_diagnostics import diagnose_prices
from purchasing import evaluate, Fact, Evidence
from test_price_distance import case, WEIGHTS


def test_discovery_uses_exact_product_card_when_detail_price_is_missing():
    from research import discover
    product = 'https://www.hornbach.de/p/test/123/'
    search = 'https://www.hornbach.de/s/Test'
    detail = dict(kind='web',url=product,text='Testprodukt ohne Preis',shop_search=search)
    matching = dict(kind='web',url=search,product_url=product,text='Passende Produktkarte')
    other = dict(kind='web',url=search,product_url=product.replace('123','456'),text='Andere Produktkarte')
    with patch('research.search_one',return_value=([{'href':product}],None)), \
            patch('research.fetch',side_effect=lambda url: ([detail],[]) if url==product else ([matching,other],[])):
        pages,_ = discover(['Test Schraube'],set(),3)
    assert matching in pages
    assert other not in pages


def sources_for(html,url='https://shop.example/s/screws'):
    records=shop_records(BeautifulSoup(html,'html.parser'),url)
    return [dict(id=f'Q{i+2}',kind='web',url=url,product_url=r['product_url'],
                 text=r['quote'],shop_products=[r],retrieved_at='2026-11-19T12:00:00+00:00') for i,r in enumerate(records)]


@pytest.mark.parametrize(("quantity", "rolls", "total"), [("30", 6, 105.90), ("31", 7, 123.55)])
def test_microdata_roll_offer_with_text_values_and_tax_footnote(quantity, rolls, total):
    html = """
    <main itemscope itemtype="http://schema.org/Product">
      <h1 itemprop="name">Isolierschlauch, Rolle 5 m, blau</h1>
      <span itemprop="sku">IS-05-B</span>
      <div itemprop="offers" itemscope itemtype="https://schema.org/Offer">
        <link itemprop="url" href="">
        <div>17,65 € <span>*</span>
          <div><span itemprop="price">17.65</span><span itemprop="priceCurrency">EUR</span></div>
        </div>
      </div>
      <div>* <span>inkl. MwSt., zzgl. Versandkosten</span></div>
    </main>"""
    [page] = sources_for(html)
    [offer] = record_offers([page])
    position, sources = case(False, quantity)
    position.quantity_unit = "m"
    position.scope_evidence.quote = f"{quantity} m"
    sources["Q1"]["text"] = f"{quantity} m Isolierschlauch"
    [row] = evaluate(position, [offer], sources | {page["id"]: page}, [], WEIGHTS)
    price = row["listed_price"]
    assert price["price_basis"] == "5 m"
    assert price["order_quantity"] == rolls and price["supplied_quantity"] == rolls * 5
    assert price["goods_value"] == total
    assert row["metrics"]["gross_goods_price"]["value"] == total
    assert "inkl. MwSt." in price["evidence"]["quote"]

    [entry] = sources_for(html.replace("17,65 €", "ab 17,65 €"))
    [from_price] = record_offers([entry])
    assert [fact.field for fact in from_price.facts if "price" in fact.field] == ["price_from"]
    assert not sources_for(html.replace('itemprop="url" href=""', 'itemprop="url" href="/andere-variante"'))


def test_catalog_reseller_price_uses_exact_manufacturer_and_sales_pack():
    from catalog_web import matching_article_offers
    from purchasing import Offer
    html = """<h1>Alto Kabelbinder schwarz</h1>
      <script type="application/ld+json">{"@type":"Product","name":"Alto Kabelbinder schwarz",
      "mpn":"KB123","brand":{"name":"Alto"},"offers":{"@type":"Offer","seller":{"name":"Musterhandel"},
      "price":"10.00","priceCurrency":"EUR"}}</script>
      <table><tr><td>10,00 EUR (11,90 EUR inkl. MwSt.)</td></tr>
      <tr><td><strong>Verkaufseinheit:</strong> 100 Stück</td></tr></table>"""
    pages = sources_for(html)
    identity = Evidence(source_id="Q8", quote="Alto KB123")
    article = Offer(supplier="Alto", product="KB123", identity=identity, facts=[])
    other = article.model_copy(update={"product": "KB124"})
    [offer] = matching_article_offers([article, other], pages)
    assert offer.supplier == "Musterhandel"
    values = {fact.field: fact.value for fact in offer.facts}
    assert (values["listed_price"], values["pack_size"], values["price_quantity"], values["tax_status"]) == (
        "11,90", "100", "100", "brutto")
    position, sources = case(False, "500")
    sources.update({source["id"]: source for source in pages})
    [row] = evaluate(position, [offer], sources, [], WEIGHTS)
    assert row["listed_price"]["goods_value"] == 59.50
    assert row["listed_price"]["order_quantity"] == 5


def test_marketplace_selected_offer_keeps_merchant_and_pack_price():
    from purchasing import seller_confirmed
    url = "https://www.voelkner.de/products/Kabelbinder-KB123.html"
    html = """<h1>Alto Kabelbinder KB123 4.8 x 200 mm 100 St.</h1>
      <div>11 ,90 € inkl. MwSt. zzgl. Versand Pack
      <section><article class="js_condition_offer_card">
      <span class="selectionCard__item__header__label__content__price">11,90 €</span>
      <span class="seller__label">Verkauf &amp; Versand:</span>
      <a class="seller__info__link">Musterhandel.de</a>
      </article></section></div>"""
    pages = sources_for(html, url)
    [offer] = record_offers(pages)
    assert offer.supplier == "Musterhandel.de"
    assert seller_confirmed(offer, {page["id"]: page for page in pages})
    assert any(f.field == "price_quantity" and f.value == "100" for f in offer.facts)
    assert not any(f.field == "Durchmesser" for f in offer.facts)
    assert not sources_for(html.replace(">11,90 €", ">12,90 €"), url)


def test_official_shop_search_follows_detail_with_exact_sku():
    from research import shop_article_pages
    from catalog_web import deduplicate_catalog_offers, matching_article_offers
    from purchasing import Offer
    root = "https://laden.example/"
    search = root + "advanced_search_result.php"
    wrong, right = root + "anderes.html", root + "passend.html"

    def product(code, url):
        html = f"""<form><h1>Kabelbinder 100 Stück</h1>
                <div itemprop="sku">{code}</div>
                <div><span class="productprice">3,10 EUR</span> inkl. 19 % MwSt.</div></form>"""
        return sources_for(html, url)

    pages = {root: [{"shop_search_form": (search, "keywords")}],
             search + "?keywords=KB123": [{"shop_search_links": [wrong, right]}],
             wrong: product("KB456", wrong), right: product("KB123", right)}
    with patch("research.fetch", side_effect=lambda url: (pages[url], [])):
        found, warnings = shop_article_pages(("Laden.Example", "KB123"))
    assert not warnings and [page["url"] for page in found] == [right]
    article = Offer(supplier="laden.example", product="KB123", facts=[],
                    identity=Evidence(source_id="Q1", quote="laden.example KB123"))
    [priced] = matching_article_offers([article], found)
    assert priced.identity == article.identity
    assert any(f.field == "listed_price" and f.value == "3,10" for f in priced.facts)
    sources = {"Q1": {"kind": "pdf"}, **{page["id"]: page for page in found}}
    assert deduplicate_catalog_offers([priced, *record_offers(found)], sources) == [priced]


def test_shop_card_links_variant_pack_tax_and_price_without_detail_price():
    sources=sources_for('''<meta property="og:site_name" content="Testshop">
      <li data-testid="article-card"><a data-testid="article-title" href="/p/plate-a/123/">Aluminiumplatte 100 Stück</a>Preis — 3,10 € inkl. MwSt. pro Pack</li>
      <li data-testid="article-card"><a data-testid="article-title" href="/p/plate-b/456/">Aluminiumplatte 200 Stück</a>Preis — 99,00 € inkl. MwSt. pro Pack</li>''')
    p,lookup=case(False,'1000')
    lookup.update({s['id']:s for s in sources})
    rows=evaluate(p,record_offers(sources),lookup,[],WEIGHTS)
    diagnose_prices(rows,sources)
    first=next(row for row in rows if row['product']=='Aluminiumplatte 100 Stück')
    assert first['metrics']['gross_goods_price']['value']==31
    assert first['listed_price']['order_quantity']==10
    assert first['listed_price']['source_url']=='https://shop.example/s/screws'
    assert first['listed_price']['product_url'].endswith('/123/')
    assert first['listed_price']['evidence_kind']=='Shop-Produktkarte'
    assert first['listed_price']['retrieved_at']=='2026-11-19T12:00:00+00:00'


def test_card_with_two_distinct_variant_links_is_not_a_price_record():
    assert not sources_for('''<li data-testid="article-card"><a href="/p/a/123/">Aluminiumplatte 100 Stück</a><a href="/p/b/456/">Andere Variante</a>Preis — 3,10 € inkl. MwSt.</li>''')


def detail_html(title='Aluminiumplatte 100 Stück',pack='100 Stück',diameter='4 mm'):
    return f'''<meta property="og:site_name" content="Testshop"><h1>{title}</h1>
      <div class="product-detail-buy"><div itemprop="offers"><meta itemprop="url" content="https://shop.example/p/a/123/">
      <meta itemprop="priceCurrency" content="EUR"><div class="product-detail-price-container"><meta itemprop="price" content="7.3">7,30 € inkl. MwSt.</div></div></div>
      <select><option>999 Stück</option><option selected>100 Stück</option></select>
      <table class="product-detail-properties-table"><tr><th>Inhalt (VPE):</th><td>{pack}</td></tr>
      <tr><th>Durchmesser:</th><td>{diameter}</td></tr></table>'''


def test_selected_variant_ignores_other_configurator_choices():
    sources=sources_for(detail_html(), 'https://shop.example/p/a/123/')
    p,lookup=case(False,'1000');lookup.update({s['id']:s for s in sources})
    row=evaluate(p,record_offers(sources),lookup,[],WEIGHTS)[0]
    assert row['metrics']['gross_goods_price']['value']==73
    assert row['listed_price']['pack_size']==100


def test_conflicting_pack_size_is_visible_but_not_priced():
    sources=sources_for(detail_html(pack='500 Stück'), 'https://shop.example/p/a/123/')
    p,lookup=case(False,'1000');lookup.update({s['id']:s for s in sources})
    rows=evaluate(p,record_offers(sources),lookup,[],WEIGHTS)
    diagnose_prices(rows,sources)
    assert not rows[0]['listed_price']
    assert 'Variantenbezug unklar' in rows[0]['reasons']['material_price']
    assert 'Packungsgröße' in rows[0]['reasons']['material_price']


def test_jsonld_price_without_pack_or_unit_does_not_invent_piece_price():
    html='''<meta property="og:site_name" content="Testshop"><script type="application/ld+json">{"@type":"Product","name":"Aluminiumplatte","offers":{"@type":"Offer","price":7.3,"priceCurrency":"EUR"}}</script>inkl. MwSt.'''
    sources=sources_for(html,'https://shop.example/p/a/123/')
    p,lookup=case(False,'1000');lookup.update({s['id']:s for s in sources})
    rows=evaluate(p,record_offers(sources),lookup,[],WEIGHTS)
    assert rows[0]['listed_price']['value']==7.3
    assert not rows[0]['listed_price'].get('goods_value')
    assert not rows[0]['metrics']


def test_screenshot_prices_combine_with_distance_on_same_basis():
    from purchasing import recommendation

    url = "https://shop.example/p/swg/7817931/"
    name = "SWG Spanplattenschraube Senkkopf TX 4x40 mm 200 Stück"
    ld = json.dumps({"@type":"Product", "name":name, "offers":{
        "@type":"Offer", "price":"7.50", "priceCurrency":"EUR", "url":url}})
    page = f'<meta property="og:site_name" content="HORNBACH"><script type="application/ld+json">{ld}</script>'
    price_box = ('<section data-testid="product-informations"><div data-testid="prices">'
                 '<span>Preis — 7,50 € * Alle Preise inkl. MwSt. pro Pack</span></div></section>')
    assert sources_for(page + price_box.replace("7,50", "8,50"), url)[0]["shop_products"][0]["tax"] == "offen"
    assert sources_for(page + "<footer>Alle Preise inkl. MwSt.</footer>", url)[0]["shop_products"][0]["tax"] == "offen"

    other = detail_html('200 Spanplattenschrauben 4x40 Senkkopf Fräsrippen TX20',pack="200 Stück")
    other = other.replace('7.3', '6.50').replace('7,30', '6,50').replace('Testshop','BefestigungsFuchs')
    other_source = sources_for(other,'https://shop.example/p/a/123/')[0] | {"id":"Q3"}
    position, lookup = case(False,"1000")
    lookup.update({"Q3":other_source})
    for tax_label, expected in ((price_box, True), ("", False)):
        first = sources_for(page + tax_label,url)[0]
        lookup["Q2"] = first
        offers = record_offers([first,other_source])
        for i,(offer,km) in enumerate(zip(offers,("15.66","596.92")),4):
            source_id = f"Q{i}"
            quote = f"Straßenentfernung nach Berlin: {km} km."
            lookup[source_id] = {"kind":"pdf","text":quote}
            offer.facts.append(Fact(field="distance_km",value=km,unit="km",
                                    evidence=Evidence(source_id=source_id,quote=quote)))
        rows = evaluate(position,offers,lookup,[],WEIGHTS)
        if expected:
            assert [(row["supplier"],row["score"]) for row in rows] == [
                ("BefestigungsFuchs",85.09),("HORNBACH",82.64)]
            assert rows[1]["components"] == {"gross_goods_price":65.77,"distance_km":16.87}
            assert rows[0]["components"] == {"gross_goods_price":72,"distance_km":13.09}
            assert rows[1]["listed_price"]["goods_value"] == 37.50
            assert rows[1]["criterion_points"]["price"]["reference"] == 32.50
            assert recommendation(rows).startswith("Empfehlung: BefestigungsFuchs")
            weighted = evaluate(position,offers,lookup,[],{"total_price":98,"distance_km":2})
            assert weighted[0]["supplier"] == "BefestigungsFuchs"
            assert recommendation(weighted).startswith("Empfehlung: BefestigungsFuchs")
        else:
            assert rows[0]["supplier"] == "BefestigungsFuchs" and rows[0]["score"] == 69.09
            assert rows[1]["partial_score"]["value"] == 16.87
            assert recommendation(rows).startswith("Vorläufige Empfehlung: BefestigungsFuchs")


def test_missing_price_diagnostics_distinguish_processing_loss_from_no_publication():
    sources=sources_for(detail_html(), 'https://shop.example/p/a/123/')
    p,lookup=case(False);lookup.update({s['id']:s for s in sources})
    offers=record_offers(sources)
    offers[0].facts=[f for f in offers[0].facts if f.field!='listed_price']
    rows=evaluate(p,offers,lookup,[],WEIGHTS);diagnose_prices(rows,sources)
    assert 'bei der Verarbeitung verloren' in rows[0]['reasons']['material_price']
    sources[0]['shop_products']=[];sources[0]['text']='Produktinformation ohne Preis.'
    diagnose_prices(rows,sources)
    assert 'Kein Preis veröffentlicht' in rows[0]['reasons']['material_price']
    hint=dict(id=sources[0]['id'],kind='search',url='https://shop.example/p/a/123/',text='Suchhinweis')
    diagnose_prices(rows,[hint],['https://shop.example/p/a/123/ · Abruf fehlgeschlagen: HTTP 503'])
    assert 'Abruf fehlgeschlagen' in rows[0]['reasons']['material_price']


def test_selected_buy_box_supports_unit_price_and_published_pack_tiers():
    url = "https://shop.example/p/a/123/"
    html = detail_html("Sechskantschraube M8 x 30", pack="",diameter="8 mm").replace(
        "</div></div>\n      <select>",'''</div><div><input type="number" min="1" name="lineItems[a][quantity]"><span>ST</span></div></div>
      <select>''')
    sources = sources_for(html,url)
    position, lookup = case(False,"100")
    lookup.update({source["id"]:source for source in sources})
    row = evaluate(position,record_offers(sources),lookup,[],WEIGHTS)[0]
    assert row["listed_price"]["goods_value"] == 730
    assert row["listed_price"]["price_basis"] == "1 Stück"
    name = "Sechskantschrauben M8 x 30 Beutel 10"
    ld = json.dumps({"@type":"Product", "name":name,"offers":{"@type":"Offer",
                     "price":"22.3","priceCurrency":"EUR","url":url}})
    pack = f'''<main><section><h1>{name}</h1><span>Packung von 10</span>
        <span>22,30 €</span><span>2,23 € pro Stück</span>Inkl. MwSt.</section>
        <div><h2>Mehr kaufen, mehr sparen</h2>
        <div><span>6+ Einheiten</span><s>22,30 €</s><b>5,12 €</b></div>
        <div><span>48+ Einheiten</span><s>22,30 €</s><b>2,27 €</b></div></div></main>'''
    sources = sources_for(f'<script type="application/ld+json">{ld}</script>'+pack,url)
    lookup.update({source["id"]:source for source in sources})
    row = evaluate(position,record_offers(sources),lookup,[],WEIGHTS)[0]
    assert row["listed_price"]["order_quantity"] == 10
    assert row["listed_price"]["goods_value"] == 51.20
    assert row["metrics"]["gross_goods_price"]["value"] == 51.20
    assert "6+ Einheiten" in row["listed_price"]["tier_evidence"]["quote"]


def test_legacy_shop_buy_box_ignores_old_and_related_prices():
    html = '''<h1>Sechskantschrauben M8 x 12 (200 Stück)</h1>
      <div class="buybox--inner"><span class="price--content"><meta itemprop="price" content="70.30"></span>
      <meta itemprop="priceCurrency" content="EUR"><meta itemprop="price" content="108.97">
      <p class="product--tax">* inkl. MwSt.</p></div>
      <div><meta itemprop="price" content="19.90"></div>'''
    sources = sources_for(html,"https://shop.example/p/screw")
    position,lookup = case(False,"100")
    lookup.update({source["id"]:source for source in sources})
    row = evaluate(position,record_offers(sources),lookup,[],WEIGHTS)[0]
    assert row["listed_price"]["supplied_quantity"] == 200
    assert row["metrics"]["gross_goods_price"]["value"] == 70.30


def test_standard_price_reference_and_count_noun_work_without_shop_specific_markup():
    name = "Kabelbinder 200 x 4,8 mm, 50 Stück"
    data = {"@type":"https://schema.org/Product","name":name,"offers":{
        "@type":"Offer","priceSpecification":{"@type":"UnitPriceSpecification","price":"12.00",
        "priceCurrency":"CHF","valueAddedTaxIncluded":True,
        "referenceQuantity":{"value":100,"unitCode":"C62"}}}}
    pages = sources_for(f'<h1>{name}</h1><script type="application/ld+json">{json.dumps(data)}</script>',
                        "https://another-shop.example/cable-ties")
    position,lookup = case(False,"120")
    position.name,position.quantity_unit = "Kabelbinder","Kabelbinder"
    lookup["Q1"]["text"] = "120 Kabelbinder nach Berlin."
    lookup.update({page["id"]:page for page in pages})
    row = evaluate(position,record_offers(pages),lookup,[],WEIGHTS)[0]
    assert row["listed_price"]["goods_value"] == 18
    assert row["listed_price"]["supplied_quantity"] == 150
    assert row["listed_price"]["currency"] == "CHF"
    assert row["listed_price"]["price_basis"] == "100 Stück"
    assert "|CHF|" in row["metrics"]["gross_goods_price"]["basis"]


def test_structured_seller_address_needs_no_additional_model_call():
    from shop_evidence import organization_lines
    from supplier_locations import research_locations
    from workflow import add_sources
    from test_price_distance import candidate
    shop = "Example Shop"
    url = "https://example-shop.example/cable-ties"
    data = {"@type":"Organization","name":shop,"url":"https://example-shop.example/",
            "address":{"addressLocality":"Dublin","addressCountry":"IE","streetAddress":"8 Example Road"}}
    soup = BeautifulSoup(f'<script type="application/ld+json">{json.dumps(data)}</script>',"html.parser")
    _,lookup = case(False)
    offer = candidate(lookup,shop,"12")
    source = lookup[offer.identity.source_id]
    source.update(kind="web",url=url,title=shop,text="\n".join(organization_lines(soup,url))+ "\n" + source["text"])
    pages = [dict(id=key,**value) for key,value in lookup.items()]
    model = Mock()
    with patch("supplier_locations.fetch",side_effect=AssertionError("address already verified")):
        research_locations(model,"",[offer],pages,add_sources,[])
    model.ask.assert_not_called()
    assert any(f.field=="company_address" and f.value=="8 Example Road Dublin IE" for f in offer.facts)


def test_public_page_cache_retains_original_evidence_and_retries_failures():
    from research import fetch
    url = "https://cache.example/product"
    source = {"text":"data","retrieved_at":"original"}
    with patch("research.WEB_CACHE",__import__("collections").OrderedDict()), \
         patch("research.fetch_uncached",side_effect=[([],["temporary"]),([source],[])]) as request:
        assert not fetch(url)[0]
        fetched,_ = fetch(url)
        fetched[0]["text"] = "changed in a report"
        assert fetch(url)[0] == [{"text":"data","retrieved_at":"original"}]
        assert request.call_count == 2


def test_compact_model_context_retains_late_price_and_packaging_quote():
    from workflow import context
    evidence = "Preis je Rolle: 41,20 EUR inklusive MwSt. Preisbezug 50 m."
    source = {"id":"Q2","kind":"web","title":"Verlegekabel",
              "text":("Menü Preis Versand Angebote Kategorien " * 180) + evidence}
    visible = context([source],3400,[],"Verlegekabel",web_limit=3400)
    assert len(visible[0]["text"]) <= 3400
    assert evidence in visible[0]["text"]


def test_supplier_location_is_reused_for_all_products_without_model_or_fetch():
    from supplier_locations import research_locations
    from workflow import add_sources
    from test_price_distance import candidate
    p,sources=case(False)
    one=candidate(sources,'Testwerk','10');two=candidate(sources,'Testwerk','20')
    two.product += ' zweite Ausführung'
    sid=one.identity.source_id
    quote='Testwerk Firmenstandort Stuttgart.'
    sources[sid]['text']+=' '+quote
    one.facts.append(Fact(field='company_city',value='Stuttgart',unit='',evidence=Evidence(source_id=sid,quote=quote)))
    pages=[dict(id=key,**value) for key,value in sources.items()]
    model=Mock()
    with patch('supplier_locations.fetch',side_effect=AssertionError('must reuse evidence')):
        research_locations(model,'',[one,two],pages,add_sources,[])
    model.ask.assert_not_called()
    assert any(f.field=='company_city' and f.value=='Stuttgart' for f in two.facts)


def test_each_shop_card_survives_source_deduplication():
    from workflow import add_sources
    sources=[]
    add_sources(sources,[dict(kind='web',url='https://shop.example/s/',product_url=f'https://shop.example/p/{i}/',text=f'Product {i}') for i in range(3)])
    assert len(sources)==3


def test_product_card_and_detail_with_conflicting_pack_sizes_block_price_points():
    card=sources_for('''<meta property="og:site_name" content="Testshop"><li data-testid="article-card"><a href="/p/a/123/">Aluminiumplatte 200 Stück</a>Preis — 8,10 € inkl. MwSt. pro Pack</li>''')
    detail=sources_for(detail_html(),'https://shop.example/p/a/123/')
    detail[0]['id']='Q3'
    sources=card+detail
    p,lookup=case(False,'1000');lookup.update({s['id']:s for s in sources})
    rows=evaluate(p,record_offers(sources),lookup,[],WEIGHTS)
    diagnose_prices(rows,sources)
    assert len(rows)==2
    assert all(not row['listed_price'] and not row['metrics'] for row in rows)
    assert all('zwischen Produktkarte und Detailseite' in row['reasons']['material_price'] for row in rows)


def test_composite_geometry_compares_equivalent_card_and_property_table():
    from purchasing import Criterion
    html='''<meta property="og:site_name" content="Testshop"><li data-testid="article-card"><a href="/p/screw/456/">Aluminiumplatte Schraube Senkkopf TX 4x40 mm 100 Stück</a>Preis — 3,10 € inkl. MwSt. pro Pack</li>'''
    card=sources_for(html)
    detail=sources_for(detail_html(title='Aluminiumplatte Schraube Senkkopf TX 4x40 mm 100 Stück'),'https://shop.example/p/a/123/')
    detail[0]['id']='Q3'
    p,lookup=case(False,'1000')
    need='Aluminiumplatte Schraube 4 × 40 mm nach Berlin.'
    lookup['Q1']['text']+=' '+need
    p.must=[Criterion(field='Abmessung',operator='eq',target='4 × 40',unit='mm',evidence=Evidence(source_id='Q1',quote=need))]
    sources=card+detail;lookup.update({s['id']:s for s in sources})
    from workflow import extract
    with patch('harness.Harness.ask',side_effect=AssertionError('structured records need no extraction model')):
        offers=extract(Mock(),' ',p,sources,[])
    rows=evaluate(p,offers,lookup,[],WEIGHTS)
    assert len(rows)==2
    assert all(row['partial_score']['basis']=={'gross_goods_price':80} for row in rows)
    assert {row['partial_score']['value'] for row in rows}=={56,6.71}


def test_storefront_lower_bound_survives_without_becoming_an_order_price():
    from shop_evidence import reconcile_web_offers

    url = "https://werkzeug.example/p/plate-family"
    name = "Aluminiumplatten im Zuschnitt"
    graph = {"@graph": [{"@type": "OnlineStore", "name": "Werkzeughaus", "url": "https://werkzeug.example"},
                        *[{"@type": "Product", "name": name, "url": url,
                           "offers": {"@type": "Offer", "price": value, "priceCurrency": "EUR"}}
                          for value in ("9.95", "10.25")]]}
    sources = sources_for(f"""
        <meta property="og:site_name" content="Aluminiumplatten, € 9,95">
        <script type="application/ld+json">{json.dumps(graph)}</script><h1>{name}</h1>
        <div id="product-offer"><div class="price_wrapper"><div class="price-row">
        <strong class="price"><span class="pricestarting">ab</span> € 10,25</strong></div>
        <span class="vat_info">inkl. 19% USt.</span></div></div>
        <select><option>100 Stück</option><option>500 Stück</option></select>
    """, url)
    parsed = record_offers(sources)
    assert len(parsed) == 1
    old = parsed[0].model_copy(update={"supplier": "Aluminiumplatten, € 9,95"})
    offers = reconcile_web_offers(parsed, [old], sources)
    position, lookup = case(False, "1000")
    lookup.update({source["id"]: source for source in sources})
    rows = evaluate(position, offers, lookup, [], WEIGHTS)
    diagnose_prices(rows, sources)
    assert len(rows) == 1 and rows[0]["supplier"] == "Werkzeughaus"
    assert any(fact["field"] == "price_from" and fact["value"] == "10,25" for fact in rows[0]["specs"])
    assert rows[0]["listed_price"] is None
    assert "Ab-Preis" in rows[0]["reasons"]["material_price"]


def test_visible_variant_buy_box_takes_precedence_and_supplies_pack_price():
    name = "Aluminiumplatte 100 Stück"
    url = "https://werkzeug.example/p/plates-100"
    graph = {"@type": "Product", "name": name, "url": url,
             "offers": {"@type": "Offer", "price": "9.95", "priceCurrency": "EUR"}}
    sources = sources_for(f"""
        <meta property="og:site_name" content="Werkzeughaus">
        <script type="application/ld+json">{json.dumps(graph)}</script><h1>{name}</h1>
        <div class="product-offer" itemprop="offers"><div class="price_wrapper">
        <div class="price">8,11 €</div><span class="vat_info">inkl. 19% USt.</span></div></div>
    """, url)
    position, lookup = case(False, "1000")
    lookup.update({source["id"]: source for source in sources})
    row = evaluate(position, record_offers(sources), lookup, [], WEIGHTS)[0]
    assert row["listed_price"]["order_quantity"] == 10
    assert row["metrics"]["gross_goods_price"]["value"] == 81.1


def test_same_shop_imprint_can_publish_a_different_legal_name():
    from supplier_locations import same_shop_imprint
    products = [{"url": "https://www.werkzeug.example/p/plates"},
                {"url": "https://market.example/search", "product_url": "https://werkzeug.example/p/plates"}]
    assert same_shop_imprint({"url": "https://werkzeug.example/impressum"}, products)
    assert not same_shop_imprint({"url": "https://other.example/impressum"}, products)
    assert not same_shop_imprint({"url": "https://market.example/impressum"}, products)


def test_norm_in_a_proven_product_title_excludes_a_different_standard():
    from purchasing import Criterion

    position, lookup = case(False, "1000")
    lookup["Q1"]["text"] = "Schrauben nach DIN 7981"
    position.must = [Criterion(field="Norm", operator="eq", target="DIN 7981", unit="",
                               evidence=Evidence(source_id="Q1", quote=lookup["Q1"]["text"]))]
    sources = sources_for("""
        <meta property="og:site_name" content="Werkzeughaus">
        <li data-testid="article-card"><a href="/p/a/1/">Blechschraube DIN 7981, 100 Stück</a>
        Preis — 8,10 € inkl. MwSt. pro Pack</li>
        <li data-testid="article-card"><a href="/p/b/2/">Blechschraube DIN 7983, 100 Stück</a>
        Preis — 4,10 € inkl. MwSt. pro Pack</li>
    """)
    lookup.update({source["id"]: source for source in sources})
    rows = evaluate(position, record_offers(sources), lookup, [], WEIGHTS)
    assert next(row for row in rows if "7983" in row["product"])["status"] == "abweichend"
    assert next(row for row in rows if "7981" in row["product"])["must"][0]["result"] is True
