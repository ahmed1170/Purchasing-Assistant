from run_metrics import timed, measured_run
"""Read screw article tables with explicit column and section boundaries."""
import re
import unicodedata
from collections import Counter, defaultdict

from purchasing import Evidence, Fact, LENGTH_UNITS, Offer, literal_in, nominal_axis, normalize, number, quantity_number

DIMENSION = re.compile(r"(?<![\d.,])(\d+(?:[.,]\d+)?)\s*[x×]\s*(\d+(?:[.,]\d+)?)(?![\d.,])", re.I)
DRIVE = re.compile(r"\b(?:TX|PZ|PH)(?:\s*\d{1,2})?\b", re.I)
HEAD = re.compile(r"\b(?:linsensenkkopf|senkkopf|tellerkopf|linsenkopf|pan-head|sechskantkopf)(?:schrauben?)?\b", re.I)
FINISH = re.compile(r"verzinkt blau passiviert|gleitbeschichtet|\bA[24]\b|\bVZ\b|verzinkt", re.I)
THREAD = re.compile(r"teilgewinde|vollgewinde", re.I)
ARTICLE = re.compile(r"(?=[A-Z0-9._-]*\d)[A-Z0-9][A-Z0-9._-]{2,34}", re.I)
SKU_LABEL = re.compile(r"^(?:art(?:ikel)?[ .-]*(?:nummer|nr\.?)|(?:article|product|item)\s*(?:no\.?|number)|sku)$", re.I)
DATA_COLUMNS = {
    "Norm": r"^norm\b|^standard\b",
    "Gewindegröße": r"^gewinde(?:\s*(?:nenn)?grösse)?$|^thread (?:size|diameter)$|^d1$",
    "Werkstoff": r"^(?:werkstoff|material)$",
    "Oberfläche": r"^(?:oberfläche|oberflächenbehandlung|beschichtung|finish|coating)$",
    "Farbe": r"^(?:farbe|color|colour)$",
    "pack_size": r"^(?:vpe|verpackungseinheit|packungsgrösse|kleinste vk-einheit|pack size|units per pack)$",
    "Bezeichnung": r"^(?:artikelbezeichnung|bezeichnung(?: 1)?|description|product name)$",
    "Hersteller": r"^(?:hersteller|manufacturer|marke|brand)$",
    "Dimension": r"^(?:dimension|abmessungen|masse|dimensions|variante)$",
    "Länge": r"^(?:länge|length)(?: \(mm\))?$",
    "Breite": r"^(?:breite|width)(?: \(mm\))?$",
    "Dicke": r"^(?:dicke|thickness)(?: \(mm\))?$",
    "Ausgangsdruck": r"^(?:ausgangsdruck|outlet pressure)$",
}


def product_word_key(word):
    plain = "".join(char for char in unicodedata.normalize("NFKD", normalize(word))
                    if not unicodedata.combining(char))
    return re.sub(r"ungen$", "ung", plain).rstrip("n").removesuffix("e")


def pdf_publisher(pages):
    """A printed company and contact block outweigh PDF author metadata."""
    from supplier_locations import GERMAN_IMPRINT_ADDRESS
    for page in pages:
        lines = page["text"].splitlines()
        for index, line in enumerate(lines):
            company = re.match(r"^([^\W\d_][\w& .-]{2,75}?\b(?:GmbH(?:\s*&\s*Co\.\s*KG)?|Ltd\.?|AG|e\.K\.))(?=\s|[|·,-]|$)", line)
            if not company:
                continue
            excerpt = " ".join(lines[index:index + 5])
            address = GERMAN_IMPRINT_ADDRESS.search(excerpt)
            if address:
                field, value = "company_address", address["address"]
            else:
                spaced = GERMAN_IMPRINT_ADDRESS.search(re.sub(r"\s+[·|-]\s+", " ", excerpt))
                exact_address = re.search(r"\s+(?:[·|-]\s+)?".join(map(re.escape, spaced["address"].split())), excerpt) if spaced else None
                postal = re.search(r"\b(?:D-)?\d{5}\s+(?:Bad |Sankt )?[A-ZÄÖÜ][\wÄÖÜäöüß-]+\b", excerpt)
                if not postal or not re.search(r"www\.|@|tel", excerpt, re.I):
                    continue
                field, value = ("company_address", exact_address[0]) if exact_address else ("company_city", postal[0])
            return company[1], Fact(field=field, value=value, unit="",
                                    evidence=Evidence(source_id=page["id"], quote="\n".join(lines[index:index + 5])))
    return "", None


def pdf_price_notes(pages):
    from practical_prices import GROSS, NET
    notes = []
    for source in pages:
        for line in source["text"].splitlines():
            text = normalize(line)
            if re.search(r"\b(?:alle preise|all prices)\b", text):
                tax = re.search(NET, text) or re.search(GROSS, text)
                if tax:
                    notes.append(Fact(field="tax_status", value=tax[0], unit="",
                                      evidence=Evidence(source_id=source["id"], quote=line)))
            dated = re.match(r"^(?:preisstand|stand|price as of)\s*:\s*(\d{1,2}\.\d{1,2}\.\d{4})\b", text)
            if dated:
                notes.append(Fact(field="price_date", value=dated[1], unit="",
                                  evidence=Evidence(source_id=source["id"], quote=line)))
    return notes


def pdf_row_price(fields, page, notes):
    """Keep the price on its exact row, with separately cited document terms."""
    from practical_prices import CURRENCIES
    fields = [(label, value, quote) for label, value, quote in fields if re.search(r"\b(?:preis|price)\b", normalize(label))]
    if len(fields) != 1:
        return []
    label, value, quote = fields[0]
    basis_pattern = r"(?:\b(?:pro|je|per)\s+|/\s*)(?:(\d+(?:[.,]\d+)?)\s*)?(stück|stk\.?|pcs|m²|mm|kg|m|l)\b"
    for currency, symbol in CURRENCIES.items():
        match = re.fullmatch(r"(\d+(?:[.,]\d+)?)\s*(?:" + symbol + r")\s*\*?\s*(?:" + basis_pattern + r")?", normalize(value))
        if match:
            amount = match[1]
            break
    else:
        return []
    result = [Fact(field="listed_price", value=amount, unit=currency,
                   evidence=Evidence(source_id=page["id"], quote=quote)), *notes]
    if basis := re.search(basis_pattern, normalize(label)):
        before = page["text"].split(quote, 1)[0]
        header = next((line for line in reversed(before.splitlines())
                       if normalize(label) in columns(line)), "")
        if header:
            result.append(Fact(field="price_basis_note", value=basis[0], unit="",
                               evidence=Evidence(source_id=page["id"], quote=header)))
    return result


def technical_pdf_candidates(position, sources, audit):
    """Read labelled records and exact table rows without requiring sales terms."""
    wanted = [criterion for criterion in position.must if normalize(criterion.field) not in
              {"produkttyp", "produktart", "materialgruppe"}]
    product_words = {
        product_word_key(word)
        for word in re.findall(r"[^\W\d_]{5,}", normalize(position.name))
        if not re.search(r"^(?:verzink|schwarz|weiß|natur|selbstkleb|einzeln|rostfrei|eloxiert)", word)
    }
    if not product_words:
        return [], {}
    documents = defaultdict(list)
    for source in sources:
        if source["kind"] == "pdf":
            documents[source["path"]].append(source)

    offers = []
    for pages in documents.values():
        pages.sort(key=lambda page: page["page"] or 0)
        first_lines = pages[0]["text"].splitlines()
        publisher, location = pdf_publisher(pages)
        footers = {match[1] for page in pages for line in page["text"].splitlines()
                   if (match := re.fullmatch(r"(?:\d+\s*\|?\s*)?([A-Z][A-Z0-9&-]{2,15})\s*\|\s*(?:Vers\.\s*\d+|\d{1,2}\.\d{1,2}\.\d{4})", line))}
        if not publisher and len(footers) == 1:
            publisher = next(iter(footers))
        price_notes = pdf_price_notes(pages)
        family = next((line for line in first_lines[:12] if not line.startswith("PDF-Metadaten")
                       and any(word in product_word_key(line.split(" | ", 1)[0]) for word in product_words)), "")
        heading_code = next(((line, match[1]) for line in first_lines[:12]
                             if (match := re.fullmatch(r"(?:Technical data|Technische Daten)\s*\|\s*([\w.-]+(?: [\w.-]+){0,2})", line, re.I))
                             and re.search(r"\d", match[1])
                             and any(literal_in(token, match[1]) for token in re.findall(r"\b\d{3,}\b", position.name))), None)
        family = family or (heading_code[0] if heading_code else "")
        if not family or re.search(r"(?mi)^\s*(?:leistungs|konformitäts)erklärung\s*$", pages[0]["text"]):
            continue
        family_word = next((word for word in re.findall(r"[^\W\d_]+", family)
                            if any(token in product_word_key(word) for token in product_words)), "")
        prefix = family.split(family_word, 1)[0].strip() if family_word else ""
        candidates = []
        for page in pages:
            lines = page["text"].splitlines()

            def fact(field, value, quote, source=page):
                if field == "Gewindegröße":
                    thread = re.fullmatch(r"(M\d+(?:[,.]\d+)?)\s*[x×]\s*\d+(?:[,.]\d+)?", value, re.I)
                    if thread:
                        value = thread[1]
                match = re.fullmatch(r"(\d+(?:[,.]\d+)?)\s*(mm|cm|m|bar)", value, re.I)
                measured = match and ((field == "Ausgangsdruck") == (normalize(match[2]) == "bar")) and field in {
                    "Länge", "Breite", "Dicke", "Dimension", "Ausgangsdruck"}
                return Fact(field=field, value=match[1] if measured else value, unit=match[2] if measured else "",
                            evidence=Evidence(source_id=source["id"], quote=quote))

            records = []
            if page is pages[0] and heading_code:
                records.append((heading_code[1], heading_code[0], [
                    (label, value.strip(), line) for line in lines
                    for label, sep, value in [line.partition("|")] if sep and "|" not in value]))
            explicit = [(i, value.strip()) for i, line in enumerate(lines)
                        for label, sep, value in [line.partition(":") if ":" in line else line.partition("|")]
                        if sep and SKU_LABEL.fullmatch(label.strip()) and ARTICLE.fullmatch(value.strip())]
            for i, sku in explicit:
                end = next((index for index, _ in explicit if index > i), len(lines))
                if len(explicit) == 2 and explicit[0][1] == explicit[1][1]:
                    end = len(lines)
                values = [(label, value.strip(), line) for line in lines[i + 1:end]
                          for label, sep, value in [line.partition(":") if ":" in line else line.partition("|")]
                          if sep and value.strip() and "|" not in value]
                blocks = [j for j in range(i + 1, len(lines)) if SKU_LABEL.fullmatch(lines[j])]
                if len(explicit) == 1 and blocks and sku in lines[blocks[0] + 1:]:
                    start = blocks[0]
                    split_at = lines.index(sku, start + 1)
                    fields = []
                    for label in lines[start:split_at]:
                        if fields and fields[-1].endswith("-") and label[:1].islower():
                            fields[-1] += label
                        else:
                            fields.append(label)
                    cells = lines[split_at:split_at + len(fields)]
                    if len(cells) == len(fields) and len(cells) >= 3 and all("|" not in cell for cell in cells):
                        quote = "\n".join(lines[start:split_at + len(fields)])
                        if len(quote) <= 700:
                            values.extend((label, cell, quote) for label, cell in zip(fields, cells))
                    elif "dimension" in map(normalize, fields):
                        # A missing value shifts later columns in vertical PDF extraction.
                        # Retain a single, explicit nominal thread code without shifting values.
                        threads = [cell for cell in cells if re.fullmatch(r"M\s*\d+(?:[,.]\d+)?", cell, re.I)]
                        quote = "\n".join(lines[start:split_at + len(cells)])
                        if len(threads) == 1 and len(quote) <= 700:
                            values.append(("Dimension", threads[0], quote))
                records.append((sku, lines[i], values))
            for index, line in enumerate(lines):
                headers = columns(line)
                sku_index = next((i for i, label in enumerate(headers) if SKU_LABEL.fullmatch(label)), None)
                if sku_index is None or len(headers) < 2:
                    continue
                last_row = index
                for row_index in range(index + 1, len(lines)):
                    if row_index - last_row > 4:
                        break
                    row = lines[row_index]
                    cells = [cell.strip() for cell in row.split("|")]
                    if any(SKU_LABEL.fullmatch(cell) for cell in cells):
                        break
                    if len(cells) != len(headers) or not ARTICLE.fullmatch(cells[sku_index]) or len(row) > 700:
                        continue
                    last_row = row_index
                    row_fields = [(label, cell, row) for label, cell in zip(headers, cells)]
                    if sku_index == 0 and re.fullmatch(r"preis|price", headers[-1]):
                        previous = lines[row_index - 1] if row_index > index + 1 else ""
                        following = lines[row_index + 1] if row_index + 1 < len(lines) else ""
                        row_fields[-1] = wrapped_price_cell(row_fields[-1], previous, following)
                    records.append((cells[sku_index], row, row_fields))
            for sku, identity, fields in records:
                facts = [fact(field, value, quote)
                         for field, pattern in DATA_COLUMNS.items() for label, value, quote in fields
                         if re.search(pattern, normalize(label)) and value]
                facts.append(fact("Artikelnummer", sku, identity))
                if len({item[1] for item in explicit}) == 1:
                    supplier_line = next((line for line in lines if re.fullmatch(r"(?:Anbieter|Verkäufer|Supplier):\s*\S.*", line, re.I)), "")
                    if supplier_line:
                        facts.append(fact("Anbieterbeleg", supplier_line.split(":", 1)[1].strip(), supplier_line))
                    from practical_prices import pdf_tier_schedule
                    start = lines.index(identity)
                    parsed_schedule = pdf_tier_schedule("\n".join(lines[start:]))
                    if parsed_schedule:
                        quote = "\n".join(lines[start:start + parsed_schedule[4] + 1])
                        if len(quote) <= 700:
                            facts.append(fact("pdf_price_schedule", quote, quote))
                    thread = re.search(r"\bM\d+(?:[,.]\d+)?\b", family, re.I)
                    if thread and not any(item.field in {"Gewindegröße", "Dimension"} for item in facts):
                        facts.append(fact("Gewindegröße", thread[0], family, pages[0]))
                connection_table = any(re.search(r"\brohr\b|anschluss|connection", normalize(label))
                                       for label, _, _ in fields)
                for label, value, quote in fields:
                    nominal = re.findall(r"(?<![\d.,])(\d+(?:[.,]\d+)?)\s*(mm|cm)\b", value, re.I)
                    if connection_table and normalize(label) == "variante" and len(nominal) == 1:
                        length, unit = nominal[0]
                        facts.append(Fact(field="Anschlussmaß", value=length, unit=unit,
                                          evidence=Evidence(source_id=page["id"], quote=quote)))
                    if normalize(label) == "variante":
                        thread = re.match(r'(\d+(?:/\d+)?)\s*["″]\s*(Innengewinde|Aussengewinde|Außengewinde)\b',
                                          value, re.I)
                        if thread and len(re.findall(r'["″]', value)) == 1:
                            facts.extend([fact("Gewindeart", thread[2], quote),
                                          Fact(field="Gewindegröße", value=thread[1], unit="Zoll",
                                               evidence=Evidence(source_id=page["id"], quote=quote))])
                if not any(item.field == "Gewindegröße" for item in facts):
                    thread = next((item for item in facts if item.field == "Dimension"
                                   and re.fullmatch(r"M\s*\d+(?:[,.]\d+)?", item.value, re.I)), None)
                    if thread:
                        facts.append(thread.model_copy(update={"field": "Gewindegröße"}))
                # An explicitly labelled family statement on the first page applies across its rows.
                for line in first_lines[:12]:
                    label, separator, value = line.partition("|")
                    if separator and value.strip() and "|" not in value:
                        facts.extend(fact(field, value.strip(), line, pages[0]) for field in ("Werkstoff", "Oberfläche", "Norm")
                                     if re.search(DATA_COLUMNS[field], normalize(label)) and not any(f.field == field for f in facts))
                    if not any(f.field == "Oberfläche" for f in facts):
                        coating = re.match(r"^\s*(?:[■•]\s*)?(?:Stahl\s+)?(?:galvanisch|elektrolytisch|feuer)?\s*(verzinkt(?:-[\w]+)?)(?=[.|\s]|$)", line, re.I)
                        if coating:
                            facts.append(fact("Oberfläche", coating[1], line, pages[0]))
                if family_word:
                    facts.append(fact("Produkttyp", family_word, family, pages[0]))
                if not any(f.field == "Norm" for f in facts):
                    standard = re.search(r"\b(?:DIN|ISO|EN|ASTM)\s*\d+(?:-\d+)*\b", family, re.I)
                    if standard:
                        facts.append(fact("Norm", standard[0], family, pages[0]))
                facts.extend(pdf_row_price(fields, page, price_notes))
                supplier = publisher or next((f.value for f in facts if f.field in {"Anbieterbeleg", "Hersteller"}), "")
                if location:
                    facts.append(location)
                    location_page = next(source for source in pages if source["id"] == location.evidence.source_id)
                    audit[(location_page["path"], location_page["title"], location_page["page"])] = True
                if not supplier and re.fullmatch(r"[\w&-]{2,40}", prefix) and normalize(prefix) not in {
                        "verzinkte", "technische", "die", "für", "galvanisch", "unsere"}:
                    supplier = prefix
                if not supplier:
                    supplier = next((line.split(": ", 1)[1] for line in first_lines[:4]
                                     if line.startswith("PDF-Metadaten · Autor: ")
                                     and re.search(r"GmbH|Ltd|AG\b|Inc\b", line)), pages[0]["title"])
                match_text = re.sub(r"(?<=\d)(?=mm\b)", " ", " ".join([family, *(f.value for f in facts)]), flags=re.I)
                rank = sum(literal_in(item.target, match_text) for item in wanted)
                rank += 10 * (literal_in(sku, position.name) or any(normalize(item.target) == normalize(sku) for item in wanted))
                variant = next((f.value for f in facts if f.field == "Dimension"), "")
                if variant:
                    requested = [re.findall(r"\d+(?:[.,]\d+)?", item.target) for item in wanted]
                    actual = re.findall(r"\d+(?:[.,]\d+)?", variant)
                    rank += 2 * sum(bool(values) and values == actual for values in requested)
                candidates.append((rank, page, Offer(supplier=supplier, product=sku,
                                        identity=Evidence(source_id=page["id"], quote=identity), facts=facts)))
        if candidates:
            top = max(rank for rank, _, _ in candidates)
            unique = set()
            for rank, page, offer in candidates:
                if rank != top or offer.product in unique or len(unique) >= 4:
                    continue
                unique.add(offer.product)
                offers.append(offer)
                audit[(page["path"], page["title"], page["page"])] = True
                audit[(pages[0]["path"], pages[0]["title"], pages[0]["page"])] = True
    return offers, {(offer.supplier, offer.product): None for offer in offers}


def wrapped_price_cell(field, previous, following):
    label, cell, row = field
    numeric = r"\d+(?:[.,]\d+)?"
    currency = r"(?:€|EUR|CHF|GBP|USD)\s*\*?"
    for neighbor, amount, sign, lines in [
        (following, cell, following.rsplit("|", 1)[-1].strip(), (row, following)),
        (previous, previous.rsplit("|", 1)[-1].strip(), cell, (previous, row)),
    ]:
        if ("|" in neighbor and not ARTICLE.fullmatch(neighbor.split("|", 1)[0].strip())
                and re.fullmatch(numeric, amount) and re.fullmatch(currency, sign, re.I)
                and len(row) + len(neighbor) + 1 <= 700):
            return label, amount + " " + sign, "\n".join(lines)
    return field


def dimensions(text):
    match = DIMENSION.search(text)
    return tuple(number(value) for value in match.groups()) if match else None


def columns(line):
    return [normalize(cell) for cell in line.split("|")]


def declaration_findings(sources):
    findings = []
    patterns = (
        ("Produktfamilie der Leistungserklärung", r"^für\s+(.+?)\s*(?:\||$)"),
        ("Dokumentkennung der Leistungserklärung", r"^(DoP\s+[A-Z0-9-]+)\s*$"),
        ("Europäische Technische Bewertung", r"^Europäische Technische Bewertung\s*[:| ]+\s*(ETA-[\d/]+)(?:;|$)"),
    )
    for source in sources:
        if source["kind"] != "pdf" or not re.search(r"^LEISTUNGSERKLÄRUNG$", source["text"], re.I | re.M):
            continue
        for field, pattern in patterns:
            match = re.search(pattern, source["text"], re.I | re.M)
            if match:
                findings.append({"field": field, "value": match[1].strip(), "variant": "",
                                 "evidence": {"source_id": source["id"], "quote": match[0].strip()}})
    return findings


def table_rows(source):
    lines = source["text"].splitlines()
    for i, line in enumerate(lines):
        cols = columns(line)
        numbered = cols[0] in {"artikelnr", "artikelnummer"}
        if not numbered or len(cols) < 2:
            continue
        header = lines[max(0, i - 8):i]
        end = next((j for j in range(i + 1, len(lines)) if columns(lines[j])[0] in {"artikelnr", "artikelnummer"}), len(lines))
        for j in range(i + 1, end):
            cells = [cell.strip() for cell in lines[j].split("|")]
            if len(cells) < 2 or not ARTICLE.fullmatch(cells[0]) or not DIMENSION.search(cells[1]):
                continue
            # A wrapped drive immediately beneath a row belongs to that row.
            continuation = lines[j + 1] if j + 1 < end else ""
            wrap = continuation if "|" not in continuation and re.fullmatch(r"(?:(?:Fräsrippen,\s*)?(?:TX|PZ|PH)\s*\d{1,2})", continuation, re.I) else ""
            yield cells, lines[j] + ("\n" + wrap if wrap else ""), header, line, wrap


def screw_dimensions_match(size, criteria):
    for criterion in criteria:
        axis = nominal_axis(criterion.field)
        unit = LENGTH_UNITS.get(normalize(criterion.unit))
        target = number(criterion.target)
        if axis is None or unit is None or target is None:
            continue
        actual, expected = size[axis], target * unit
        if {"eq": actual != expected, "gte": actual < expected, "lte": actual > expected}.get(criterion.operator):
            return False
    return True


def catalog_measure_options(position, field, sources, audit):
    axis = {"Durchmesser": 0, "Länge": 1}.get(field)
    if axis is None or "schraub" not in normalize(position.name):
        return []
    sizes = Counter()
    documents = defaultdict(set)
    for source in sources:
        if source["kind"] != "pdf":
            continue
        for cells, *_ in table_rows(source):
            size = dimensions(cells[1])
            if not size or None in size or "schraub" not in normalize(cells[1]):
                continue
            if screw_dimensions_match(size, position.must):
                value = size[axis]
                sizes[value] += 1
                documents[value].add(source["path"])
                audit[(source["path"], source["title"], source["page"])] = True
    options = sorted(sizes, key=lambda value: (-len(documents[value]), -sizes[value], value))[:3]
    return [f"{value.normalize():f}".replace(".", ",") + " mm" for value in options]


def cable_catalog_candidates(position, sources, audit):
    request = " ".join([position.name, *(item.target for item in position.must)])
    requested = dimensions(request)
    if not requested or None in requested or not re.search("kabelbinder", request, re.I):
        return [], {}
    requested = tuple(sorted(requested))
    documents = defaultdict(list)
    for page in sources:
        if page["kind"] == "pdf":
            documents[page["path"]].append(page)
    offers, prices = [], {}
    for pages in documents.values():
        website = next((match[1] for page in pages
                        if (match := re.search(r"(?<![@\w-])(?:www\.)?([a-z][a-z0-9-]+\.(?:de|at|ch|com))\b",
                                               page["text"], re.I))), None)
        for page in pages:
            text = page["text"]
            if "kabelbinder" not in normalize(text):
                continue
            def fact(field, value, quote, unit=""):
                return Fact(field=field,value=value,unit=unit,evidence=Evidence(source_id=page["id"],quote=quote))

            def add(supplier, sku, quote, facts, price=None):
                offers.append(Offer(supplier=supplier,product=sku,identity=Evidence(source_id=page["id"],quote=quote),facts=facts))
                prices[(supplier,sku)] = price
                audit[(page["path"],page["title"],page["page"])] = True

            manufacturer = re.search(
                r"(?m)^Hersteller\s*\n(?:[^\n]+\n){1,18}([A-Z][A-Z0-9-]{1,20})\n"
                r"(\d+(?:[.,]\d+)?[x×]\d+(?:[.,]\d+)?mm)\n(schwarz|weiß|weiss|natur)\n[^\n]+\n(\d+)\n(Stück)\b",
                text)
            article = re.search(r"(?mi)^Artikelnummer:\s*([A-Z0-9-]+)$", text)
            if manufacturer and article:
                supplier, size, color, pack, unit = manufacturer.groups()
                if tuple(sorted(dimensions(size))) == requested:
                    width, length = DIMENSION.search(size).groups()
                    measurements = re.search(r"(?m)^" + re.escape(length) + r"\s*mm\n" +
                                             re.escape(width) + r"\s*mm$",text)
                    facts = [fact("Maße",size,manufacturer[0]),fact("Farbe",color,manufacturer[0]),
                             fact("pack_size",pack,manufacturer[0],unit)]
                    if measurements:
                        facts.extend([fact("Länge",length,measurements[0]),fact("Breite",width,measurements[0])])
                    add(supplier,article[1],article[0],facts)
            lines = text.splitlines()
            for index, header in enumerate(lines):
                fields = columns(header)
                axes = {label:next((i for i,cell in enumerate(fields) if cell.startswith(label)), None)
                        for label in ("länge","breite")}
                if None in axes.values():
                    continue
                color_column = next((i for i,cell in enumerate(fields) if cell.startswith("schwarz")),None)
                article_column = next((i for i,cell in enumerate(fields) if re.match(r"artikel(?:nr|nummer)",cell)),None)
                color_title = next((line for line in lines[:index] if re.search(r"kabelbinder.{0,10}schwarz",line,re.I)), "")
                sku_column = color_column if color_column is not None else article_column
                if sku_column is None or color_column is None and not color_title:
                    continue
                supplier = (website.split(".")[0].upper() if website and color_column is not None
                            else website or page["title"])
                packing = re.search(r"(?mi)^Verpackungseinheit:\s*\|?\s*(\d+)\s+Stück", text)
                pack_column = fields.index("vpe") if "vpe" in fields else None
                price_column = next((i for i,cell in enumerate(fields) if cell == "eur/"),None)
                units = lines[index+1] if index+1 < len(lines) else ""
                basis = re.search(r"(\d+)\s*Stk\.",units.rsplit("|",1)[-1],re.I)
                for line in lines[index+1:]:
                    cells = [cell.strip() for cell in line.split("|")]
                    if len(cells) != len(fields):
                        if len(cells) == 1: break
                        continue
                    length,width = (cells[axes[field]] for field in ("länge","breite"))
                    size = (number(length),number(width))
                    if None in size or tuple(sorted(size)) != requested or not ARTICLE.fullmatch(cells[sku_column]):
                        continue
                    evidence = [
                        fact("Länge",length,line),fact("Breite",width,line),
                        fact("Farbe",header.split("|")[color_column].strip().split()[0],header) if color_column is not None
                        else fact("Farbe",re.search("schwarz",color_title,re.I)[0],color_title),
                    ]
                    pack = cells[pack_column] if pack_column is not None else packing[1] if packing else ""
                    if pack:
                        evidence.append(fact("pack_size",pack,line if pack_column is not None else packing[0],
                                             "Stück" if packing and pack_column is None else ""))
                    price = None
                    if price_column is not None and basis and quantity_number(pack) and number(cells[price_column]) is not None:
                        footer = next((line for line in lines if re.search(
                            r"preise.{0,80}(?:exkl\.?|zzgl\.?)\s*mwst",line,re.I)), "")
                        dated = re.search(r"\b(?:0[1-9]|1[0-2])/20\d{2}\b",footer)
                        price = {"value":cells[price_column],"currency":"EUR","tax":"netto" if footer else "offen","basis":int(basis[1]),
                                 "pack":int(quantity_number(pack)),"date":dated[0] if dated else "",
                                 "evidence":Evidence(source_id=page["id"],quote=line).model_dump(),
                                 "header":Evidence(source_id=page["id"],quote=header+"\n"+units).model_dump(),
                                 "date_evidence":Evidence(source_id=page["id"],quote=footer).model_dump() if dated else None}
                    add(supplier,cells[sku_column],line,evidence,price)
    return offers, prices


@timed("pdf_catalog")
def catalog_candidates(position, sources, audit):
    cable_offers, cable_prices = cable_catalog_candidates(position, sources, audit)
    if cable_offers:
        return cable_offers, cable_prices
    demand = " ".join([position.name, *(item.target for item in position.must)])
    requested = dimensions(demand) or next((match for item in position.must
                                             if (match := dimensions(item.evidence.quote))), None)
    axes = [item for item in position.must if nominal_axis(item.field) is not None
            and normalize(item.unit) in LENGTH_UNITS and number(item.target) is not None]
    if (not requested and not axes) or not re.search(r"schraub", demand, re.I):
        return [], {}
    documents = defaultdict(list)
    for source in sources:
        if source["kind"] == "pdf":
            documents[source["path"]].append(source)
    offers, details = [], {}
    for pages in documents.values():
        author = next(((m[1].strip(), page["id"], m[0]) for page in pages
                       if (m := re.search(r"^PDF-Metadaten · Autor: (.+)$", page["text"], re.M))), None)
        site = next(((m[1].capitalize(), page["id"], m[0]) for page in pages
                     if (m := re.search(r"\bwww\.([a-z][a-z0-9-]+)\.de\b", page["text"], re.I))), None)
        publisher = author or site
        supplier = publisher[0] if publisher else pages[0]["title"]
        for source in pages:
            for cells, row, section, header, wrap in table_rows(source):
                sku, description = cells[:2]
                size = dimensions(description)
                if (not size or None in size or requested and size != requested or not screw_dimensions_match(size, axes)
                        or not re.search(r"schraub", description, re.I)):
                    continue
                audit[(source["path"], source["title"], source["page"])] = True
                def ev(quote):
                    return Evidence(source_id=source["id"], quote=quote)
                facts = [Fact(field="Artikelnummer", value=sku, unit="", evidence=ev(row)),
                         Fact(field="Bezeichnung", value=description, unit="", evidence=ev(row)),
                         Fact(field="Maße", value=DIMENSION.search(description)[0], unit="", evidence=ev(row))]
                if publisher:
                    facts.append(Fact(field="Anbieterbeleg", value=supplier, unit="",
                                      evidence=Evidence(source_id=publisher[1], quote=publisher[2])))
                for field, pattern in (("Kopfform", HEAD), ("Antrieb", DRIVE), ("Werkstoff / Oberfläche", FINISH), ("Gewindeart", THREAD)):
                    # Only an explicit section heading, never a neighbouring article row.
                    quotes = [row, *(line for line in section if not ARTICLE.fullmatch(line.split("|")[0].strip())
                                     and not re.search(r"\d\s*[x×]\s*\d", line, re.I))]
                    matches = [(match[0], quote) for quote in quotes for match in pattern.finditer(quote)]
                    if matches:
                        for n, (value, quote) in enumerate(dict.fromkeys(matches[:3])):
                            facts.append(Fact(field=field if n == 0 else f"{field} ({n+1})",
                                              value=value, unit="", evidence=ev(quote)))
                family_source = next((text for text in [row, *section] if re.search(r"Spanplattenschrauben?", text, re.I)), "")
                family = re.search(r"Spanplattenschrauben?", family_source, re.I)
                if "holzbauschraube" in normalize(description):
                    family_source = row
                    family = re.search(r"Holzbauschraube", row, re.I)
                if family:
                    facts.append(Fact(field="Produktart", value=family[0], unit="", evidence=ev(family_source)))
                price = None
                labels = columns(header)
                if len(cells) == len(labels) and all(label in labels for label in ("verp.-einh.", "pr.einh.", "vk netto €")):
                    raw_pack, raw_basis, amount = (cells[labels.index(label)] for label in ("verp.-einh.", "pr.einh.", "vk netto €"))
                    pack, basis = map(quantity_number, (raw_pack, raw_basis))
                    raw_amount = amount.removesuffix("€").strip()
                    value = number(raw_amount)
                    date_entry = next(((m[1], s) for s in section if (m := re.search(r"Datum:\s*\|?\s*(\d{1,2}\.\d{1,2}\.\d{4})", s, re.I))), None)
                    if pack and basis and value is not None and amount.endswith("€") and pack % 1 == basis % 1 == 0:
                        facts.append(Fact(field="Packungsgröße", value=raw_pack, unit="", evidence=ev(row)))
                        qty = quantity_number(position.quantity)
                        count_unit = normalize(position.quantity_unit) in {"stück", "stk"} or bool(
                            re.fullmatch(r"(?:[\w-]+)?schrauben?", normalize(position.quantity_unit)))
                        subtotal = value * qty / basis if qty and qty > 0 and qty % 1 == 0 and count_unit else None
                        price = {"value": raw_amount, "currency": "EUR", "tax": "netto", "basis": int(basis), "pack": int(pack),
                                 "date": date_entry[0] if date_entry else "", "evidence": ev(row).model_dump(),
                                 "header": ev(header).model_dump(), "date_evidence": ev(date_entry[1]).model_dump() if date_entry else None,
                                 "calculation": f"{int(qty)} ÷ {int(basis)} × {raw_amount} EUR = {subtotal:.2f} EUR".replace(".", ",") if subtotal is not None else "",
                                 "package_note": "Bestellmenge ist kein Vielfaches der Verpackungseinheit." if qty and qty % pack else ""}
                        footer = next((line for line in source["text"].splitlines()
                                       if re.fullmatch(r"Alle Preise zzgl\. MwSt\.", line, re.I)), None)
                        if footer:
                            price["tax_evidence"] = ev(footer).model_dump()
                offer = Offer(supplier=supplier, product=sku, identity=ev(row), facts=facts)
                offers.append(offer)
                details[(supplier, sku)] = price
    return offers, details


def catalog_check(criterion, facts):
    """Resolve documented column values to the requested technical property."""
    name = normalize(criterion.field)
    if name == "farbe" and (color := facts.get("Farbe")) and criterion.operator in {"eq","contains"}:
        target = normalize(criterion.target)
        expected = re.sub(r"^(schwarz|weiß|weiss)(?:e[snmr]?)$",r"\1",target)
        return normalize(color.value) == expected, color
    if re.search(r"durchmesser|länge|breite|maß|abmessung", name):
        fact = facts.get("Maße")
        actual = dimensions(fact.value) if fact else None
        length, width = facts.get("Länge"), facts.get("Breite")
        if length and width:
            size = number(length.value), number(width.value)
            target = dimensions(criterion.target)
            if target and None not in size and None not in target:
                return sorted(size) == sorted(target), length
            single = width if "breite" in name else length if "länge" in name else None
            unit = LENGTH_UNITS.get(normalize(criterion.unit))
            expected = number(criterion.target)
            if single and criterion.operator == "eq" and unit and expected is not None:
                return number(single.value) == expected * unit, single
        if not actual:
            return None, fact
        if "durchmesser" in name or "länge" in name and "maß" not in name:
            target = number(criterion.target)
            unit = LENGTH_UNITS.get(normalize(criterion.unit))
            if target is None or unit is None:
                return None, fact
            target *= unit
            value = actual[0 if "durchmesser" in name else 1]
            test = {"eq": value == target, "gte": value >= target, "lte": value <= target}
            return test.get(criterion.operator), fact
        target = dimensions(criterion.target)
        return (actual == target if target and criterion.operator in {"eq", "contains"} else None), fact
    field = next((field for pattern, field in ((r"kopf", "Kopfform"), (r"antrieb", "Antrieb"),
                 (r"schrauben(?:art|typ)|produktart|typ", "Produktart"), (r"^gewinde(?:art)?$", "Gewindeart"),
                 (r"werkstoff|oberfläche|material", "Werkstoff / Oberfläche")) if re.search(pattern, name)), None)
    fact = facts.get(field)
    if not fact or criterion.operator not in {"eq", "contains"} or criterion.unit:
        return None, fact
    actual, target = normalize(fact.value), normalize(criterion.target)
    if field == "Antrieb":
        actual, target = (re.sub(r"(?:[\s-]+antrieb)$", "", value) for value in (actual, target))
    if field == "Antrieb" and target in {"tx", "pz", "ph"}:
        return bool(re.fullmatch(target + r"(?:\s*\d{1,2})?", actual)), fact
    if field == "Kopfform":
        actual, target = (re.sub(r"schrauben?$", "", value) for value in (actual, target))
    if field == "Produktart":
        actual, target = (re.sub(r"schrauben\b", "schraube", text) for text in (actual, target))
    if field == "Werkstoff / Oberfläche":
        # A2 and a finish are different properties, so an absent attribute is unknown.
        values = [normalize(item.value) for key, item in facts.items() if key.startswith(field)]
        match = any(target in item if criterion.operator == "contains" else target == item for item in values)
        return True if match else None, fact
    return (target in actual if criterion.operator == "contains" else actual == target), fact
