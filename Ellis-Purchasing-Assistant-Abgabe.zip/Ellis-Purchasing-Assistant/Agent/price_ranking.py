"""Weighted scores for comparable material prices and distances."""

from purchasing import METRICS

PRICE_KEYS = ("net_price", "gross_goods_price", "unit_net_price", "unit_gross_price")
DISTANCE_SCALE_KM = 2000
DISTANCE_CEILING = 0.85
PRICE_PREMIUM_SCALE = 0.5
PRICE_COMPARISON_CEILING = 0.90
PRICE_SINGLE_SUPPLIER_CEILING = 0.70


def comparable_groups(rows, keys):
    groups = {}
    for row in rows:
        for key in keys:
            metric = row["metrics"].get(key)
            if metric:
                groups.setdefault((key, metric.get("basis", key)), []).append(row)
    return groups


def price_priority(group):
    (key, basis), rows = group
    suppliers = {row["supplier"].casefold() for row in rows}
    return (len(suppliers) > 1, "historisch" not in basis, len(rows) > 1,
            key in PRICE_KEYS[:2], len(suppliers), len(rows), -PRICE_KEYS.index(key))


def distance_priority(group):
    (_, basis), rows = group
    air = "air" in basis.split("|") or "luftlinie" in basis.casefold()
    return (not air, len({row["supplier"].casefold() for row in rows}), len(rows))


def earned(row):
    return row["score"] if row["score"] is not None else (row["partial_score"] or {}).get("value", 0)


def rank_prices(rows, weights):
    viable = [row for row in rows if row["status"] != "abweichend"]
    for row in viable:
        row["scoring_method"] = "weighted_curves"
        row["criterion_points"] = {}
        row["comparison_basis"] = {}
    criteria = (("price", PRICE_KEYS, weights.get("total_price", 0), price_priority),
                ("distance", ("distance_km",), weights.get("distance_km", 0), distance_priority))
    for criterion, keys, weight, priority in criteria:
        if not weight:
            continue
        groups = comparable_groups(viable, keys)
        if not groups:
            continue
        (key, basis), participants = max(groups.items(), key=priority)
        reference = min(row["metrics"][key]["value"] for row in participants) if criterion == "price" else 0
        supplier_count = len({row["supplier"].casefold() for row in participants})
        ceiling = (DISTANCE_CEILING if criterion == "distance"
                   else PRICE_COMPARISON_CEILING if supplier_count > 1 else PRICE_SINGLE_SUPPLIER_CEILING)
        for row in participants:
            metric = row["metrics"][key]
            value = metric["value"]
            if criterion == "distance":
                fraction = 1 / (1 + value / DISTANCE_SCALE_KM)
                unit, scale = "km", DISTANCE_SCALE_KM
            else:
                premium = (value - reference) / reference
                fraction = 1 / (1 + (premium / PRICE_PREMIUM_SCALE) ** 2)
                unit = (metric.get("fact") or {}).get("unit", "EUR")
                scale = PRICE_PREMIUM_SCALE
            row["criterion_points"][criterion] = {
                "points": round(weight * ceiling * fraction, 2), "max": weight, "basis": basis,
                "count": len(participants), "supplier_count": supplier_count, "ceiling": ceiling,
                "reference": reference, "unit": unit,
                "method": criterion, "scale": scale,
            }
            row["comparison_basis"][key] = weight

    for row in rows:
        row["missing"] = [check["field"] for check in row["must"] if check["result"] is None]
        if not any(key in row["metrics"] for key in ("total_price","gross_total_price")):
            row["reasons"]["shipping_cost"] = "Versandkosten offen. Waren- und Einheitspreise verstehen sich vor Versand."
        row["reasons"].pop("delivery_days", None)
        if row["status"] == "abweichend":
            conflicts = [f'{check["field"]}: {check["fact"]["value"]} statt {check["target"]}'
                         for check in row["must"] if check["result"] is False and check["fact"]]
            row["reasons"]["alternative"] = "Abweichende Alternative · " + " · ".join(conflicts) + "."
            continue
        points = row["criterion_points"]
        for criterion, keys, weight, _ in criteria:
            if weight and criterion not in points:
                label = "Preis" if criterion == "price" else "Entfernung"
                row["missing"].append(label)
                if any(key in row["metrics"] for key in keys):
                    text = ("Preis hat eine andere Vergleichsgrundlage (Variante, Menge, Währung, Steuerstatus oder Preisstand)."
                            if criterion == "price" else "Entfernung wurde auf anderer Grundlage ermittelt.")
                    row["reasons"][criterion + "_score"] = text
        basis = row["comparison_basis"]
        if not basis:
            row.pop("comparison_basis")
            continue
        components = {key: points["distance" if key == "distance_km" else "price"]["points"] for key in basis}
        coverage = sum(basis.values())
        value = round(sum(components.values()), 2)
        if coverage == 100:
            row["score"], row["components"] = value, components
            if not row["missing"]:
                row["status"] = "geeignet"
        else:
            row["partial_score"] = {"value": value, "basis": basis, "components": components}

    rows.sort(key=lambda row: (row["status"] == "abweichend", -earned(row),
                               -sum(row.get("comparison_basis", {}).values()),
                               row["supplier"].casefold(), row["product"].casefold()))
    return rows


def recommend(rows, questions):
    viable = [row for row in rows if row["status"] != "abweichend"]
    if not viable:
        return "Abweichende Alternativen gefunden. " + " ".join(row["reasons"]["alternative"] for row in rows[:3])
    best = viable[0]
    basis = best.get("comparison_basis", {})
    if not basis:
        return "Vorauswahl: " + best["supplier"] + ". Für eine Empfehlung fehlt ein bewertbarer Preis oder eine bewertbare Entfernung."
    value = earned(best)
    coverage = sum(basis.values())
    tied = [row for row in viable if earned(row) == value and row.get("comparison_basis")]
    price = best.get("criterion_points", {}).get("price")
    single_supplier = price and price.get("supplier_count") == 1
    title = ("Empfehlung" if coverage == 100 and not best["missing"] and not questions and not single_supplier
             and (basis == {"distance_km":100} or any(key in basis for key in PRICE_KEYS[:2]))
             and all(sum(row.get("comparison_basis", {}).values()) == 100 for row in viable) else "Vorläufige Empfehlung")
    parts = best["components"] if best["score"] is not None else best["partial_score"]["components"]
    split = " + ".join(f"{points:.2f}/{basis[key]} {METRICS[key]}" for key,points in parts.items())
    result = (f"{title}: {best['supplier']} ({best['product']}). "
              f"{value:.2f} von {coverage} bewertbaren Punkten ({split}). ")
    if len(tied) > 1:
        names = ", ".join(dict.fromkeys(row["supplier"] for row in tied))
        result += f"Punktgleichstand bei {names}. Bei gleichem Ergebnis steht das Angebot mit höherer Datenabdeckung zuerst. "
    if single_supplier:
        result += "Für den Preis liegt nur ein vergleichbarer Lieferant vor. "
    if best["missing"]:
        result += "Offene Prüfung direkt für diesen Kandidaten: " + ", ".join(best["missing"]) + ". "
    if questions and best.get("selection_basis"):
        result += "Zugrunde gelegte Ausführung: " + best["selection_basis"] + ". "
    if (best.get("listed_price") or {}).get("historical"):
        result += "Historischer Listenstand: " + best["listed_price"]["date"] + ". "
    if any(key in basis for key in PRICE_KEYS):
        result += "Materialpreisvergleich ohne Versand. "
    if questions:
        result += "Nächster Prüfschritt: " + questions[0]
    return result.strip()

