import json
from pathlib import Path
from threading import Event
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest
from fastapi.testclient import TestClient

from harness import Harness, ModelError, codex_executable, codex_status
from live_test import example_pdf
from purchasing import Criterion, Evidence, Fact, Offer, Offers, OrderPosition, Position, Scope, evaluate, grounded, number, recommendation
from research import pdf_pages, public_target, web_batch
from server import create_app, database

WEIGHTS = {"total_price": 40, "quality": 30, "delivery_days": 20, "distance_km": 10}
NEED = "100 Stück nach Berlin. Muss: Werkstoff A2. Soll: Karton."
SCOPE = Evidence(source_id="Q1", quote="100 Stück nach Berlin.")


def evidence(source_id, quote):
    return Evidence(source_id=source_id, quote=quote)


def test_pdf_imprint_follows_official_homepage_link_before_search():
    from supplier_locations import pdf_imprint_locations
    from workflow import add_sources
    root = "https://www.musterkabel.de/"
    imprint = root + "unternehmen/impressum.html"
    pdf = dict(id="P1", kind="pdf", path="katalog.pdf", title="katalog.pdf",
               text="Musterkabel KB123 www.musterkabel.de")
    candidates = [Offer(supplier="Musterkabel", product="KB123", identity=evidence("P1", pdf["text"]), facts=[])]
    pages = [pdf]

    def fetch_page(url):
        if url == root:
            return [dict(kind="web", url=root, title="Homepage", text=f"Kontaktquelle: {imprint}")], []
        assert url == imprint
        return [dict(kind="web", url=imprint, title="Impressum",
                     text="Musterkabel GmbH Musterstraße 7 12345 Bad Musterstadt Deutschland")], []

    with patch("supplier_locations.fetch", side_effect=fetch_page), patch("supplier_locations.search_one") as search:
        pdf_imprint_locations(candidates, pages, add_sources, [])
    search.assert_not_called()
    assert [(fact.field, fact.value) for fact in candidates[0].facts] == [
        ("company_address", "Musterstraße 7 12345 Bad Musterstadt"), ("company_country", "Deutschland")]


def test_pdf_product_annotation_identifies_shop_with_different_legal_name():
    from io import BytesIO
    from pypdf import PdfReader, PdfWriter
    from pypdf.annotations import Link
    from supplier_locations import imprint_facts, pdf_imprint_locations
    from workflow import add_sources

    root = "https://www.werk-shop.de/"
    imprint = root + "Impressum"
    writer = PdfWriter(clone_from=PdfReader(BytesIO(example_pdf())))
    writer.add_annotation(0, Link(rect=(10, 10, 50, 22), url=root + "artikel-22"))
    output = BytesIO()
    writer.write(output)
    text = pdf_pages(output.getvalue())[0][0][1]
    assert f"PDF-Link: {root}artikel-22" in text
    pdf = dict(id="Q1", kind="pdf", path="angebot.pdf", title="Angebot", text=text)
    offer = Offer(supplier="Werk-Shop", product="22", identity=evidence("Q1", text.splitlines()[0]), facts=[])
    imprint_page = dict(kind="web", url=imprint, title="Impressum",
                        text="Betreiber und verantwortlich für die Inhalte dieses Shops ist: Beispiel Handel GbR Lindenstraße 5 12345 Bad Musterstadt")
    assert not imprint_facts("Werk-Shop", imprint_page | {"id":"Q2"})
    home = dict(kind="web", url=root, title="Startseite", text=f"Kontaktquelle: {imprint}")
    with (
        patch("supplier_locations.fetch", side_effect=[([home], []), ([imprint_page], [])]),
        patch("supplier_locations.search_one") as search,
    ):
        pdf_imprint_locations([offer], [pdf], add_sources, [])
    search.assert_not_called()
    assert offer.facts[0].value == "Lindenstraße 5 12345 Bad Musterstadt"


def test_legal_representative_between_name_and_company_address():
    from supplier_locations import imprint_facts
    page = dict(id="Q2", url="https://example.com/Impressum",
                text="Beispiel Werk GmbH diese vertr. d. d. Geschäftsführer Max Muster Lindenstraße 5 12345 Musterstadt Deutschland")
    assert imprint_facts("Beispiel Werk", page)[0].value == "Lindenstraße 5 12345 Musterstadt"


def position():
    return Position(
        name="Schrauben", material_group="Befestigung", quantity="100", quantity_unit="Stück",
        destination="Berlin", scope_evidence=SCOPE, destination_evidence=SCOPE, search_query="A2 Schrauben Lieferant", questions=[],
        must=[Criterion(field="Werkstoff", operator="eq", target="A2", unit="", evidence=evidence("Q1", "Werkstoff A2."))],
        quality=[Criterion(field="Verpackung", operator="eq", target="Karton", unit="", evidence=evidence("Q1", "Soll: Karton."))],
    )


def scenario():
    lines = ["100 Stück nach Berlin: Gesamtpreis netto 50,00 EUR inkl. aller Nebenkosten.",
             "Lieferzeit nach Berlin: 4 Kalendertage.", "Straßenentfernung nach Berlin: 80 km."]
    sources = {"Q1": {"kind": "input", "text": NEED}}
    offers = []
    for index, (supplier, material, packaging, price, delivery, distance) in enumerate([
        ("Nord", "A2", "Karton", "50,00", "4", "80"),
        ("Süd", "A2", "Kunststoff", "60,00", "2", "50"),
        ("West", "C1", "Karton", "30,00", "1", "30"),
        ("Ost", "A2", "Karton", "35,00", "", "55"),
    ], 2):
        ident = f"Testwerk {supplier}, Produkt T-{index}."
        source_id = f"Q{index}"
        specs = [
            ("Werkstoff", material, "", f"Werkstoff {material}."),
            ("Verpackung", packaging, "", f"Verpackung {packaging}."),
            ("total_price", price, "EUR", lines[0].replace("50,00", price)),
            ("distance_km", distance, "km", lines[2].replace("80", distance)),
        ]
        if delivery:
            specs.append(("delivery_days", delivery, "d", lines[1].replace("4", delivery)))
        sources[source_id] = {"kind": "pdf", "text": " ".join([ident] + [spec[3] for spec in specs])}
        offers.append(Offer(supplier=f"Testwerk {supplier}", product=f"T-{index}", identity=evidence(source_id, ident),
                            facts=[Fact(field=field, value=value, unit=unit, evidence=evidence(source_id, quote))
                                   for field, value, unit, quote in specs]))
    return offers, sources


def test_must_gate_then_weights():
    offers, sources = scenario()
    rows = evaluate(position(), offers, sources, [], WEIGHTS)
    assert [(row["supplier"], row["status"], row["score"]) for row in rows] == [
        ("Testwerk Nord", "geeignet", 86.25), ("Testwerk Süd", "geeignet", 63.33),
        ("Testwerk Ost", "offen", None), ("Testwerk West", "ausgeschlossen", None),
    ]
    assert rows[0]["components"] == {"total_price": 40, "quality": 30, "delivery_days": 10, "distance_km": 6.25}


def test_unverified_and_conflicting_facts_stay_open():
    offers, sources = scenario()
    offer = offers[0]
    additional = "Lieferzeit nach Berlin: 8 Kalendertage."
    sources["Q2"]["text"] += " " + additional
    offer.facts.append(Fact(field="delivery_days", value="8", unit="d", evidence=evidence("Q2", additional)))
    rows = evaluate(position(), [offer], sources, [], WEIGHTS)
    assert rows[0]["status"] == "offen"
    assert "Lieferzeit in Tagen" in rows[0]["missing"]


@pytest.mark.parametrize("value", ["5", "5,0", "050"])
def test_excerpt_does_not_establish_different_raw_value(value):
    quote = "Gesamtpreis netto 50,00 EUR."
    assert not grounded(evidence("Q1", quote), {"Q1": {"kind": "pdf", "text": quote}}, value)


def test_snippets_and_incomparable_prices_do_not_count():
    offers, sources = scenario()
    quote = "100 Stück nach Berlin: Einzelpreis netto 50,00 EUR inkl. aller Nebenkosten."
    sources["Q2"]["text"] += " " + quote
    offer = offers[0]
    price = next(fact for fact in offer.facts if fact.field == "total_price")
    price.evidence.quote = quote
    row = evaluate(position(), [offer], sources, [], WEIGHTS)[0]
    assert "total_price" not in row["metrics"]
    assert row["status"] == "offen"
    assert not grounded(evidence("Q2", quote), {"Q2": {"kind": "search", "text": quote}}, "50,00")


def test_quantity_and_units_are_not_guessed():
    assert number("1.200,50") == number("1,200.50")
    assert number("1.200") is None
    offers, sources = scenario()
    altered = position()
    altered.quantity = "10"
    row = evaluate(altered, offers[:1], sources, [], WEIGHTS)[0]
    assert row["status"] == "offen"


def test_pdf_text_and_empty_page():
    pages, warnings = pdf_pages(example_pdf([["Hersteller Nord. Werkstoff A2."], []]))
    assert pages == [(1, "Hersteller Nord. Werkstoff A2.")]
    assert any("OCR" in warning for warning in warnings)


@pytest.mark.parametrize("url", ["http://127.0.0.1/", "http://[::1]/", "https://user@example.org/", "http://example.org:9000/"])
def test_supplier_pages_cannot_fetch_local_or_unsafe_targets(url):
    with pytest.raises(ValueError):
        public_target(url)


def test_chat_completions_adapter_uses_requested_model():
    content = Scope(positions=[position()], questions=[]).model_dump_json()
    response = SimpleNamespace(raise_for_status=lambda: None, json=lambda: {"choices": [{"message": {"content": content}}]})
    with patch("harness.httpx.post", return_value=response) as post:
        result = Harness("chat", "model-local", "http://localhost:1234/v1", "test").ask("role", "scope", {}, Scope)
    assert result.positions[0].quantity == "100"
    assert post.call_args.args == ("http://localhost:1234/v1/chat/completions",)
    assert post.call_args.kwargs["json"]["model"] == "model-local"


def test_api_pdf_web_followup_and_persistence(tmp_path):
    offers, sources = scenario()
    quote = "Testwerk Ost, Produkt T-5. Werkstoff A2."
    pdf = example_pdf([[sources[f"Q{i}"]["text"]] for i in range(2, 6)])
    followup = {"kind": "web", "title": "Nachweis", "url": "https://example.org/nachweis", "text": quote}
    refined = offers[-1].model_copy(deep=True)
    refined.identity = evidence("Q6", "Testwerk Ost, Produkt T-5.")
    refined.facts = [Fact(field="Werkstoff", value="A2", unit="", evidence=evidence("Q6", quote))]
    offers[-1].facts = [fact for fact in offers[-1].facts if fact.field != "Werkstoff"]
    stages = [Scope(positions=[position()], questions=[]), Offers(offers=offers), Offers(offers=[refined])]
    with TestClient(create_app(tmp_path)) as client, \
            patch("harness.Harness.ask", side_effect=stages) as model, \
            patch("workflow.discover", side_effect=[([], []), ([followup], [])]) as search, \
            patch("workflow.research_locations"):
        file_response = client.get("/api/agent/files").json()
        assert any(Path(row["path"]).is_absolute() and row["content"] for row in file_response["files"])
        response = client.post("/api/agent/run", data={"need": NEED}, files=[("pdfs", ("Angebote.pdf", pdf, "application/pdf"))])
        assert response.status_code == 200, response.text
        report = response.json()
        session_id = report["session_id"]
        assert model.call_count == 3
        assert "Werkstoff" in search.call_args.args[0][0]
        rows = report["positions"][0]["offers"]
        # Delivered totals alone no longer participate in the material-price comparison.
        assert rows[0]["supplier"] == "Testwerk Süd"
        assert len([source for source in report["sources"] if source["kind"] == "pdf"]) == 4
        assert Path(next(file["path"] for file in report["used_files"] if file["name"] == "Angebote.pdf")).read_bytes() == pdf
        assert client.get("/api/agent/reports").json()[0]["session_id"] == session_id
        assert client.post("/api/agent/feedback", json={"session_id": session_id, "rating": -1, "note": "Test"}).status_code == 201

    with TestClient(create_app(tmp_path)) as restarted:
        assert restarted.get(f"/api/agent/reports/{session_id}").json() == report
    with database(tmp_path / "agent_memory.sqlite3") as conn:
        assert tuple(conn.execute("SELECT rating, note FROM feedback_log").fetchone()) == (-1, "Test")


def test_api_model_failure_and_invalid_upload_leave_no_session(tmp_path):
    with TestClient(create_app(tmp_path)) as client, patch("harness.Harness.ask", side_effect=ModelError("Modellfehler")):
        bad_pdf = client.post("/api/agent/run", data={"need": NEED}, files={"pdfs": ("bad.pdf", b"not a pdf", "application/pdf")})
        assert bad_pdf.status_code == 502  # Invalid document does not prevent entering the model stage.
        failed = client.post("/api/agent/run", data={"need": NEED, "web": "false"},
                             files={"pdfs": ("good.pdf", example_pdf(), "application/pdf")})
        assert failed.status_code == 502
        assert client.get("/api/agent/reports").json() == []
        assert not (tmp_path / "uploads").exists()


def test_api_rejects_cross_site_requests(tmp_path):
    with TestClient(create_app(tmp_path)) as client:
        assert client.post("/api/agent/run", headers={"Origin": "https://example.org"}, data={"need": NEED}).status_code == 403


def test_api_custom_weights_change_ranking_and_are_preserved(tmp_path):
    offers, sources = scenario()
    pdf = example_pdf([[sources[f"Q{i}"]["text"]] for i in range(2, 6)])
    weights = {"total_price": 0, "distance_km": 100}
    parsed = position()
    parsed.quality = []
    for offer in offers:
        offer.facts = [fact for fact in offer.facts if fact.field in {"Werkstoff", "distance_km"}]
    with TestClient(create_app(tmp_path)) as client, patch(
        "harness.Harness.ask", side_effect=[Scope(positions=[parsed], questions=[]), Offers(offers=offers)]
    ):
        response = client.post(
            "/api/agent/run", data={"need": NEED, "web": "false", "weights": json.dumps(weights)},
            files=[("pdfs", ("Angebote.pdf", pdf, "application/pdf"))],
        )
        assert response.status_code == 200, response.text
        report = response.json()
        assert report["weights"] == weights
        ranked = report["positions"][0]["offers"]
        assert [(row["supplier"], row["status"], row["score"]) for row in ranked] == [
            ("Testwerk Süd", "geeignet", 82.93), ("Testwerk Ost", "geeignet", 82.73),
            ("Testwerk Nord", "geeignet", 81.73), ("Testwerk West", "abweichend", None),
        ]
        assert ranked[0]["components"] == {"distance_km": 82.93}
        assert client.get(f"/api/agent/reports/{report['session_id']}").json()["weights"] == weights


@pytest.mark.parametrize("weights", [
    WEIGHTS | {"total_price": 41},
    WEIGHTS | {"total_price": 40.5, "quality": 29.5},
    WEIGHTS | {"total_price": 101, "quality": -31},
    {"total_price": 100},
])
def test_api_rejects_invalid_weights_before_model(tmp_path, weights):
    with TestClient(create_app(tmp_path)) as client, patch("harness.Harness.ask") as model:
        response = client.post("/api/agent/run", data={"need": NEED, "weights": json.dumps(weights)})
    assert response.status_code == 422
    model.assert_not_called()


def test_web_budget_returns_available_sources_while_one_is_still_pending():
    release = Event()

    def lookup(name):
        if name == "slow":
            release.wait(4)
        return [name], None

    try:
        result = web_batch(["slow", "fast"], lookup, 0.2, lambda name: f"{name} timed out")
        assert result == [([], "slow timed out"), (["fast"], None)]
    finally:
        release.set()


def test_partial_prices_use_one_basis_and_keep_unproven_candidates_visible():
    offers, sources = scenario()
    partial = position()
    partial.quantity = "1.000"
    partial.destination = ""
    partial.quality = []
    for index, value in [(0, "80,00"), (1, "100,00"), (2, "20,00")]:
        source_id = f"Q{index + 2}"
        qty = "1000" if index == 0 else "1.000"
        quote = f"{qty} Stück: Warenpreis netto {value} EUR ohne Versand."
        sources[source_id]["text"] += " " + quote
        offers[index].facts.append(Fact(field="net_price", value=value, unit="EUR", evidence=evidence(source_id, quote)))
    rows = evaluate(partial, offers, sources, ["An welchen Ort soll geliefert werden?"], WEIGHTS)
    assert [row["status"] for row in rows] == ["offen", "offen", "offen", "ausgeschlossen"]
    assert [row["partial_score"]["value"] if row["partial_score"] else None for row in rows] == [40, 32, None, None]
    assert all(row["score"] is None for row in rows)
    assert all({"distance_km", "total_price"}.isdisjoint(row["metrics"]) for row in rows)
    assert all("Versandkosten" in row["missing"] for row in rows)
    assert rows[0]["partial_score"]["basis"] == rows[1]["partial_score"]["basis"] == {"net_price": 40}
    message = recommendation(rows, ["An welchen Ort soll geliefert werden?"])
    assert "Vorläufige Empfehlung" in message and "Lieferort kann Versandkosten" in message


def test_partial_does_not_mix_delivered_and_goods_prices():
    offers, sources = scenario()
    quote = "100 Stück: Warenpreis netto 45,00 EUR ohne Versand."
    sources["Q3"]["text"] += " " + quote
    offers[0].facts = [fact for fact in offers[0].facts if fact.field in {"Werkstoff", "total_price"}]
    offers[1].facts = [
        next(fact for fact in offers[1].facts if fact.field == "Werkstoff"),
        Fact(field="net_price", value="45,00", unit="EUR", evidence=evidence("Q3", quote)),
    ]
    rows = evaluate(position(), offers[:2], sources, ["Welche Maße sind erforderlich?"], WEIGHTS)
    assert all(row["partial_score"] is None for row in rows)
    assert {key for row in rows for key in row["metrics"]} == {"total_price", "net_price"}
    assert "Technische Shortlist" in recommendation(rows)


def test_candidate_on_different_price_basis_does_not_block_shared_comparison():
    offers, sources = scenario()
    partial = position()
    partial.quality = []
    for index, value in [(0, "40,00"), (1, "45,00")]:
        source_id = f"Q{index + 2}"
        quote = f"100 Stück: Warenpreis netto {value} EUR ohne Versand."
        sources[source_id]["text"] += " " + quote
        offers[index].facts = [Fact(field="net_price", value=value, unit="EUR", evidence=evidence(source_id, quote))]
    offers[3].facts = [fact for fact in offers[3].facts if fact.field == "total_price"]
    rows = evaluate(partial, [offers[0], offers[1], offers[3]], sources, ["Welche Maße sind erforderlich?"], WEIGHTS)
    assert [row["partial_score"]["value"] if row["partial_score"] else None for row in rows] == [40, 35.56, None]
    assert all(row["partial_score"]["basis"] == {"net_price": 40} for row in rows[:2])
    assert "Weitere Kandidaten" in recommendation(rows, ["Welche Maße sind erforderlich?"])


def test_partial_can_compare_net_unit_prices_on_same_unit():
    offers, sources = scenario()
    partial = position()
    partial.destination = ""
    partial.quality = []
    for index, value in [(0, "0,14"), (1, "0,20")]:
        source_id = f"Q{index + 2}"
        quote = f"{value} EUR netto je Stück ohne Versand."
        sources[source_id]["text"] += " " + quote
        offers[index].facts.append(Fact(field="unit_net_price", value=value, unit="EUR", evidence=evidence(source_id, quote)))
    rows = evaluate(partial, offers[:2], sources, ["Lieferort fehlt"], WEIGHTS)
    assert [row["partial_score"]["value"] for row in rows] == [40, 28]
    assert all(row["partial_score"]["basis"] == {"unit_net_price": 40} for row in rows)


def test_api_searches_aluminum_with_missing_dimensions(tmp_path):
    need = "Aluminium EN AW-5754, 50 Stück. Lieferort Köln. Maße und Toleranz offen."
    market = "Rheinmetall Handel AL-R50. Legierung EN AW-5754. Dicke 3 mm. 50 Stück: Warenpreis netto 120,00 EUR ohne Versand."
    pos = Position(
        name="Aluminium EN AW-5754", material_group="Halbzeuge", quantity="50", quantity_unit="Stück",
        destination="Köln", scope_evidence=evidence("Q1", "50 Stück."), destination_evidence=evidence("Q1", "Köln"),
        search_query="Aluminium EN AW-5754 Lieferant", questions=["Welche Maße und Toleranz sind erforderlich?"] * 2,
        must=[Criterion(field="Legierung", operator="eq", target="EN AW-5754", unit="", evidence=evidence("Q1", "Aluminium EN AW-5754"))],
        quality=[],
    )
    hit = {"kind": "web", "title": "Aluminium", "url": "https://example.org/al-r50", "text": market}
    offer = Offer(supplier="Rheinmetall Handel", product="AL-R50", identity=evidence("Q2", "Rheinmetall Handel AL-R50."), facts=[
        Fact(field="Legierung", value="EN AW-5754", unit="", evidence=evidence("Q2", "Legierung EN AW-5754.")),
        Fact(field="Dicke", value="3", unit="mm", evidence=evidence("Q2", "Dicke 3 mm.")),
        Fact(field="net_price", value="120,00", unit="EUR", evidence=evidence("Q2", "50 Stück: Warenpreis netto 120,00 EUR ohne Versand.")),
    ])
    with TestClient(create_app(tmp_path)) as client, \
            patch("harness.Harness.ask", side_effect=[Scope(positions=[pos], questions=[]), Offers(offers=[offer])]) as model, \
            patch("workflow.discover", side_effect=[([hit], []), ([], [])]) as search, \
            patch("supplier_locations.fetch", return_value=([], [])), \
            patch("supplier_locations.discover", return_value=([], [])):
        response = client.post("/api/agent/run", data={"need": need})
    assert response.status_code == 200, response.text
    result = response.json()["positions"][0]
    assert "EN AW-5754" in search.call_args_list[0].args[0][0]
    assert search.call_count == 1 and model.call_count == 2
    assert result["destination"] == "Köln"
    assert sum("Toleranz" in question for question in result["questions"]) == 1
    row = result["offers"][0]
    assert row["specs"][0]["evidence"]["source_id"] == "Q2"
    assert row["metrics"]["net_price"]["value"] == 120 and row["status"] == "offen"
    assert row["partial_score"]["basis"] == {"net_price":80}


@pytest.mark.parametrize(("result", "expected"), [
    (None, "missing"),
    (OSError("executable not present"), "start_failed"),
    (SimpleNamespace(returncode=1, stdout="", stderr="Not logged in"), "signed_out"),
    (SimpleNamespace(returncode=1, stdout="", stderr="Unexpected error"), "unknown"),
    (SimpleNamespace(returncode=0, stdout="", stderr="Logged in using ChatGPT"), "ready"),
])
def test_codex_status_only_classifies_known_states(result, expected):
    with patch("harness.codex_executable", return_value="codex.exe" if result else None), \
            patch("harness.subprocess.run", return_value=result, side_effect=result if isinstance(result, OSError) else None):
        assert codex_status() == expected


def test_codex_override_takes_precedence(monkeypatch):
    monkeypatch.setenv("TRINITY_CODEX_EXE", r"C:\custom\codex.exe")
    with patch("harness.shutil.which") as search:
        assert codex_executable() == r"C:\custom\codex.exe"
        search.assert_not_called()


def test_search_continues_after_restart_and_keeps_candidates_pdf_and_weights(tmp_path):
    offers, source_map = scenario()
    initial = position()
    initial.destination = ""
    initial.destination_evidence = evidence("", "")
    followup = position()
    followup.destination = "72622 Nürtingen"
    followup.destination_evidence = evidence("Q1", "Lieferung nach 72622 Nürtingen.")
    pdf = example_pdf([[source_map[f"Q{i}"]["text"]] for i in range(2, 6)])
    custom = {"total_price": 60, "distance_km": 40}
    with TestClient(create_app(tmp_path)) as client, patch("harness.Harness.ask", side_effect=[
        Scope(positions=[initial], questions=[]), Offers(offers=offers)
    ]):
        r = client.post("/api/agent/run", data={"need": NEED, "web": "false", "weights": json.dumps(custom)},
                        files={"pdfs": ("Angebote.pdf", pdf, "application/pdf")})
        assert r.status_code == 200, r.text
        search_id = r.json()["search_id"]
        # Simulate an existing report from before the chat migration.
        with database(tmp_path / "agent_memory.sqlite3") as conn:
            conn.execute("DELETE FROM search_turns WHERE search_id=?", (search_id,))
    with TestClient(create_app(tmp_path)) as restarted, patch("harness.Harness.ask", side_effect=[
        Scope(positions=[followup], questions=[]), Offers(offers=[])
    ]) as model:
        assert len(restarted.get(f"/api/agent/searches/{search_id}").json()["turns"]) == 1
        r = restarted.post("/api/agent/run", data={"need": "Lieferung nach 72622 Nürtingen.",
                                                 "search_id": search_id, "web": "false"})
        assert r.status_code == 200, r.text
        assert "100 Stück" in model.call_args_list[0].args[2]["sources"][0]["text"]
        report = r.json()
        assert report["search_id"] == search_id and report["weights"] == custom
        assert report["positions"][0]["destination"] == "72622 Nürtingen"
        assert len(report["positions"][0]["offers"]) == 4
        assert {src["id"] for src in report["sources"] if src["kind"] == "pdf"} == {"Q2", "Q3", "Q4", "Q5"}
        assert any("Lieferort: offen → 72622 Nürtingen" in change for change in report["changes"])
        assert len(restarted.get(f"/api/agent/searches/{search_id}").json()["turns"]) == 2
        assert len(restarted.get("/api/agent/searches").json()) == 1


def test_variant_pack_price_shipping_and_rank():
    offers, sources = scenario()
    for i, (offer, price) in enumerate(zip(offers[:2], ["5,00", "6,00"]), 2):
        key = f"Q{i}"
        listing = f"{offer.product}: {price} EUR netto je Packung, 20 Stück pro Packung, ohne Versand."
        freight = f"{offer.product}: Versandkosten 3,00 EUR netto für 100 Stück nach Berlin, keine weiteren Nebenkosten."
        sources[key]["text"] += " " + listing + " " + freight
        offer.facts = [fact for fact in offer.facts if fact.field != "total_price"] + [
            Fact(field="listed_price", value=price, unit="EUR", evidence=evidence(key, listing)),
            Fact(field="shipping_cost", value="3,00", unit="EUR", evidence=evidence(key, freight)),
        ]
    rows = evaluate(position(), offers, sources, [], WEIGHTS)
    assert rows[0]["listed_price"]["pack_size"] == 20
    assert rows[0]["metrics"]["total_price"]["value"] == 28
    assert any(row["status"] == "ausgeschlossen" for row in rows)
    pending = position()
    pending.destination = ""
    rows = evaluate(pending, offers[:2], sources, ["Lieferort?"], WEIGHTS)
    assert "total_price" not in rows[0]["metrics"]
    assert "Vorläufige Empfehlung" in recommendation(rows)
    pending.quantity = "93"
    rows = evaluate(pending, [offers[0]], sources, ["Lieferort?"], WEIGHTS)
    assert "100 Stück" in rows[0]["listed_price"]["order_note"]
    assert "net_price" not in rows[0]["metrics"]
    wrong = offers[0].model_copy(deep=True)
    wrong.facts = [fact for fact in offers[1].facts if fact.field == "listed_price"]
    assert evaluate(pending, [wrong], sources, [], WEIGHTS)[0]["listed_price"] is None


def test_product_jsonld_keeps_variant_prices_separate():
    from bs4 import BeautifulSoup
    from research import product_lines
    variants = [{"@type": "Product", "name": name, "sku": sku,
                 "offers": {"@type": "Offer", "price": value, "priceCurrency": "EUR"}}
                for name, sku, value in [("M6 × 40", "A40", "10.90"), ("M6 × 50", "A50", "13.90")]]
    data = json.dumps({"@type": "ProductGroup", "hasVariant": variants})
    lines = product_lines(BeautifulSoup(f'<script type="application/ld+json">{data}</script>', "html.parser"),
                          "https://shop.example.org/product")
    assert any("A40" in line and "10.90" in line and "13.90" not in line for line in lines)
    assert any("A50" in line and "13.90" in line and "10.90" not in line for line in lines)


def test_shop_variant_title_can_specify_pack_and_plural_is_not_a_must_failure():
    from purchasing import compare
    offers, sources = scenario()
    product = "Universalschraube TX 4x40 mm 200 Stück"
    quote = f"Testwerk Nord · {product} · 20,95 EUR / Pack inkl. MwSt."
    offers[0].product = product
    offers[0].identity = evidence("Q2", quote)
    offers[0].facts = [Fact(field="listed_price", value="20,95", unit="EUR", evidence=evidence("Q2", quote))]
    sources["Q2"]["text"] = quote
    result = evaluate(position(), [offers[0]], sources, [], WEIGHTS)[0]
    assert result["listed_price"]["pack_size"] == 200 and result["listed_price"]["tax"] == "brutto"
    assert not result["metrics"]
    criterion = Criterion(field="Typ", operator="eq", target="Universalschrauben", unit="", evidence=evidence("Q1", NEED))
    matching = Fact(field="Typ", value="Universalschraube", unit="", evidence=evidence("Q2", quote))
    assert compare(criterion, matching) is True
    matching.value = "Spanplattenschraube"
    assert compare(criterion, matching) is False


def test_routing_uses_explicit_dispatch_location_and_destination():
    from workflow import add_routes
    offers, sources = scenario()
    offer = offers[0]
    offer.facts = [fact for fact in offer.facts if fact.field != "distance_km"]
    entries = [{"id": key, **value} for key, value in sources.items()]
    origin = "Versandstandort Leipzig."
    sources["Q2"]["text"] += " " + origin
    entries[1]["text"] = sources["Q2"]["text"]
    fact = Fact(field="dispatch_location", value="Leipzig", unit="", evidence=evidence("Q2", origin))
    offer.facts.append(fact)
    with patch("workflow.route_distance", return_value=("https://route.example.org/result", "188.20", "12.37,51.34; 13.40,52.52")) as route:
        add_routes([offer], position(), entries)
    route.assert_called_once_with("Leipzig", "Berlin")
    discovered = {entry["id"]: entry for entry in entries}
    row = evaluate(position(), [offer], discovered, [], WEIGHTS)[0]
    assert row["metrics"]["distance_km"]["value"] == 188.2
    assert "OSRM" in row["metrics"]["distance_km"]["fact"]["evidence"]["quote"]


def test_pdf_attachments_append_remove_and_survive_restart(tmp_path):
    first = example_pdf([["Testwerk Nord. Schrauben K-100. Werkstoff A2."]])
    second = example_pdf([["Testwerk Süd. Schrauben K-101. Werkstoff A4."]])
    stages = [Scope(positions=[position()], questions=[]), Offers(offers=[])]
    with TestClient(create_app(tmp_path)) as client, patch("harness.Harness.ask", side_effect=stages * 2):
        for name, payload, status in [("a.pdf", first, "ready"), ("defekt.pdf", b"not pdf", "error")]:
            result = client.post("/api/agent/pdf-check", files={"pdf": (name, payload, "application/pdf")})
            assert result.json()["status"] == status
        result = client.post("/api/agent/run", data={"need": NEED, "web": "false"}, files=[
            ("pdfs", ("a.pdf", first, "application/pdf")), ("pdfs", ("defekt.pdf", b"not pdf", "application/pdf")),
        ]).json()
        search_id = result["search_id"]
        assert [item["status"] for item in result["attachments"]] == ["ready", "error"]
        assert [item["name"] for item in result["pdf_review"]] == ["a.pdf"]
        follow = client.post("/api/agent/run", data={"need": "Bitte weiter", "web": "false", "search_id": search_id},
                             files={"pdfs": ("b.pdf", second, "application/pdf")}).json()
        assert [item["name"] for item in follow["attachments"]] == ["a.pdf", "defekt.pdf", "b.pdf"]
        ident = follow["attachments"][0]["id"]
        assert client.delete(f"/api/agent/searches/{search_id}/attachments/{ident}").status_code == 200

    with TestClient(create_app(tmp_path)) as restarted, patch("harness.Harness.ask", side_effect=stages) as model:
        history = restarted.get(f"/api/agent/searches/{search_id}").json()
        assert [item["name"] for item in history["attachments"]] == ["defekt.pdf", "b.pdf"]
        assert history["turns"][0]["report"]["pdf_review"][0]["name"] == "a.pdf"
        continued = restarted.post("/api/agent/run", data={"need": "Weiter", "web": "false", "search_id": search_id}).json()
        assert "K-100" not in str(model.call_args_list)
        assert [item["name"] for item in continued["pdf_review"]] == ["b.pdf"]
        assert all(source.get("title") != "a.pdf" for source in continued["sources"])


def test_pdf_variant_row_and_deep_page(tmp_path):
    from purchasing import DocumentFinding, DocumentOffers
    positions = [position()]
    positions[0].name = "Schrauben K-100"
    first_row = "K-100 | 4 x 40 mm | TX20 | Senkkopf | A2 | Teilgewinde | 200 Stück | 20,95 EUR"
    wrong_row = "K-101 | 4 x 45 mm | TX20 | Senkkopf | A2 | Teilgewinde | 250 Stück | 23,95 EUR"
    pages = [["Testwerk Nord. Inhaltsverzeichnis."]] + [["Technische Grundlagen."]] * 34 + [[first_row, wrong_row]]
    result = Offer(supplier="Testwerk Nord", product="K-100", identity=evidence("Q37", first_row), facts=[
        Fact(field="Artikelnummer", value="K-100", unit="", evidence=evidence("Q37", first_row)),
        Fact(field="Packungsgröße", value="200", unit="Stück", evidence=evidence("Q37", first_row)),
        Fact(field="Preis", value="20,95", unit="EUR", evidence=evidence("Q37", first_row)),
        Fact(field="Packungsgröße", value="250", unit="Stück", evidence=evidence("Q37", wrong_row)),
        Fact(field="Preis", value="23,95", unit="EUR", evidence=evidence("Q37", wrong_row)),
    ])
    with TestClient(create_app(tmp_path)) as client, patch("harness.Harness.ask", side_effect=[
        Scope(positions=positions, questions=[]), DocumentOffers(offers=[result], findings=[
            DocumentFinding(field="Packungsgröße", value="200", variant="K-100", evidence=evidence("Q37", first_row)),
            DocumentFinding(field="Preis", value="23,95", variant="K-100", evidence=evidence("Q37", wrong_row)),
            DocumentFinding(field="listed_price", value="23,95", variant="K-100", evidence=evidence("Q37", first_row + "\n" + wrong_row)),
            DocumentFinding(field="Artikelnummer", value="K-101", variant="", evidence=evidence("Q37", wrong_row)),
        ]),
    ]):
        report = client.post("/api/agent/run", data={"need": NEED + " Artikel K-100.", "web": "false"},
                             files={"pdfs": ("Sortiment.pdf", example_pdf(pages), "application/pdf")}).json()
    specs = report["positions"][0]["offers"][0]["specs"]
    assert {fact["value"] for fact in specs} == {"K-100", "200", "20,95"}
    assert all(fact["evidence"]["source_id"] == "Q37" for fact in specs)
    assert [finding["value"] for finding in report["positions"][0]["pdf_findings"]] == ["200"]
    assert 36 in report["pdf_review"][0]["pages"]
    assert next(source for source in report["sources"] if source["id"] == "Q37")["page"] == 36


def test_pdf_errors_distinguish_password_scan_size_and_corruption():
    from io import BytesIO
    from pypdf import PdfReader, PdfWriter
    from research import inspect_pdf, PDFError, MAX_PDF_BYTES
    data = example_pdf([["Produktdaten"]])
    for password in ("", "geheim"):
        out = BytesIO()
        writer = PdfWriter(clone_from=PdfReader(BytesIO(data)))
        writer.encrypt(password)
        writer.write(out)
        if password:
            with pytest.raises(PDFError, match="Passwort erforderlich"):
                inspect_pdf(out.getvalue())
        else:
            assert inspect_pdf(out.getvalue())[0] == [(1, "Produktdaten")]
    assert "OCR nötig" in inspect_pdf(example_pdf([[]]))[2][0]
    with pytest.raises(PDFError, match="beschädigt"):
        inspect_pdf(b"%PDF-1.5\nbroken")
    with pytest.raises(PDFError, match="Dateigröße"):
        inspect_pdf(b"x" * (MAX_PDF_BYTES + 1))


def test_catalog_sections_and_distinct_price_columns_reach_pdf_only_report(tmp_path):
    need = "1.000 Spanplattenschrauben, 4 × 40 mm, Senkkopf, TX-Antrieb."
    p = position()
    p.name, p.quantity, p.destination = "Spanplattenschrauben", "1.000", ""
    p.scope_evidence = evidence("Q1", "1.000 Spanplattenschrauben")
    p.quantity_unit = ""  # Model left the literal count unit open.
    p.must = [
        Criterion(field="Schraubenart", operator="eq", target="Spanplattenschrauben", unit="", evidence=evidence("Q1", need)),
        Criterion(field="Nenndurchmesser", operator="eq", target="4", unit="mm", evidence=evidence("Q1", "4 × 40 mm")),
        Criterion(field="Nennlänge", operator="eq", target="40", unit="mm", evidence=evidence("Q1", "4 × 40 mm")),
        Criterion(field="Kopfform", operator="eq", target="Senkkopf", unit="", evidence=evidence("Q1", need)),
        Criterion(field="Antrieb", operator="eq", target="TX-Antrieb", unit="", evidence=evidence("Q1", "TX-Antrieb")),
    ]
    p.quality = []
    price = example_pdf([[
        "Artikelpreisliste | Datum: | 15.1.2024",
        "Artikelnr | Bezeichnung | Verp.-Einh. | Pr.Einh. | VK netto €",
        "A400 | Spanplattenschraube 4,0 x 40/26 VZ TX20 | 500 | 100 | 2,65 €",
        "A450 | Spanplattenschraube 4,0 x 45 VZ TX20 | 200 | 50 | 4,99 €",
        "Alle Preise zzgl. MwSt."
    ]])
    catalog = example_pdf([["Spanplattenschrauben | Senkkopf", "TX-Antrieb", "verzinkt blau passiviert",
                            "Artikelnummer | Artikelbeschreibung",
                            "B450 | Spanplattenschraube 4 x 45 mm TX20 mit Teilgewinde",
                            "B400 | Spanplattenschraube 4 x 40 mm TX20",
                            "C400 | Spanplattenschraube 4 x 40 mm PZ"]])
    with TestClient(create_app(tmp_path)) as client, patch("harness.Harness.ask", side_effect=[
        Scope(positions=[p], questions=[]), Offers(offers=[]),
    ]):
        result = client.post("/api/agent/run", data={"need": need, "web": "false"}, files=[
            ("pdfs", ("Listenpreise.pdf", price, "application/pdf")), ("pdfs", ("Katalog.pdf", catalog, "application/pdf")),
        ])
        assert result.status_code == 200, result.text[:800]
        followup = client.post("/api/agent/run",data={"need":"Berechne die Materialpreise bitte neu.","web":"false","search_id":result.json()["search_id"]})
        assert followup.status_code == 200, followup.text[:800]
        assert "26.50" in followup.json()["answer"] or "26,50" in followup.json()["answer"]
    assert result.status_code == 200, result.text[:800]
    pos = result.json()["positions"][0]
    rows = {row["product"]:row for row in pos["offers"]}
    assert set(rows) == {"A400", "B400", "C400"}
    offer = rows["A400"]
    assert offer["technical_status"] == "Nachweis offen"
    assert offer["catalog_price"]["basis"] == 100 and offer["catalog_price"]["pack"] == 500
    assert offer["catalog_price"]["calculation"] == "1000 ÷ 100 × 2,65 EUR = 26,50 EUR"
    assert offer["metrics"]["net_price"]["value"] == 26.5
    assert "historisch:15.1.2024" in offer["metrics"]["net_price"]["basis"]
    assert rows["B400"]["technical_status"] == "passend"
    assert rows["C400"]["status"] == "abweichend"
    assert not any(item["field"] == "Gewindeart" for item in rows["B400"]["specs"])
    assert "Vorläufige Empfehlung" in pos["recommendation"]
    assert "Historischer Listenstand" in pos["recommendation"]


def test_full_fictional_offers_still_give_rank_and_recommendation():
    offers, sources = scenario()
    rows = evaluate(position(), offers, sources, [], WEIGHTS)
    assert [row["score"] for row in rows[:2]] == [86.25, 63.33]
    assert "Testwerk Nord" in recommendation(rows)
    assert any(row["status"] == "ausgeschlossen" for row in rows)


def test_unavailable_street_route_is_explicit_and_not_replaced_with_airline(monkeypatch):
    from workflow import add_routes
    monkeypatch.delenv("TRINITY_GEOCODER_URL", raising=False)
    offers, sources = scenario()
    offer = offers[0]
    offer.facts = [fact for fact in offer.facts if fact.field != "distance_km"]
    address = "Musterstraße 1, 10115 Berlin"
    quote = f"Testwerk Nord · {address} · Koordinaten 52.532, 13.384"
    sources["Q2"]["text"] += "\n"+quote
    sources["Q1"]["text"] += "\nBerlin (52.520, 13.405)"
    for key, value in [("company_address", address), ("company_coordinates", "52.532, 13.384")]:
        offer.facts.append(Fact(field=key, value=value, unit="", evidence=evidence("Q2", quote)))
    entries = [{"id": key, **value} for key,value in sources.items()]
    with patch("workflow.route_distance", return_value=None), patch("workflow.air_distance",return_value=None):
        add_routes([offer], position(), entries)
    row = evaluate(position(), [offer], {item["id"]:item for item in entries}, [], WEIGHTS)[0]
    assert row["distance"]["status"] == "open"
    assert row["distance"]["label"].startswith("Ab Firmenstandort, Versandort unbestätigt")
    assert row["reasons"]["distance_km"].startswith(("Geokodierung", "Routing:"))
    assert "distance_km" not in row["metrics"]
    assert row["score"] is None


def test_catalog_web_updates_require_exact_article_and_do_not_treat_imprint_as_dispatch():
    from catalog_web import ArticleUpdate, WebUpdates, plan, verified_updates
    from unittest.mock import Mock
    offers, sources = scenario()
    offer = offers[0]
    _, queries = plan([offer], sources)
    assert any(f"{offer.supplier} {offer.product} Preis" in q for q in queries)
    assert any("Impressum" in q for q in queries)
    address = "Musterstraße 1, 10115 Berlin"
    quote = f"Impressum · {offer.supplier} · {address}."
    wrong = "T-25: 40 EUR netto für 100 Stück."
    page = {"id":"Q7", "kind":"web", "url":"https://example.test/", "text":quote+"\n"+wrong}
    h = Mock()
    h.ask.return_value = WebUpdates(updates=[ArticleUpdate(supplier=offer.supplier, article=offer.product, facts=[
        Fact(field="company_address", value=address, unit="", evidence=evidence("Q7", quote)),
        Fact(field="dispatch_location", value=address, unit="", evidence=evidence("Q7", quote)),
        Fact(field="total_price", value="40", unit="EUR", evidence=evidence("Q7", wrong)),
    ])])
    result = verified_updates(h, "", [offer], [page], position(), "both")
    assert [fact.field for fact in result[(offer.supplier,offer.product)]] == ["company_address"]


def test_precise_followup_targets_only_named_supplier():
    from catalog_web import request_kind
    previous = {"positions":[{"offers":[{"supplier":"Hexago", "technical_status":"passend"}, {"supplier":"Paulis"}]}]}
    assert request_kind("Bitte prüfe den Standort von Hexago.",previous) == ("location", {"Hexago"})
    assert request_kind("Prüfe den Standort von Hexago und liefere nach Köln",previous) is None


def test_epdm_rounds_whole_rolls_and_compares_same_price_basis():
    demand = "Mindestens 20 m selbstklebendes EPDM D-Profil 9 × 6 mm nach Berlin. Mehrere Rollen sind erlaubt."
    pos = OrderPosition.model_validate(position().model_dump())
    pos.quantity, pos.quantity_unit, pos.whole_packs_allowed, pos.quality = "20", "m", True, []
    pos.must = [Criterion(field=field, operator="eq", target=value, unit=unit, evidence=evidence("Q1", demand))
                for field, value, unit in (("Material", "EPDM", ""), ("Profil", "D-Profil", ""),
                                            ("Montage", "selbstklebendes", ""), ("Maße", "9 × 6", "mm"))]
    offers, sources = [], {"Q1": {"kind": "input", "text": demand}}
    for index, (supplier, material, profile, price) in enumerate([
        ("Anbieter Nord", "EPDM-Gummi", "D-Profil", "7,25"),
        ("Anbieter Süd", "Gummi", "", "8,00"),
        ("Anbieter Ost", "PVC", "E-Profil", "5,00"),
    ], 2):
        source_id = f"Q{index}"
        product = f"{supplier} Dichtung 6 m"
        quote = f"{product}: {price} € pro Rolle, inkl. MwSt. zzgl. Versandkosten."
        specs = f"{material} {profile} selbstklebend 9 x 6 mm."
        sources[source_id] = {"kind": "web", "text": quote + " " + specs}
        facts = [Fact(field=field, value=value, unit=unit, evidence=evidence(source_id, specs))
                 for field, value, unit in zip(("Material", "Profil", "Montage", "Maße"),
                                              (material, profile, "selbstklebend", "9 x 6"), ("", "", "", "mm")) if value]
        facts.append(Fact(field="listed_price", value=price, unit="EUR", evidence=evidence(source_id, quote)))
        offers.append(Offer(supplier=supplier, product=product, identity=evidence(source_id, quote), facts=facts))
    first, second, third = evaluate(pos, offers, sources, [], WEIGHTS)
    assert first["technical_status"] == "passend"
    assert second["technical_status"] == "Nachweis offen"
    assert third["status"] == "ausgeschlossen"
    assert first["listed_price"]["order_quantity"] == 4
    assert first["listed_price"]["supplied_length"] == 24
    assert first["listed_price"]["goods_value"] == 29
    assert first["listed_price"]["price_basis"] == "Rolle à 6 m"
    assert first["listed_price"]["tax"] == "brutto"
    assert first["partial_score"] == {"value": 40, "basis": {"gross_goods_price": 40},
                                      "components": {"gross_goods_price": 40}}
    assert second["partial_score"]["value"] == 36.25
    assert first["score"] is None and "total_price" not in first["metrics"]
    assert "Vorläufige Empfehlung: Anbieter Nord" in recommendation([first, second, third])
    pos.whole_packs_allowed = False
    assert "gross_goods_price" not in evaluate(pos, offers[:1], sources, [], WEIGHTS)[0]["metrics"]


def test_exclusion_question_uses_existing_report_without_model_or_web():
    from workflow import followup_intent, run_workflow
    offers, sources = scenario()
    rows = evaluate(position(), offers, sources, [], WEIGHTS)
    previous = {"positions": [{"offers": rows}], "questions": [], "sources": [], "weights": WEIGHTS}
    with patch("workflow.discover", side_effect=AssertionError("unexpected web search")):
        reply = run_workflow(None, {}, "Warum wurde Testwerk West ausgeschlossen?", [], True, [], WEIGHTS, previous)
    assert reply["answer_only"]
    assert 'Testwerk West' in reply["answer"] and "C1" in reply["answer"]
    assert reply["positions"] == previous["positions"]
    assert followup_intent("Warum wurde HORNBACH ausgeschlossen? Berechne die Rollen und suche Alternativen.") == (
        True, False, True, True)
    assert followup_intent("Korrigiere die Menge auf 24 m und berechne neu.") == (False, True, True, False)


@pytest.mark.parametrize("question", [
    "Was ist mit dem Preis von OBO",
    "Wie weit ist OBO von Stuttgart entfernt?",
    "Wie wurde der Preis berechnet?",
    "Und was bedeutet das für meine Bestellung",
])
def test_conversational_followup_answers_from_the_existing_comparison(question):
    from workflow import FollowupAnswer, run_workflow
    harness = Mock()
    harness.ask.return_value = FollowupAnswer(answer="Für OBO ist kein Direktpreis belegt.")
    previous = {"positions": [{"destination": "Stuttgart", "offers": [
        {"supplier": "OBO", "product": "2331874", "listed_price": None},
    ]}], "questions": [], "sources": [], "weights": WEIGHTS, "answer": "Der Vergleich steht fest."}
    with patch("workflow.discover", side_effect=AssertionError("unexpected web search")), \
            patch("workflow.add_routes", side_effect=AssertionError("unexpected routing")):
        reply = run_workflow(harness, {}, question, [], True, [], WEIGHTS, previous,
                             ["500 Kabelbinder nach Stuttgart", question])
    assert reply["answer_only"] and reply["answer"] == harness.ask.return_value.answer
    assert reply["positions"] == previous["positions"]
    harness.ask.assert_called_once()
    _, _, payload, contract = harness.ask.call_args.args
    assert contract is FollowupAnswer and payload["question"] == question
    assert payload["positions"][0]["offers"][0]["listed_price"] is None
    assert payload["previous_answer"] == previous["answer"]


def test_location_from_supplier_imprint_survives_product_fact_filter():
    from workflow import extract
    from unittest.mock import Mock
    offers, sources = scenario()
    offer = offers[0]
    quote = "Impressum Testwerk Nord: Musterstraße 1, 10115 Berlin."
    sources["Q8"] = {"kind": "web", "url": "https://example.test/impressum", "title": "Impressum", "text": quote}
    sources["Q2"].update(kind="web", title="Angebot", url="https://example.test/produkt")
    offer.facts.append(Fact(field="company_address", value="Musterstraße 1, 10115 Berlin", unit="",
                            evidence=evidence("Q8", quote)))
    h = Mock()
    h.ask.return_value = Offers(offers=[offer])
    found = extract(h, "", position(), [{"id":key, **value, "title":value.get("title","Quelle")}
                                       for key,value in sources.items()], [])
    assert any(fact.field == "company_address" for fact in found[0].facts)
    assert not any(fact.field == "dispatch_location" for fact in found[0].facts)


def test_photon_geocoding_filters_pois_and_keeps_same_address_cluster():
    from research import geocode
    from unittest.mock import Mock
    def item(lat, lon, **properties):
        return {"properties":properties, "geometry":{"coordinates":[lon,lat]}}
    response = Mock()
    response.url = "https://geocode.example/api/?q=Berlin"
    response.json.return_value = {"features":[
        item(52.52,13.4, name="Berlin", postcode="10115", osm_key="place", type="city"),
        item(52.53,13.4, name="Cafe", city="Berlin", postcode="10115", type="house"),
    ]}
    with patch("research.httpx.get", return_value=response):
        assert geocode("https://geocode.example/api","10115 Berlin")[0] == (52.52,13.4)
    response.json.return_value = {"features":[
        item(52.52,13.4, street="Musterstraße", housenumber="2", postcode="10115"),
        item(52.5201,13.4001, street="Musterstraße", housenumber="4", postcode="10115"),
        item(53.5,13.4, street="Falsche Straße", housenumber="2", postcode="10115"),
    ]}
    with patch("research.httpx.get", return_value=response):
        assert geocode("https://geocode.example/api","Musterstraße 2 + 4 10115 Berlin")[0] == (52.52,13.4)
    response.json.return_value["features"].append(
        item(54.52,13.4, street="Musterstraße", housenumber="2", postcode="10115"))
    with patch("research.httpx.get", return_value=response):
        from geocoding import GeocodingError
        with pytest.raises(GeocodingError,match="Mehrere Orte passen"):
            geocode("https://geocode.example/api","Musterstraße 2 + 4 10115 Berlin doppelt")


def test_street_route_uses_company_instead_of_branch_and_is_reused():
    from workflow import add_routes
    offers, sources = scenario()
    offer = offers[0]
    offer.facts = [fact for fact in offer.facts if fact.field != "distance_km"]
    address = "Musterstraße 2 + 4 10115 Berlin"
    quote = f"{offer.supplier} Filiale Berlin {address}"
    sources["Q2"]["text"] += quote
    offer.facts.append(Fact(field="branch_address",value=address,unit="",evidence=evidence("Q2",quote)))
    entries = [{"id":key, **value} for key,value in sources.items()]
    with patch("workflow.route_distance",return_value=("https://route.example/result","40.33","13.4,52.52;13.5,52.6")) as route:
        add_routes([offer],position(),entries)
        route.assert_not_called()
        company = "Musterstraße 10, 10115 Berlin"
        company_quote = f"Testwerk Nord Firmenanschrift {company}."
        sources["Q2"]["text"] += company_quote
        entries[1]["text"] = sources["Q2"]["text"]
        offer.facts.append(Fact(field="company_address",value=company,unit="",evidence=evidence("Q2",company_quote)))
        add_routes([offer],position(),entries)
        add_routes([offer],position(),entries)
        route.assert_called_once()
    row = evaluate(position(),[offer],{item["id"]:item for item in entries},[],WEIGHTS)[0]
    assert row["metrics"]["distance_km"]["value"] == 40.33
    assert row["distance"]["approximate"]
    assert row["distance"]["origin"] == company
    assert row["distance"]["label"].startswith("Ab Firmenstandort, Versandort unbestätigt")


def test_partial_points_cover_only_shared_seventy_percent():
    offers, sources = scenario()
    for offer in offers[:2]:
        offer.facts = [fact for fact in offer.facts if fact.field not in {"delivery_days", "distance_km"}]
    rows = evaluate(position(),offers[:2],sources,[],WEIGHTS)
    assert rows[0]["partial_score"]["value"] == 70
    assert rows[0]["partial_score"]["basis"] == rows[1]["partial_score"]["basis"] == {"total_price":40,"quality":30}
    assert rows[1]["partial_score"]["value"] == 33.33
    assert all(row["score"] is None for row in rows)
    assert "Vorläufige Empfehlung: Testwerk Nord" in recommendation(rows)


def test_targeted_research_includes_requested_new_supplier():
    from workflow import length_research
    pos = position()
    queries = length_research(pos, [], "Prüfe bei HORNBACH den Preis und finde Alternativen.")
    assert any("HORNBACH" in query and "Preis" in query for query in queries)
    assert any("HORNBACH" in query and "Impressum" in query for query in queries)


def test_all_supplier_addresses_are_routed_on_shared_basis_without_three_supplier_limit():
    from workflow import add_routes
    offers, sources = scenario()
    for index, offer in enumerate(offers, 1):
        offer.facts = [fact for fact in offer.facts if fact.field != "distance_km"]
        source_id = offer.identity.source_id
        address = f"Musterstraße {index}, 10115 Berlin"
        quote = f"{offer.supplier} Firmenanschrift {address}."
        sources[source_id]["text"] += quote
        offer.facts.append(Fact(field="company_address",value=address,unit="",evidence=evidence(source_id,quote)))
    entries = [{"id":key, **value} for key,value in sources.items()]
    with patch("workflow.route_distance", return_value=("https://route.example/","40.33","13.4,52.5; 13.5,52.6")) as route:
        add_routes(offers,position(),entries)
        assert route.call_count == 4  # Four different verified addresses.
    rows = evaluate(position(),offers,{source["id"]:source for source in entries},[],WEIGHTS)
    assert len(rows) == 4
    assert all(row["distance"]["status"] == "ready" for row in rows)
    assert all(row["distance"]["label"].startswith("Ab Firmenstandort, Versandort unbestätigt") for row in rows)
    assert all(row["distance"]["target_approximate"] for row in rows)
    assert len({row["metrics"]["distance_km"]["basis"] for row in rows}) == 1
    assert all("ca. 40 km" in row["distance"]["evidence"]["quote"] for row in rows)
    assert any(row["status"] == "ausgeschlossen" and row["distance"] for row in rows)


def test_distance_is_invalidated_when_destination_changes_and_dispatch_takes_priority():
    from workflow import add_routes
    offers, sources = scenario()
    offer = offers[0]
    offer.facts = [fact for fact in offer.facts if fact.field != "distance_km"]
    quote = "Testwerk Nord Firmenanschrift Köln. Versandstandort Leipzig."
    sources["Q2"]["text"] += quote
    for field,value in [("company_address","Köln"),("dispatch_location","Leipzig")]:
        offer.facts.append(Fact(field=field,value=value,unit="",evidence=evidence("Q2",quote)))
    entries = [{"id":key, **value} for key,value in sources.items()]
    with patch("workflow.route_distance", return_value=("https://route.example/","188.20","12.3,51.3; 13.4,52.5")) as route:
        add_routes([offer],position(),entries)
        route.assert_called_once_with("Leipzig","Berlin")
    changed = position()
    changed.destination = "Musterstraße 10, 10115 Berlin"
    with patch("workflow.route_distance", return_value=("https://route.example/","187.20","12.3,51.3; 13.4,52.5")) as route:
        add_routes([offer],changed,entries)
        route.assert_called_once_with("Leipzig",changed.destination)
    row = evaluate(changed,[offer],{source["id"]:source for source in entries},[],WEIGHTS)[0]
    assert row["distance"]["origin_kind"] == "dispatch"
    assert row["distance"]["approximate"] is False
    assert row["metrics"]["distance_km"]["value"] == 187.2


def test_different_routing_bases_never_share_distance_points():
    offers, sources = scenario()
    rows = evaluate(position(),offers[:2],sources,[],WEIGHTS)
    for index,row in enumerate(rows):
        row["metrics"] = {"distance_km": {"value":10 + index,"fact":None,"basis":f"router-{index}"}}
    from purchasing import partial_comparison
    _, basis = partial_comparison(rows,WEIGHTS)
    assert "distance_km" not in basis


def test_dedicated_supplier_address_lookup_keeps_products_and_address_proofs():
    from supplier_locations import SupplierLocation, SupplierLocations, research_locations
    from workflow import add_sources
    from unittest.mock import Mock
    offers, sources = scenario()
    entries = [{"id":key, **value} for key,value in sources.items()]
    def lookup(queries, seen, limit):
        supplier = "Testwerk Nord" if "Testwerk Nord" in queries[0] else "Testwerk Süd"
        quote = f"{supplier} Impressum Musterstraße 1, 10115 Berlin."
        return [{"kind":"web","title":supplier,"url":"https://example.test/" + supplier[-3:],
                 "text":quote}], []
    def locations(system, task, payload, contract):
        assert contract is SupplierLocations
        return SupplierLocations(locations=[
            SupplierLocation(supplier=source["title"], facts=[
                Fact(field="company_address",value="Musterstraße 1, 10115 Berlin",unit="",
                     evidence=evidence(source["id"],source["text"]))])
            for source in payload["sources"]])
    h = Mock()
    h.ask.side_effect = locations
    before = [(offer.supplier,offer.product) for offer in offers[:2]]
    with patch("supplier_locations.discover",side_effect=lookup):
        research_locations(h,"",offers[:2],entries,add_sources,[])
    assert [(offer.supplier,offer.product) for offer in offers[:2]] == before
    assert all(any(fact.field == "company_address" for fact in offer.facts) for offer in offers[:2])


def test_cms_imprint_content_attribute_preserves_company_address():
    from bs4 import BeautifulSoup
    from research import component_lines
    soup = BeautifulSoup("""
        <cms-text-image content="&lt;p&gt;Beispiel Handel AG&lt;br /&gt;Musterstraße 11&lt;br /&gt;76879 Bornheim&lt;/p&gt;"></cms-text-image>
        <script>const address = 'Andere Anschrift 999';</script>
    ""","html.parser")
    assert component_lines(soup) == ["Beispiel Handel AG Musterstraße 11 76879 Bornheim"]


def test_photon_supports_international_postcodes_and_house_number_formats():
    from research import geocode
    from unittest.mock import Mock
    response = Mock()
    response.url = "https://international.example/api/"
    response.json.return_value = {"features":[{
        "properties":{"street":"Malobřevnovská","housenumber":"904/33","postcode":"169 00"},
        "geometry":{"coordinates":[14.35,50.08]}}]}
    with patch("research.httpx.get",return_value=response):
        assert geocode("https://international.example/api","Malobřevnovská 904/33, 16900 Praha 6")[0] == (50.08,14.35)


def test_verified_coordinate_source_routes_unresolved_address_and_is_not_reused_for_other_address():
    from supplier_locations import research_coordinates
    from workflow import add_routes,add_sources
    offers,sources = scenario()
    offer = offers[0]
    offer.facts = [fact for fact in offer.facts if fact.field != "distance_km"]
    address = "Musterstraße 1, 10115 Berlin"
    quote = f"Testwerk Nord Firmenanschrift {address}."
    sources["Q2"]["text"] += quote
    offer.facts.append(Fact(field="company_address",value=address,unit="",evidence=evidence("Q2",quote)))
    entries = [{"id":key, **value} for key,value in sources.items()]
    with patch("workflow.route_distance",return_value=None), patch("workflow.air_distance",return_value=None):
        add_routes([offer],position(),entries)
    coordinate_text = f"Testwerk Nord {address}. Koordinaten: 52.5200 | 13.4050"
    add_sources(entries,[{"kind":"web","title":"Standortkarte","url":"https://maps.example/standort","text":coordinate_text}])
    with patch("supplier_locations.discover",side_effect=AssertionError("stored proof should suffice")):
        assert research_coordinates([offer],entries,add_sources,[])
    with patch("workflow.route_distance",return_value=("https://route.example/","25.50","13.4,52.5;13.5,52.6")) as route:
        add_routes([offer],position(),entries)
        route.assert_called_once_with(address,"Berlin",origin_coordinates=((52.52,13.405),"https://maps.example/standort"))
    row = evaluate(position(),[offer],{item["id"]:item for item in entries},[],WEIGHTS)[0]
    assert "coordinates_evidence" in row["distance"]
    assert row["metrics"]["distance_km"]["value"] == 25.5
    changed_quote = "Testwerk Nord neue Firmenanschrift Musterstraße 7, 10115 Berlin."
    sources["Q2"]["text"] += changed_quote
    entries[1]["text"] = sources["Q2"]["text"]
    offer.facts = [fact for fact in offer.facts if fact.field != "company_address"]
    offer.facts.append(Fact(field="company_address",value="Musterstraße 7, 10115 Berlin",unit="",evidence=evidence("Q2",changed_quote)))
    with patch("workflow.route_distance",return_value=None) as route, patch("workflow.geocode",return_value=None), patch("workflow.air_distance",return_value=None):
        add_routes([offer],position(),entries)
        route.assert_called_once_with("Musterstraße 7, 10115 Berlin","Berlin")
