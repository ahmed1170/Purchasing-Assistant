"""Resolve addresses and localities through configurable OSM geocoders."""
from contextvars import ContextVar, copy_context
from functools import wraps
import math
import os
import re
import sqlite3
from threading import Lock
from time import monotonic, sleep, time
import unicodedata
from urllib.parse import urlsplit

import httpx


class GeocodingError(RuntimeError):
    def __init__(self, kind, message):
        super().__init__(message)
        self.kind = kind


_scope = ContextVar("geocode_run", default=None)
_cache = {}
_cache_lock = Lock()
_public_gate = Lock()
_public_next = 0.0
_local_types = {"city","town","village","municipality","hamlet","district","locality",
                "borough","suburb","city_district","administrative","postcode","postal_code"}
_postal = re.compile(r"(?<!\w)(?:[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}|\d{4}\s?[A-Z]{2}|\d{4,6}(?:-\d{3,4})?|\d{3}\s\d{2})(?!\w)",re.I)


def location_key(value):
    normalized = unicodedata.normalize("NFKD",str(value).casefold())
    return "".join(char for char in normalized if char.isalnum())


def name_keys(value):
    value = str(value).casefold()
    return {location_key(value),location_key(value.replace("ä","ae").replace("ö","oe").replace("ü","ue"))}


def resolution_scope(function):
    @wraps(function)
    def run(*args,**kwargs):
        if _scope.get() is not None:
            return function(*args,**kwargs)
        token = _scope.set({"results":{}, "locks":{}, "guard":Lock(), "down":set()})
        try:
            return function(*args,**kwargs)
        finally:
            _scope.reset(token)
    return run


def mapped_with_scope(pool, function, items):
    return pool.map(lambda item: copy_for_item(function,item), ((copy_context(), item) for item in items))


def copy_for_item(function, context_item):
    context,item = context_item
    return context.run(function,item)


def cached_result(key):
    now = time()
    with _cache_lock:
        item = _cache.get(key)
        if item and item[0] > now:
            return item[1]
    path = os.getenv("TRINITY_GEOCODE_CACHE")
    if path:
        try:
            with sqlite3.connect(path,timeout=.5) as db:
                db.execute("CREATE TABLE IF NOT EXISTS geocodes (key TEXT PRIMARY KEY, expires REAL, lat REAL, lon REAL, source TEXT, precision TEXT)")
                item = db.execute("SELECT lat,lon,source,precision FROM geocodes WHERE key=? AND expires>?", (key,now)).fetchone()
                if item:
                    return ((item[0],item[1]),item[2],item[3])
        except sqlite3.Error:
            pass
    return None


def store_result(key,result):
    expires = time() + 7*86400
    with _cache_lock:
        if len(_cache) >= 512:
            _cache.pop(next(iter(_cache)))
        _cache[key] = expires,result
    path = os.getenv("TRINITY_GEOCODE_CACHE")
    if path:
        try:
            with sqlite3.connect(path,timeout=.5) as db:
                db.execute("DELETE FROM geocodes WHERE expires<=?",(time(),))
                db.execute("INSERT OR REPLACE INTO geocodes VALUES (?,?,?,?,?,?)",(key,expires,*result[0],result[1],result[2]))
        except sqlite3.Error:
            pass


def request_candidates(base, query):
    global _public_next
    photon = base.rstrip("/").endswith("/api")
    endpoint = base.rstrip("/") + ("/" if photon else "/search")
    params = {"q":query,"limit":6}
    if not photon:
        params.update(format="jsonv2",addressdetails=1)
    def get():
        return httpx.get(endpoint,params=params,timeout=httpx.Timeout(6.0,connect=2.5),
                         headers={"User-Agent":"Ellis-Purchasing-Assistant/1.0 (local interactive procurement)"})
    if urlsplit(base).hostname == "nominatim.openstreetmap.org":
        with _public_gate:
            sleep(max(0,_public_next-monotonic()))
            _public_next = monotonic()+1.05
            response = get()
    else:
        response = get()
    response.raise_for_status()
    payload = response.json()
    rows = []
    for item in payload["features"] if photon else payload:
        if photon:
            props = item["properties"]
            lon,lat = item["geometry"]["coordinates"]
            street,house = props.get("street",""),props.get("housenumber","")
            kind = props.get("type","")
            if not street and not house and props.get("osm_key") not in {"place","boundary"}:
                continue
        else:
            props = item.get("address",{}) | {"name":item.get("name","")}
            props["countrycode"] = props.get("country_code","")
            lat,lon = item["lat"],item["lon"]
            street,house = props.get("road",props.get("pedestrian","")),props.get("house_number","")
            kind = item.get("addresstype",item.get("type",""))
        lat,lon = float(lat),float(lon)
        if not (-90<=lat<=90 and -180<=lon<=180):
            continue
        names = [props.get("name","")]
        namedetails = item.get("namedetails") or {}
        if isinstance(namedetails,dict):
            names.extend(str(name) for field,name in namedetails.items() if field.startswith(("name:","official_name:")))
        if kind in {"postcode","postal_code"} or (not street and not house):
            names.extend(props.get(field,"") for field in ("city","town","village","municipality","hamlet"))
        rows.append({"point":(lat,lon),"properties":props,"names":names,"street":street,"house":house,"kind":kind})
    return rows,str(response.url)


def input_forms(query):
    """Keep a postal or regional hint when falling back to an approximate place."""
    postal = _postal.search(query)
    forms = [query]
    parts = [part.strip() for part in query.split(",") if part.strip()]
    if len(parts)>1 and re.search(r"\d",parts[0]) and re.search(r"[^\W\d_]",parts[0]):
        # Comma-delimited addresses can put the postal code before or after the city.
        if not postal or _postal.search(parts[0]) is None:
            locality = ", ".join(parts[1:])
            forms.extend((locality,_postal.sub("",locality).strip(" ,")))
    if postal:
        tail = query[postal.end():].strip(" ,")
        before = query[:postal.start()].strip(" ,")
        if tail:
            if re.fullmatch(r"[\wÄÖÜäöüß .'-]+\s+\d{1,4}[a-z]?", before,re.I):
                forms.insert(1, before + ", " + tail)
            forms.append(postal[0]+" "+tail)
        elif before and "," in before:
            forms.append(before.rsplit(",",1)[1].strip()+" "+postal[0])
        before_locality = before.rsplit(",",1)[-1].strip()
        if "," in before and before_locality and not re.search(r"\d",before_locality):
            forms.extend([", ".join(part for part in (before_locality+" "+postal[0],tail) if part),
                          ", ".join(part for part in (before_locality,tail) if part)])
        elif tail and not re.search(r"\d",tail.split(",")[0]):
            locality, *context = tail.split(",", 1)
            if "-" in locality:
                parent = locality.split("-", 1)[0].strip()
                forms.append(", ".join([postal[0] + " " + parent, *context]))
            forms.append(tail)
        elif before and not re.search(r"\d",before):
            forms.append(before)
    else:
        if len(parts)>1 and re.search(r"\d",parts[0]):
            forms.append(", ".join(parts[1:]))
        elif len(parts)==1:
            street = re.match(r"^.+?\s+\d{1,4}[a-z]?(?:/\d+)?\s+([^\d].+)$",query,re.I)
            if street:
                forms.append(street[1])
    if "-" in query and not postal and not re.search(r"\d",query):
        city,*context = query.split(",",1)
        forms.append(", ".join([city.split("-",1)[0].strip(),*context]))
    return list(dict.fromkeys(forms))[:4]


def select_location(rows, query):
    postcode = _postal.search(query)
    body = _postal.sub(" ",query).strip(" ,")
    matches = []
    for item in rows:
        props = item["properties"]
        reduced = body
        region_code = str(props.get("ISO3166-2-lvl4","")).split("-")[-1]
        country_code = str(props.get("countrycode","")).casefold()
        country_aliases = {"de":("Germany","Deutschland"),"at":("Austria","Österreich"),
                           "ch":("Switzerland","Schweiz","Suisse","Svizzera"),
                           "fr":("France","Frankreich"),"gb":("United Kingdom","UK","Vereinigtes Königreich"),
                           "nl":("Netherlands","Niederlande","Nederland"),"be":("Belgium","Belgien","België","Belgique"),
                           "pl":("Poland","Polen","Polska"),"cz":("Czechia","Tschechien","Tschechische Republik","Česko"),"us":("USA","United States")}
        suffixes = [str(props.get(field,"")) for field in ("country","countrycode","state","county","region")]
        suffixes += [region_code,*country_aliases.get(country_code,())]
        for _ in range(3):
            before = reduced
            for part in sorted(filter(None,suffixes),key=len,reverse=True):
                if name_keys(item["names"][0]) & name_keys(reduced):
                    break
                reduced = re.sub(r"(?<!\w)"+re.escape(part)+r"$", "",reduced,flags=re.I).strip(" ,")
            if before == reduced:
                break
        if postcode:
            postal_values = str(props.get("postcode",""))
            candidates = {location_key(part) for part in re.split(r"[;,/]",postal_values)}
            if postal_values and location_key(postcode[0]) not in candidates:
                continue
        if item["street"] and item["house"]:
            if not any(key in location_key(query) for key in name_keys(item["street"]) if key):
                continue
            housenumbers = re.split(r"\s*[+;]\s*",item["house"])
            if not any(re.search(r"(?<![\w/])"+re.escape(number)+r"(?![\w/])",_postal.sub(" ",query),re.I) for number in housenumbers):
                continue
            locality = [props.get(key,"") for key in ("city","town","village","municipality")]
            aliases = [re.sub(r"\s*\([^()]+\)$","",name).strip() for name in locality if name]
            if aliases and not any(location_key(name) in location_key(query) for name in aliases if name):
                continue
            matches.append((item,"address"))
        elif item["kind"] in _local_types and any(name and name_keys(name) & name_keys(reduced) for name in item["names"]):
            # A borough's parent city is a filter, not another place with that name.
            if not postcode and item["kind"] in {"district","suburb","neighbourhood","quarter","city_district"}:
                if not name_keys(item["names"][0]) & name_keys(reduced):
                    continue
            matches.append((item,"postal" if postcode and props.get("postcode") else "city"))
    if not matches:
        return None,False
    if any(precision == "address" for _,precision in matches):
        matches = [(item,precision) for item,precision in matches if precision == "address"]
    elif postcode and any(precision == "postal" for _,precision in matches):
        matches = [(item,precision) for item,precision in matches if precision == "postal"]
    default = os.getenv("TRINITY_DEFAULT_COUNTRY","DE").casefold()
    countries = {str(item["properties"].get("countrycode","")).casefold() for item,_ in matches}
    if default and len(countries- {""})>1 and default in countries:
        matches = [(item,precision) for item,precision in matches if str(item["properties"].get("countrycode","")).casefold()==default]
    first,precision = matches[0]
    radius = .35 if precision=="address" else 12
    def nearby(item):
        lat,lon = first["point"]
        a,b = item["point"]
        return math.hypot((lat-a)*111.2,(lon-b)*111.2*math.cos(math.radians(lat))) <= radius
    def region(item):
        p = item["properties"]
        return tuple(location_key(p.get(key,"")) for key in ("countrycode","state","county"))
    first_region = region(first)
    if any(not nearby(item) or any(a and b and a!=b for a,b in zip(first_region,region(item))) for item,_ in matches):
        return None,True
    # Prefer a postcode point for a postcode, and a locality centre for city-only input.
    preferred = next((item for item,_ in matches if item["kind"] in
                     ({"postcode","postal_code"} if precision=="postal" else {"city","town","village"})),first)
    return (preferred["point"],precision),False


def resolve(primary, query):
    query = " ".join(query.split()).strip(" ,")
    query = re.sub(r"(?<!\w)(?:D|DE|A|AT|CH|CZ)-(?=\d{4,5}\b)","",query,flags=re.I)
    fallback = os.getenv("TRINITY_GEOCODER_FALLBACK_URL","").strip()
    providers = list(dict.fromkeys(provider for provider in (primary,fallback)
                                  if provider.startswith(("https://","http://"))))
    key = "|".join(["v3",*providers,os.getenv("TRINITY_DEFAULT_COUNTRY","DE"),query.casefold()])
    run = _scope.get()
    if run is None:
        return perform_resolution(providers,query,key,None)
    with run["guard"]:
        lock = run["locks"].setdefault(key,Lock())
    with lock:
        if key not in run["results"]:
            try:
                run["results"][key] = perform_resolution(providers,query,key,run)
            except GeocodingError as error:
                run["results"][key] = error
        result = run["results"][key]
        if isinstance(result,GeocodingError):
            raise GeocodingError(result.kind,str(result))
        return result


def perform_resolution(providers,query,key,run):
    cached = cached_result(key)
    if cached:
        return cached
    failures,answered = [],False
    deadline = monotonic()+16
    forms = input_forms(query)
    lookups = [(form,form) for form in forms]
    # Some providers rank administrative areas above a city's own record when
    # given a qualifier. Retry the shorter search and still verify full context.
    lookups.extend((form.split(",",1)[0].strip(),form) for form in forms if "," in form)
    ambiguous_result = False
    for lookup,form in dict.fromkeys(lookups):
        for provider in providers:
            if monotonic() >= deadline:
                raise GeocodingError("service","Zeitbudget der Geokodierung erreicht.")
            if run and provider in run["down"]:
                failures.append(urlsplit(provider).hostname)
                continue
            try:
                rows,source = request_candidates(provider,lookup)
            except (httpx.HTTPError,KeyError,TypeError,ValueError,IndexError) as error:
                failures.append(urlsplit(provider).hostname)
                if run and (isinstance(error,(httpx.ConnectError,httpx.ConnectTimeout))
                            or isinstance(error,httpx.HTTPStatusError) and error.response.status_code in {403,429,503}):
                    with run["guard"]:
                        run["down"].add(provider)
                continue
            answered = True
            match,ambiguous = select_location(rows,form)
            if ambiguous:
                ambiguous_result = True
            if match:
                point,precision = match
                result = point,source,precision
                store_result(key,result)
                return result
    if ambiguous_result:
        raise GeocodingError("ambiguous","Mehrere Orte passen. Land, Region oder PLZ ergänzen.")
    if failures:
        hosts = ", ".join(dict.fromkeys(host for host in failures if host))
        raise GeocodingError("service",f"Geodienst derzeit nicht erreichbar oder fehlerhaft ({hosts})."+(" Ein anderer Dienst lieferte keinen verifizierten Treffer." if answered else ""))
    return None
