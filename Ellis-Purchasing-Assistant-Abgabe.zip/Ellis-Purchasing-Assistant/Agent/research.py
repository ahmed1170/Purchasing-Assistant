from run_metrics import timed, measured_run
"""Bounded PDF text extraction and public supplier research."""
import http.client
import io
import ipaddress
import json
import math
import os
import re
import shutil
import socket
import ssl
from base64 import urlsafe_b64decode
from concurrent.futures import ThreadPoolExecutor, wait
from functools import lru_cache
from threading import Lock
from time import monotonic, sleep
import unicodedata
from datetime import datetime, timezone
from collections import OrderedDict
from copy import deepcopy
from shop_evidence import linked_data, organization_lines, shop_records, store_name
from urllib.parse import parse_qs, quote, urlencode, urldefrag, urljoin, urlsplit, urlunsplit

import httpx
from geocoding import GeocodingError, location_key, resolve
from bs4 import BeautifulSoup
from pypdf import PdfReader

MAX_PDF_BYTES = 8 * 1024 * 1024
PAGE_CHARS = 9000
WEB_BYTES = 3 * 1024 * 1024
WEB_TIMEOUT = 3
WEB_WORKERS = ThreadPoolExecutor(max_workers=12, thread_name_prefix="supplier-web")
WEB_CACHE = OrderedDict()
WEB_CACHE_LOCK = Lock()
WEB_CACHE_SECONDS = 120
OSRM_LOCK = Lock()
OSRM_NEXT_REQUEST = 0.0
DEFAULT_GEOCODER = "https://photon.komoot.io/api"
DEFAULT_ROUTER = "https://router.project-osrm.org"


class PDFError(ValueError):
    pass


def inspect_pdf(data):
    if len(data) > MAX_PDF_BYTES:
        raise PDFError("Dateigröße überschritten (maximal 8 MiB).")
    if b"%PDF-" not in data[:1024]:
        raise PDFError("Datei hat keinen gültigen PDF-Header.")
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted and not reader.decrypt(""):
            raise PDFError("Passwort erforderlich.")
        count = len(reader.pages)
    except PDFError:
        raise
    except Exception as exc:
        raise PDFError("Datei beschädigt oder PDF-Struktur nicht unterstützt.") from exc

    pages, scans, failed = [], [], []
    for idx in range(count):
        try:
            page = reader.pages[idx]
            raw = page.extract_text(extraction_mode="layout") or page.extract_text() or ""
            # Keep lines and mark separated table cells explicitly.
            lines = [re.sub(r"[ \t]{2,}", " | ", line.strip()) for line in raw.splitlines() if line.strip()]
            if re.search(r"EUR\s*/|preis|netto|mwst", raw, re.I):
                # Price-list terms can be printed vertically outside the table.
                try:
                    margin = page.extract_text((90, 180, 270)) or ""
                except Exception:
                    margin = ""  # Preserve a readable table when its margin cannot be extracted.
                for note in margin.splitlines():
                    note = " ".join(note.split())
                    if 0 < len(note) <= 1000 and re.search(r"preis|mwst|netto|brutto|VAT",note,re.I):
                        lines.append(note)
            body = "\n".join(lines)
        except Exception:
            failed.append(idx + 1)
            continue
        if not body:
            scans.append(idx + 1)
            continue
        author = (reader.metadata.author or "").strip() if idx == 0 and reader.metadata else ""
        if author and re.fullmatch(r"[\w .&-]{2,100}", author):
            body = "PDF-Metadaten · Autor: " + author + "\n" + body
        annotations = page.get("/Annots")
        if annotations is not None:
            links = []
            try:
                for reference in annotations.get_object()[:40]:
                    annotation = reference.get_object()
                    action = annotation.get("/A")
                    if annotation.get("/Subtype") != "/Link" or action is None:
                        continue
                    action = action.get_object()
                    uri = action.get("/URI")
                    if action.get("/S") == "/URI" and isinstance(uri, str) and re.fullmatch(r"https?://[^\s<>]{1,1000}", uri):
                        links.append("PDF-Link: " + uri)
            except (AttributeError, IndexError, TypeError, ValueError):
                pass
            if links:
                body += "\n" + "\n".join(dict.fromkeys(links))
        pages.append((idx + 1, body))
    warnings = []
    if scans:
        ocr = "OCR lokal verfügbar" if shutil.which("tesseract") and shutil.which("pdftoppm") else "keine lokale OCR gefunden"
        warnings.append(f"Scan ohne Textschicht – OCR nötig auf PDF-Seiten {', '.join(map(str, scans))} ({ocr}).")
    if failed:
        warnings.append(f"Textextraktion fehlgeschlagen auf PDF-Seiten {', '.join(map(str, failed))}.")
    if not count:
        warnings.append("PDF enthält keine Seiten.")
    return pages, count, warnings


def pdf_pages(data):
    pages, _, warnings = inspect_pdf(data)
    return [(page, body[:PAGE_CHARS]) for page, body in pages], warnings


def public_target(url):
    parts = urlsplit(url)
    port = parts.port or {"https": 443, "http": 80}.get(parts.scheme)
    if parts.scheme not in {"https", "http"} or not parts.hostname or parts.username or parts.password:
        raise ValueError("Nur öffentliche HTTP(S)-Quellen sind zulässig.")
    if port != {"https": 443, "http": 80}[parts.scheme]:
        raise ValueError("Webquelle verwendet keinen Standardport.")
    addresses = socket.getaddrinfo(parts.hostname, port, type=socket.SOCK_STREAM)
    ips = [ipaddress.ip_address(record[4][0]) for record in addresses]
    if not ips or any(not ip.is_global or ip.is_multicast or ip.is_reserved for ip in ips):
        raise ValueError("Webquelle löst auf eine nicht öffentliche Adresse auf.")
    return parts, port, list(dict.fromkeys(record[4][0] for record in addresses))


@lru_cache(maxsize=1)
def tls_context():
    if os.name == "nt":
        import truststore

        return truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    return ssl.create_default_context()


def get_page(url):
    """Connect to the validated address, preserving Host and TLS hostname checks."""
    for _ in range(4):
        parts, port, addresses = public_target(url)
        conn = http.client.HTTPConnection(parts.hostname, port, timeout=WEB_TIMEOUT)
        try:
            for address in addresses[:3]:
                try:
                    conn.sock = socket.create_connection((address, port), timeout=WEB_TIMEOUT)
                    break
                except OSError:
                    continue
            if conn.sock is None:
                raise OSError("Verbindung zur Webquelle fehlgeschlagen.")
            if parts.scheme == "https":
                conn.sock = tls_context().wrap_socket(conn.sock, server_hostname=parts.hostname)
            path = parts.path or "/"
            if parts.query:
                path += "?" + parts.query
            conn.request("GET", path, headers={"Host": parts.netloc, "User-Agent": "Purchasing-Assistant",
                                                "Accept": "text/html, application/pdf"})
            response = conn.getresponse()
            if response.status in {301, 302, 303, 307, 308} and response.getheader("Location"):
                url = urljoin(url, response.getheader("Location"))
                continue
            if response.status != 200:
                raise OSError(f"HTTP {response.status}")
            data = response.read(WEB_BYTES + 1)
            if len(data) > WEB_BYTES:
                raise ValueError("Webquelle überschreitet das Größenlimit.")
            return url, response.getheader("Content-Type", "").lower(), data
        finally:
            conn.close()
    raise ValueError("Zu viele Weiterleitungen.")


def shop_article_pages(item):
    """Follow a shop's public article-search form, then verify the detail pages."""
    host, article = item
    homepage, notes = fetch("https://" + host.casefold() + "/")
    form = next((page["shop_search_form"] for page in homepage if page.get("shop_search_form")), None)
    if not form:
        return [], notes
    action, name = form
    parts = urlsplit(action)
    query = urlencode(parse_qs(parts.query) | {name: [article]}, doseq=True)
    search_url = urlunsplit((parts.scheme, parts.netloc, parts.path, query, ""))
    results, errors = fetch(search_url)
    notes = notes + errors
    output = []
    links = list(dict.fromkeys(link for page in results for link in page.get("shop_search_links", ())))
    for url in links[:4]:
        pages, errors = fetch(url)
        notes.extend(errors)
        output.extend(page for page in pages if any(
            article.casefold() in record.get("identifiers", ())
            or re.search(r"(?<!\w)" + re.escape(article) + r"(?!\w)", record["name"], re.I)
            for record in page.get("shop_products", ())))
        if output:
            break
    return output, notes


def fetch(url):
    # Use the original retrieval timestamp when a public source is reused.
    with WEB_CACHE_LOCK:
        cached = WEB_CACHE.get(url)
        if cached and monotonic() - cached[0] < WEB_CACHE_SECONDS:
            WEB_CACHE.move_to_end(url)
            return deepcopy(cached[1])
    result = fetch_uncached(url)
    if result[0]:
        with WEB_CACHE_LOCK:
            WEB_CACHE[url] = (monotonic(),deepcopy(result))
            WEB_CACHE.move_to_end(url)
            while len(WEB_CACHE) > 64:
                WEB_CACHE.popitem(last=False)
    return result


def fetch_uncached(url):
    started = monotonic()
    retrieved_at = datetime.now(timezone.utc).isoformat()
    try:
        try:
            final_url, kind, data = get_page(url)
        except (TimeoutError, ConnectionResetError):
            final_url, kind, data = get_page(url)
        if "application/pdf" in kind or data.startswith(b"%PDF-"):
            pages, warnings = pdf_pages(data)
            entries = [{"kind": "web_pdf", "title": "PDF im Web", "url": final_url, "page": page, "text": text}
                       for page, text in pages[:6]]
            if len(pages) > 6:
                warnings.append("Web-PDF auf sechs Textseiten begrenzt.")
            return entries, [f"{final_url} · {warning}" for warning in warnings]
        if "text/html" not in kind and "text/plain" not in kind and "xhtml" not in kind:
            raise ValueError("Quellformat nicht unterstützt.")
        charset = re.search(r"charset\s*=\s*[\"']?([\w.-]+)", kind)
        soup = BeautifulSoup(data, "html.parser", from_encoding=charset[1] if charset else None)
        title = soup.title.get_text(" ", strip=True) if soup.title else parts_title(final_url)
        heading = soup.select_one('h1')
        shop_search_form = None
        for form in soup.find_all("form", action=True):
            action = urljoin(final_url, form["action"])
            field = form.select_one('input[type="search"][name], input[name="keywords"], input[name="q"]')
            if (field and form.get("method", "get").casefold() == "get"
                    and urlsplit(action).netloc == urlsplit(final_url).netloc
                    and re.search(r"search|suche", urlsplit(action).path, re.I)):
                shop_search_form = (action, field["name"])
                break
        shop_search_links = []
        if shop_search_form and urlsplit(final_url).path == urlsplit(shop_search_form[0]).path:
            for anchor in soup.select("main h2 a[href], main h3 a[href]")[:8]:
                link = urldefrag(urljoin(final_url, anchor["href"])).url
                if urlsplit(link).netloc == urlsplit(final_url).netloc and urlsplit(link).path != urlsplit(final_url).path:
                    shop_search_links.append(link)
        shop_search = None
        if (urlsplit(final_url).hostname in {'www.hornbach.de','hornbach.de'}
                and urlsplit(final_url).path.startswith('/p/') and heading and soup.select_one('form[action="/s/"]')):
            name = re.sub(r'\s+', ' ', heading.get_text(' ',strip=True))[:120]
            dimension = re.search(r'\d+(?:[,.]\d+)?\s*[x×]\s*\d+(?:[,.]\d+)?',name,re.I)
            if dimension:
                name = name.split()[0] + ' ' + re.sub(r'\s+','',dimension[0]).replace('×','x')
            if name:
                shop_search = urljoin(final_url,'/s/'+quote(name,safe=''))
        records = shop_records(soup,final_url)
        cards = [record for record in records if record['kind']=='Shop-Produktkarte']
        detail_records = [record for record in records if record not in cards]
        structured = ([record['quote'] for record in detail_records] + organization_lines(soup,final_url)
                      + ([] if detail_records else product_lines(soup, final_url)) + component_lines(soup))
        contact_links = []
        corporate_hosts = []
        finder_links = []
        product_links = []
        for link in soup.find_all("a", href=True):
            target = urldefrag(urljoin(final_url,link["href"])).url
            site_host = urlsplit(final_url).hostname.removeprefix("www.")
            link_host = (urlsplit(target).hostname or "").removeprefix("www.")
            if (link_host != site_host and link_host.split(".")[0] == site_host.split(".")[0]
                    and urlsplit(target).scheme in {"http","https"}
                    and re.search(r"unternehmen|corporate|karriere|career|presse|press|impressum|company",
                                  link.get_text(" ",strip=True),re.I)):
                corporate_hosts.append(link_host)
            if (urlsplit(target).hostname == urlsplit(final_url).hostname
                    and re.search(r"marktfinder|filialfinder|standortsuche|unsere filialen|store locator|find a store|our stores|our branches|our locations",link.get_text(" ",strip=True),re.I)):
                finder_links.append("Standortfinder: " + target)
            if (urlsplit(target).hostname == urlsplit(final_url).hostname and target.startswith(("http://","https://"))
                    and re.search(r"/(?:p|product|products|produkt)/[^?#]+",urlsplit(target).path)
                    and target != final_url):
                product_links.append("Produktquelle: "+target)
            if re.search(r"impressum|imprint|legal notice|kontakt|contact", link.get_text(" ", strip=True), re.I):
                target = urljoin(final_url, link["href"])
                if urlsplit(target).hostname == urlsplit(final_url).hostname and target.startswith(("http://", "https://")):
                    contact_links.append("Kontaktquelle: " + target)
        for tag in soup(["script", "style", "noscript", "svg", "nav", "footer", "header"]):
            tag.decompose()
        content = " ".join((soup.body or soup).stripped_strings)
        main = soup.select_one("main #content, main, [role=main], #content")
        if main and re.search(r"/(?:impressum|imprint|legal-notice|kontakt|contact)(?=[/.:_-]|$)", urlsplit(final_url).path, re.I):
            main_text = " ".join(main.stripped_strings)
            if main_text and len(main_text) < 9000:
                content = main_text + "\n" + content
        content = re.sub(r"\s+", " ", f"{title} {content}").strip()
        if structured:
            content = "\n".join(structured) + "\n\n" + content
        if contact_links:
            content = "\n".join(list(dict.fromkeys(contact_links))[:4]) + "\n" + content
        if finder_links:
            content = "\n".join(list(dict.fromkeys(finder_links))[:2]) + "\n" + content
        if product_links:
            content = "\n".join(list(dict.fromkeys(product_links))[:4]) + "\n" + content
        if len(content) < 40:
            raise ValueError("Kein nutzbarer Seitentext.")
        notes = [f"{final_url} · Webseitentext auf 14.000 Zeichen begrenzt."] if len(content) > 14000 else []
        card_sources = [{"kind":"web","title":record['name'],"url":final_url,"product_url":record['product_url'],
                         "retrieved_at":retrieved_at,"shop_products":[record],
                         "text":record['quote']+'\nOriginalkarte: '+record['raw']} for record in cards]
        return [{"kind": "web", "title": title[:250], "url": final_url, "text": content[:14000],
                 "retrieved_at":retrieved_at,"fetch_seconds":round(monotonic()-started,3),
                 "shop_products":[r for r in detail_records if r['quote'] in content[:14000]],
                 "corporate_hosts":list(dict.fromkeys(corporate_hosts))[:3],
                 **({"shop_search_form": shop_search_form, "shop_search_links": shop_search_links} if shop_search_form else {}),
                 "shop_listing":bool(cards), **({"shop_search":shop_search} if shop_search else {})}] + card_sources, notes
    except (OSError, ValueError, http.client.HTTPException, UnicodeError, RuntimeError) as exc:
        return [], [f"{url} · Abruf fehlgeschlagen: {type(exc).__name__}: {str(exc)[:180]}"]
    except Exception:
        # PDF parsers may raise several format-specific exceptions for malformed pages.
        return [], [f"{url} · Quelle konnte nicht ausgewertet werden."]


def product_lines(soup, url):
    """Keep each JSON-LD Offer attached to its Product instead of flattening variants."""
    heading = soup.select_one("h1")
    default_seller = store_name(soup, url, list(linked_data(soup)), heading.get_text(" ", strip=True) if heading else "")
    pending = []
    for script in soup.find_all("script", type="application/ld+json", limit=30):
        try:
            pending.append(json.loads(script.get_text()))
        except (ValueError, RecursionError):
            continue
    lines = []
    while pending and len(lines) < 24:
        node = pending.pop()
        if isinstance(node, list):
            pending.extend(node)
            continue
        if not isinstance(node, dict):
            continue
        pending.extend(node[key] for key in ("@graph", "hasVariant", "mainEntity") if key in node)
        kinds = node.get("@type", [])
        if "Product" not in ([kinds] if isinstance(kinds, str) else kinds or []) or not isinstance(node.get("name"), str):
            continue
        offers = node.get("offers", [])
        for offer in offers if isinstance(offers, list) else [offers]:
            if not isinstance(offer, dict) or offer.get("@type") != "Offer" or not offer.get("priceCurrency"):
                continue
            item = offer.get("itemOffered")
            if isinstance(item, dict) and any(item.get(key) and item.get(key) != node.get(key) for key in ("sku", "name")):
                continue
            price = str(offer.get("price", ""))
            spec = offer.get("priceSpecification")
            if offer.get("minPrice") or isinstance(spec, dict) and spec.get("minPrice"):
                continue
            if not re.fullmatch(r"\d{1,12}(?:[.,]\d{1,4})?", price):
                continue
            seller = offer.get("seller")
            seller = (seller.get("name") if isinstance(seller, dict) else None) or default_seller
            parts = [f"Anbieter: {seller}", f"Produkt: {node['name']}"]
            if node.get("sku"):
                parts.append(f"SKU: {node['sku']}")
            parts.append(f"Preis der Variante: {price} {offer['priceCurrency']}")
            if isinstance(spec, dict) and type(spec.get("valueAddedTaxIncluded")) is bool:
                parts.append("Steuerstatus: inkl. MwSt." if spec["valueAddedTaxIncluded"] else "Steuerstatus: netto")
            # eligibleQuantity describes order eligibility, not the contents of a pack.
            lines.append("JSON-LD · " + " · ".join(re.sub(r"\s+", " ", part)[:155] for part in parts))
    return list(dict.fromkeys(lines))


def component_lines(soup):
    """Read server-rendered CMS text carried in web-component attributes."""
    sections = []
    for tag in soup.find_all(attrs={"content": True}):
        content = tag.get("content", "")
        if "-" not in tag.name or "<" not in content or len(content) > 200000:
            continue
        fragment = BeautifulSoup(content, "html.parser")
        for hidden in fragment(["script", "style"]):
            hidden.decompose()
        text = " ".join(fragment.stripped_strings)
        if text:
            sections.append(text)
    return list(dict.fromkeys(sections))[:24]


def parts_title(url):
    return urlsplit(url).hostname or url


def geocode(base, location):
    result = resolve(base, location)
    return result[:2] if result else None


def route_distance(origin, destination, origin_coordinates=None):
    """Use explicitly configured geocoding and OSRM services."""
    geocoder = os.getenv("TRINITY_GEOCODER_URL", DEFAULT_GEOCODER)
    router = os.getenv("TRINITY_ROUTER_URL", DEFAULT_ROUTER)
    if not all(url.startswith(("http://", "https://")) for url in (geocoder, router)):
        return None
    try:
        with httpx.Client(timeout=5, follow_redirects=False, headers={"User-Agent": "Ellis-Purchasing-Assistant"}) as client:
            target = resolve(geocoder, destination)
            if not target:
                return None
            origin_result = origin_coordinates or geocode(geocoder, origin)
            if not origin_result:
                return None
            locations = [origin_result, target[:2]]
            coordinates = [f"{lon:.6f},{lat:.6f}" for (lat, lon), _ in locations]
            url = router.rstrip("/") + "/route/v1/driving/" + ";".join(coordinates) + "?overview=false"
            response = get_route(client, url)
            response.raise_for_status()
            data = response.json()
            meters = float(data["routes"][0]["distance"])
            if data.get("code") == "Ok" and math.isfinite(meters) and meters >= 0:
                return url, f"{meters / 1000:.2f}", ("; ".join(coordinates) + ". Geokodierung: "
                                                     + " → ".join(source for _, source in locations)
                                                     + f". Zielauflösung: {target[2]}")
    except (GeocodingError, httpx.HTTPError, KeyError, IndexError, ValueError, TypeError):
        return None


def get_route(client, url):
    global OSRM_NEXT_REQUEST
    if urlsplit(url).hostname not in {"router.project-osrm.org", "routing.openstreetmap.de"}:
        return client.get(url)
    with OSRM_LOCK:
        sleep(max(0, OSRM_NEXT_REQUEST - monotonic()))
        OSRM_NEXT_REQUEST = monotonic() + 1
        return client.get(url)


def air_distance(origin, destination, origin_coords="", destination_coords=""):
    geocoder = os.getenv("TRINITY_GEOCODER_URL", DEFAULT_GEOCODER)
    def locate(value, raw):
        match = re.fullmatch(r"\s*(-?\d{1,2}\.\d+)\s*,\s*(-?\d{1,3}\.\d+)\s*", raw)
        if match:
            lat, lon = map(float, match.groups())
            if -90 <= lat <= 90 and -180 <= lon <= 180:
                return (lat, lon), None
        return geocode(geocoder, value) if geocoder.startswith(("https://", "http://")) else None
    try:
        target = resolve(geocoder,destination) if not destination_coords else None
        b = target[:2] if target else locate(destination, destination_coords) if destination_coords else None
        a = locate(origin, origin_coords) if b else None
        if not a or not b:
            return None
        lat, lon = map(math.radians, a[0])
        end_lat, end_lon = map(math.radians, b[0])
        h = math.sin((end_lat-lat)/2)**2 + math.cos(lat)*math.cos(end_lat)*math.sin((end_lon-lon)/2)**2
        km = 6371.0088 * 2 * math.asin(math.sqrt(min(1, max(0, h))))
        precision = f". Zielauflösung: {target[2]}" if target else ""
        return km, f"{a[0]} → {b[0]}{precision}", next((url for _,url in (a,b) if url), None)
    except (GeocodingError, httpx.HTTPError, KeyError, ValueError, TypeError):
        return None


def search_one(query, limit):
    site = re.search(r"\bsite:([\w.-]+)",query,re.I)
    terms = set(re.findall(r"[\w]{4,}", query.casefold())) - {
        "kaufen", "preis", "rolle", "anbieter", "lieferant", "online", "artikel", "shop",
        "impressum", "adresse", "standort", "filiale", "nähe", "nach", "lieferzeit", "versandkosten",
    }
    engines = (
        ("https://lite.duckduckgo.com/lite/", {"q": query, "kl": "de-de"}, ".result-link"),
        ("https://www.bing.com/search", {"q": query, "setlang": "de-DE"}, "li.b_algo h2 a"),
    )
    for endpoint, params, selector in engines:
        try:
            response = httpx.get(endpoint, params=params, timeout=WEB_TIMEOUT, headers={"User-Agent": "Mozilla/5.0"})
            response.raise_for_status()
        except httpx.HTTPError:
            continue
        page = BeautifulSoup(response.content, "html.parser")
        hits = []
        for link in page.select(selector):
            url = urljoin(endpoint, link.get("href", ""))
            parts = urlsplit(url)
            args = parse_qs(parts.query)
            if parts.hostname in {"duckduckgo.com", "lite.duckduckgo.com"}:
                url = args.get("uddg", [""])[0]
                excerpt = link.find_parent("tr")
                excerpt = excerpt.find_next_sibling("tr") if excerpt else None
            else:
                excerpt = link.find_parent("li")
                excerpt = excerpt.select_one(".b_caption p") if excerpt else None
                if parts.hostname == "www.bing.com":
                    encoded = args.get("u", [""])[0]
                    if not encoded.startswith("a1"):
                        continue
                    try:
                        url = urlsafe_b64decode(encoded[2:] + "===").decode("utf-8")
                    except (ValueError, UnicodeError):
                        continue
            if url.startswith(("https://", "http://")) and url != endpoint:
                host = urlsplit(url).hostname or ""
                if site and host != site[1] and not host.endswith("." + site[1]):
                    continue
                summary = " ".join([url, link.get_text(" ", strip=True),
                                    excerpt.get_text(" ", strip=True) if excerpt else ""]).casefold()
                if terms and not any(term in summary for term in terms):
                    continue
                hits.append({"href": url, "title": link.get_text(" ", strip=True),
                             "body": excerpt.get_text(" ", strip=True) if excerpt else ""})
            if len(hits) == limit:
                break
        if hits:
            return hits, None
    return [], f'Websuche lieferte keine abrufbaren Treffer für „{query}“.'


def web_batch(items, action, budget, timeout_message):
    if not items:
        return []
    futures = [WEB_WORKERS.submit(action, item) for item in items]
    done, pending = wait(futures, timeout=budget)
    for future in pending:
        future.cancel()
    return [future.result() if future in done else ([], timeout_message(item))
            for item, future in zip(items, futures)]


@timed("web_search_fetch")
def discover(queries, seen, limit, exact_articles=()):
    entries, warnings, urls = [], [], []
    searches = web_batch(queries, lambda query: search_one(query, limit), 6,
                         lambda query: f"Zeitlimit der Websuche erreicht: {query}")
    for _, warning in searches:
        if warning:
            warnings.append(warning)
    for rank in range(limit):
        for hits, _ in searches:
            if len(hits) <= rank:
                continue
            hit = hits[rank]
            url = hit.get("href", "")
            if not url.startswith(("https://", "http://")) or len(url) > 1200 or url in seen:
                continue
            if exact_articles:
                summary = " ".join([url, str(hit.get("title", "")), str(hit.get("body", ""))])
                if not any(re.search(r"(?<!\w)" + re.escape(article) + r"(?!\w)", summary, re.I)
                           for article in exact_articles):
                    continue
            seen.add(url)
            urls.append(url)
            entries.append({
                "kind": "search", "title": str(hit.get("title", ""))[:250], "url": url,
                "text": str(hit.get("body", ""))[:600],
            })
    # A failing first group must not hide later concrete product results.
    downloads = web_batch(urls[:10], fetch, 6, lambda url: [f"{url} · Zeitlimit beim Quellenabruf erreicht."])
    products = []
    for found,_ in downloads:
        for page in found:
            links = re.findall(r"Produktquelle: (https?://\S+)",page["text"])
            for link in links[:1]:
                if link not in seen:
                    seen.add(link)
                    products.append(link)
    promoted = web_batch(products[:4],fetch,5,lambda url:[f"{url} · Zeitlimit der Produktseite erreicht."])
    for found,notes in promoted:
        entries.extend(found)
        warnings.extend(notes)
    for found, notes in downloads:
        entries.extend(found)
        warnings.extend(notes)
    # A shop search is a first-party fallback when the detail page has no
    # structured price. Only return the card linking to the original product.
    from shop_evidence import canonical
    fallback = {page['shop_search']:canonical(page['url']) for page in entries
                if page.get('shop_search') and not any(record.get('price') for record in page.get('shop_products',[]))}
    for search_url in list(fallback)[:2]:
        cards,notes = fetch(search_url)
        entries.extend(card for card in cards if card.get('product_url') and canonical(card['product_url'])==fallback[search_url])
        warnings.extend(notes)
    return entries, warnings
