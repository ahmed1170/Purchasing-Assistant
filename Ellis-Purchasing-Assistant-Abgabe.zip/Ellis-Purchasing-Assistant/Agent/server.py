"""Local FastAPI server and SQLite persistence for the Trinity purchasing agent."""
import json
import logging
import os
import re
import sqlite3
from functools import lru_cache
from threading import Lock
from time import monotonic
from hashlib import sha256
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Literal
from uuid import uuid4

import yaml
from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse
from jsonschema import Draft202012Validator
from pydantic import BaseModel, Field, ValidationError
from starlette.middleware.trustedhost import TrustedHostMiddleware

from harness import CODEX_STATUS, Harness, ModelError, codex_status
from purchasing import Weights
from research import MAX_PDF_BYTES, PDFError, inspect_pdf
from workflow import run_workflow

ROOT = Path(__file__).resolve().parent
MIGRATION = "memory/migrations/001-initial.sql"
CORE = ("manifest.json", "role.yaml", "AGENTS.md", "output.schema.json", "workflow.json", MIGRATION)
RUNTIME = ("server.py", "workflow.py", "purchasing.py", "practical_prices.py", "price_ranking.py", "catalog.py", "catalog_web.py", "research.py", "geocoding.py", "supplier_locations.py", "harness.py", "shop_evidence.py", "price_diagnostics.py", "run_metrics.py", "static/index.html")
INSPECTABLE = CORE + RUNTIME + ("requirements.txt", "start.ps1", "README.md", "test_agent.py", "test_price_distance.py", "live_test.py", ".gitignore")
LOG = logging.getLogger("uvicorn.error")
DEFAULT_CHAT_URL = "http://localhost:1234/v1"


def search_history(conn, search_id):
    return list(conn.execute("""
        SELECT s.id, s.need, r.report_json FROM sessions s JOIN reports r ON r.session_id=s.id
        LEFT JOIN search_turns t ON t.session_id=s.id
        WHERE s.id=? OR t.search_id=? ORDER BY COALESCE(t.turn, 0)
    """, (search_id, search_id)))


def attachment_id(path):
    return sha256(path.encode("utf-8")).hexdigest()


def removed_ids(conn, search_id):
    return {row[0] for row in conn.execute("SELECT attachment_id FROM removed_pdfs WHERE search_id=?", (search_id,))}


def report_attachments(report):
    if "attachments" in report:
        return report["attachments"]
    paths = {}
    for source in report["sources"]:
        if source["kind"] == "pdf":
            path = source["path"]
            paths.setdefault(path, {"id": attachment_id(path), "name": source["title"], "path": path,
                                    "status": "ready", "notes": [], "pages": None})
    return list(paths.values())


@lru_cache(maxsize=5)
def cached_pdf(data):
    return inspect_pdf(data)


def inspect_upload(upload):
    name = (upload.filename or "Dokument.pdf").replace("\\", "/").rsplit("/", 1)[-1][:180]
    entry = {"name": name, "status": "ready", "notes": [], "pages": None}
    data = upload.file.read(MAX_PDF_BYTES + 1)
    try:
        pages, count, notes = cached_pdf(data)
    except PDFError as exc:
        return entry | {"status": "error", "notes": [str(exc)]}, [], b""
    entry.update(pages=count, notes=notes)
    if not pages:
        entry.update(status="error", notes=notes or ["Keine lesbare Textschicht gefunden."])
    return entry, pages, data


@contextmanager
def database(path):
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        with conn:
            yield conn
    finally:
        conn.close()


def snapshot():
    entries = []
    for name in INSPECTABLE:
        path = (ROOT / name).resolve()
        if path.is_relative_to(ROOT) and path.is_file():
            entries.append({"name": name, "path": str(path), "content": path.read_text(encoding="utf-8-sig")})
    return entries


class Feedback(BaseModel):
    session_id: str = Field(pattern=r"^[a-f0-9]{32}$")
    rating: Literal[1, -1]
    note: str = Field(default="", max_length=2000)


def create_app(memory=None):
    memory = Path(memory or os.environ.get("TRINITY_MEMORY_DIR", ROOT / "memory")).resolve()
    db = memory / "agent_memory.sqlite3"
    run_states = {}
    progress_lock = Lock()

    def update_progress(run_id, stage):
        if not run_id:
            return
        now = monotonic()
        with progress_lock:
            started = run_states.get(run_id, (now, now, ""))[0]
            run_states[run_id] = (started, now, stage)
            for key, (_, last, _) in list(run_states.items()):
                if now - last > 1800:
                    del run_states[key]

    @asynccontextmanager
    async def lifespan(app):
        memory.mkdir(parents=True, exist_ok=True)
        app.state.files = snapshot()
        app.state.texts = {entry["name"]: entry["content"] for entry in app.state.files}
        config = app.state.texts
        app.state.manifest = json.loads(config["manifest.json"])
        app.state.default_weights = Weights.model_validate(json.loads(config["workflow.json"])["weights"]).model_dump()
        yaml.safe_load(config["role.yaml"])
        schema = json.loads(config["output.schema.json"])
        Draft202012Validator.check_schema(schema)
        app.state.validator = Draft202012Validator(schema)
        with database(db) as conn:
            conn.execute("PRAGMA journal_mode = WAL")
            conn.executescript(config[MIGRATION])
        LOG.info("Einkaufsagent bereit. Gedächtnis: %s", db)
        yield

    app = FastAPI(title="Purchasing Assistant", lifespan=lifespan)
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=["localhost", "127.0.0.1", "[::1]", "testserver"])

    @app.middleware("http")
    async def local_browser(request: Request, call_next):
        origin = request.headers.get("origin")
        expected_origin = f"{request.url.scheme}://{request.headers.get('host', '')}"
        if request.headers.get("sec-fetch-site") == "cross-site" or (origin and origin != expected_origin):
            return JSONResponse({"detail": "Die Anfrage muss von der lokalen Oberfläche stammen."}, status_code=403)
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Content-Security-Policy"] = "default-src 'none'; script-src 'unsafe-inline' https://unpkg.com/maplibre-gl@5.6.1/dist/maplibre-gl.js; style-src 'unsafe-inline' https://unpkg.com/maplibre-gl@5.6.1/dist/maplibre-gl.css; img-src https://tiles.openfreemap.org data: blob:; connect-src 'self' https://tiles.openfreemap.org; worker-src blob:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
        return response

    @app.get("/", include_in_schema=False)
    def index():
        return HTMLResponse(app.state.texts["static/index.html"])

    @app.get("/api/agent/status")
    def agent_status():
        status = codex_status()
        return {"manifest": app.state.manifest,
                "default_weights": app.state.default_weights,
                "codex_available": status != "missing",
                "codex_status": status, "codex_message": CODEX_STATUS[status]}

    @app.get("/api/agent/files")
    def files():
        return {**agent_status(), "files": app.state.files, "memory_path": str(db)}

    @app.post("/api/agent/pdf-check")
    def pdf_check(pdf: UploadFile):
        return inspect_upload(pdf)[0]

    @app.get("/api/agent/progress/{run_id}")
    def progress(run_id: str):
        with progress_lock:
            item = run_states.get(run_id)
        return {"stage": item[2], "elapsed_seconds": round(monotonic() - item[0], 1)} if item else {"stage": ""}

    @app.delete("/api/agent/searches/{search_id}/attachments/{file_id}")
    def remove_pdf(search_id: str, file_id: str):
        with database(db) as conn:
            history = search_history(conn, search_id)
            if not history or history[0]["id"] != search_id or not any(
                item["id"] == file_id for item in report_attachments(json.loads(history[-1]["report_json"]))
            ):
                raise HTTPException(404, "Anhang nicht gefunden.")
            conn.execute("INSERT OR IGNORE INTO removed_pdfs VALUES (?,?)", (search_id, file_id))
        return {"removed": True}

    @app.post("/api/agent/run")
    def run(
        need: Annotated[str, Form(min_length=1, max_length=16000)],
        harness: Annotated[Literal["codex", "chat"], Form()] = "codex",
        model: Annotated[str, Form(max_length=120)] = "",
        base_url: Annotated[str, Form(max_length=1000)] = DEFAULT_CHAT_URL,
        api_key: Annotated[str, Form(max_length=1000)] = "",
        web: Annotated[bool, Form()] = True,
        weights: Annotated[str | None, Form(max_length=500)] = None,
        search_id: Annotated[str | None, Form(pattern=r"^[a-f0-9]{32}$")] = None,
        run_id: Annotated[str | None, Form(pattern=r"^[a-f0-9]{32}$")] = None,
        pdfs: Annotated[list[UploadFile] | None, File()] = None,
    ):
        if not need.strip():
            raise HTTPException(422, "Bitte eine Nachricht eingeben.")
        if model and not re.fullmatch(r"[\w./:@+\-]+", model):
            raise HTTPException(422, "Ungültiger Modellname.")
        history = []
        removed = set()
        if search_id:
            with database(db) as conn:
                history = search_history(conn, search_id)
                removed = removed_ids(conn, search_id)
            if not history or history[0]["id"] != search_id:
                raise HTTPException(404, "Suche nicht gefunden.")
        previous = json.loads(history[-1]["report_json"]) if history else None
        try:
            selected_weights = (Weights.model_validate_json(weights).model_dump()
                                if weights is not None else previous["weights"] if previous and
                                set(previous["weights"]) == {"total_price","distance_km"} else app.state.default_weights)
        except ValidationError as exc:
            raise HTTPException(422, "Bitte Preis und Entfernung ganzzahlig von 0 bis 100 mit der Summe 100 % eingeben.") from exc
        request_started = monotonic()
        session_id = uuid4().hex
        search_id = search_id or session_id
        folder = memory / "uploads" / session_id
        documents, warnings, staged = [], [], []
        attachments = [item for item in report_attachments(previous) if item["id"] not in removed] if previous else []
        excluded = {item["path"] for item in report_attachments(previous)
                    if item["id"] in removed and item.get("path")} if previous else set()
        used = [{"name": entry["name"], "path": entry["path"]} for entry in app.state.files if entry["name"] in CORE + RUNTIME]
        if previous:
            paths = {item["path"] for item in attachments if item.get("path")}
            used.extend(item for item in previous["used_files"] if item["path"] in paths)
        update_progress(run_id, "PDFs werden ausgewertet" if pdfs else "Vorhandene Belege werden geladen")
        if previous:
            # Refresh older saved evidence when a price note or link was omitted.
            lookup_requested = re.search(r"standort|adresse|anschrift|entfernung|impressum|kilometer", need, re.I)
            for path in paths:
                candidates = [source for source in previous["sources"] if source.get("path") == path
                              and (("EUR/" in source["text"] and not re.search(r"(?:netto|brutto|mwst)",source["text"],re.I))
                                   or (lookup_requested and "PDF-Link:" not in source["text"]))]
                pdf_path = Path(path).resolve()
                if not candidates or not pdf_path.is_relative_to(memory / "uploads"):
                    continue
                try:
                    with pdf_path.open("rb") as stream:
                        refreshed = dict(cached_pdf(stream.read(MAX_PDF_BYTES + 1))[0])
                except (OSError, PDFError):
                    continue
                for source in candidates:
                    updated = refreshed.get(source.get("page"), "")
                    if updated.startswith(source["text"] + "\n"):
                        source["text"] = updated
        for index, upload in enumerate(pdfs or [], 1):
            path = folder / f"{index:02d}.pdf"
            entry, pages, data = inspect_upload(upload)
            if entry["status"] == "ready" and sum(item["status"] == "ready" for item in attachments) >= 5:
                entry.update(status="error", notes=["Maximal fünf aktive PDFs pro Suche."])
            entry["id"] = attachment_id(str(path))
            attachments.append(entry)
            if entry["status"] != "ready":
                continue
            entry["path"] = str(path)
            staged.append((path, data))
            warnings.extend(f"{entry['name']} · {note}" for note in entry["notes"])
            used.append({"name": entry["name"], "path": str(path)})
            for page, text in pages or [(None, "")]:
                documents.append({"kind": "pdf", "title": entry["name"], "path": str(path), "text": text, "page": page})
        pdf_seconds = monotonic()-request_started
        model_client = Harness(harness, model, base_url, api_key)
        LOG.info("Lauf %s mit %s. Quelldateien: %s", session_id, harness, json.dumps(used, ensure_ascii=False))
        try:
            messages = [row["need"] for row in history] + [need]
            report = run_workflow(model_client, app.state.texts, need, documents, web, warnings, selected_weights,
                                  previous=previous, messages=messages, excluded=excluded,
                                  progress=lambda message: update_progress(run_id, message))
        except ModelError as exc:
            raise HTTPException(502, str(exc)) from exc
        if "timings" in report:
            report['timings']['operations']['upload_pdf_preparation']={'seconds':round(pdf_seconds,3),'calls':1}
            report['timings']['total_seconds']=round(monotonic()-request_started,3)
        report.update({
            "session_id": session_id, "created_at": datetime.now(timezone.utc).isoformat(),
            "harness": harness, "model": model_client.resolved_model, "used_files": used, "search_id": search_id,
            "attachments": attachments,
        })
        app.state.validator.validate(report)
        written = []
        try:
            if staged:
                folder.mkdir(parents=True)
            for path, data in staged:
                written.append(path)
                path.write_bytes(data)
            with database(db) as conn:
                conn.execute("INSERT INTO sessions(id, need, harness, model) VALUES (?, ?, ?, ?)",
                             (session_id, need, harness, model_client.resolved_model))
                conn.execute("INSERT INTO reports(session_id, report_json) VALUES (?, ?)",
                             (session_id, json.dumps(report, ensure_ascii=False, allow_nan=False)))
                if len(search_history(conn, search_id)) != (len(history) or 1) or removed_ids(conn, search_id) != removed:
                    raise HTTPException(409, "Die Suche wurde inzwischen geändert. Bitte erneut öffnen.")
                conn.execute("INSERT INTO search_turns VALUES (?, ?, ?)", (search_id, len(history), session_id))
        except Exception:
            for path in written:
                path.unlink(missing_ok=True)
            if folder.is_dir():
                folder.rmdir()
            raise
        return report

    @app.get("/api/agent/searches")
    def searches():
        with database(db) as conn:
            rows = conn.execute("""
                SELECT s.id AS search_id, s.need FROM sessions s JOIN reports r ON r.session_id=s.id
                LEFT JOIN search_turns t ON t.session_id=s.id WHERE COALESCE(t.turn, 0)=0
                ORDER BY COALESCE((SELECT MAX(s2.rowid) FROM search_turns t2
                    JOIN sessions s2 ON s2.id=t2.session_id WHERE t2.search_id=s.id), s.rowid) DESC
            """)
            return [dict(row) | {"need": row["need"][:120]} for row in rows]

    @app.get("/api/agent/searches/{search_id}")
    def search(search_id: str):
        with database(db) as conn:
            rows = search_history(conn, search_id)
            if not rows or rows[0]["id"] != search_id or conn.execute(
                "SELECT 1 FROM search_turns WHERE session_id=? AND turn>0", (search_id,)
            ).fetchone():
                raise HTTPException(404, "Suche nicht gefunden.")
            removed = removed_ids(conn, search_id)
        attachments = [item for item in report_attachments(json.loads(rows[-1]["report_json"])) if item["id"] not in removed]
        return {"search_id": search_id, "attachments": attachments, "turns": [
            {"need": row["need"], "report": json.loads(row["report_json"])} for row in rows
        ]}

    @app.get("/api/agent/reports")
    def reports():
        with database(db) as conn:
            rows = conn.execute("SELECT id, created_at, need, model FROM sessions ORDER BY rowid DESC LIMIT 40")
            return [{"session_id": row["id"], "created_at": row["created_at"], "need": row["need"][:120],
                     "model": row["model"]} for row in rows]

    @app.get("/api/agent/reports/{session_id}")
    def report(session_id: str):
        with database(db) as conn:
            row = conn.execute("SELECT report_json FROM reports WHERE session_id = ?", (session_id,)).fetchone()
        if row is None:
            raise HTTPException(404, "Bericht nicht gefunden.")
        return json.loads(row["report_json"])

    @app.post("/api/agent/feedback", status_code=201)
    def feedback(body: Feedback):
        with database(db) as conn:
            if not conn.execute("SELECT 1 FROM reports WHERE session_id = ?", (body.session_id,)).fetchone():
                raise HTTPException(404, "Bericht nicht gefunden.")
            conn.execute("INSERT INTO feedback_log(session_id, rating, note) VALUES (?, ?, ?)",
                         (body.session_id, body.rating, body.note.strip()))
        return {"saved": True}

    return app


app = create_app()
