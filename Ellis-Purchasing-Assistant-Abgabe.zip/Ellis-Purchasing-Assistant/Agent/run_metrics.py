"""Request-local timings. Nested operation times overlap and are labelled as such."""
from contextvars import ContextVar
from functools import wraps
from time import perf_counter

active = ContextVar("ellis_run_measurements", default=None)


def timed(label):
    def decorate(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            started = perf_counter()
            try:
                return function(*args, **kwargs)
            finally:
                collector = active.get()
                if collector is not None:
                    item = collector.setdefault(label, {"seconds":0.0,"calls":0})
                    item["seconds"] += perf_counter() - started
                    item["calls"] += 1
        return wrapped
    return decorate


def measured_run(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        operations = {}
        token = active.set(operations)
        started = perf_counter()
        try:
            result = function(*args, **kwargs)
            result["timings"] = {"total_seconds":round(perf_counter()-started,3),
                "operations":{key:{"seconds":round(item["seconds"],3),"calls":item["calls"]}
                              for key,item in operations.items()},
                "model_requests":operations.get("model",{}).get("requests",[]),
                "note":"Teilzeiten sind verschachtelt und dürfen nicht addiert werden."}
            return result
        finally:
            active.reset(token)
    return wrapped
