param([switch]$Restart, [switch]$OnlineRouting)

$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not $env:TRINITY_GEOCODER_URL) {
    $env:TRINITY_GEOCODER_URL = 'https://photon.komoot.io/api'
    if (-not $env:TRINITY_GEOCODER_FALLBACK_URL) {
        $env:TRINITY_GEOCODER_FALLBACK_URL = 'https://nominatim.openstreetmap.org'
    }
}
if (-not $env:TRINITY_ROUTER_URL) { $env:TRINITY_ROUTER_URL = 'https://router.project-osrm.org' }
if (-not $env:TRINITY_GEOCODE_CACHE) { $env:TRINITY_GEOCODE_CACHE = Join-Path $PSScriptRoot 'memory\geocodes.sqlite3' }
if (-not $env:TRINITY_CODEX_EXE -and -not (Get-Command codex -CommandType Application -ErrorAction SilentlyContinue)) {
    $codexBin = Join-Path $env:LOCALAPPDATA 'OpenAI\Codex\bin'
    $desktopCodex = Get-ChildItem -LiteralPath $codexBin -Filter codex.exe -File -Recurse -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($desktopCodex) {
        $env:TRINITY_CODEX_EXE = $desktopCodex.FullName
    } elseif (Get-Command Get-AppxPackage -ErrorAction SilentlyContinue) {
        $package = Get-AppxPackage -Name OpenAI.Codex -ErrorAction SilentlyContinue |
            Sort-Object Version -Descending | Select-Object -First 1
        if ($package.InstallLocation) {
            $packageCli = Join-Path $package.InstallLocation 'app\resources\codex.exe'
            if (Test-Path -LiteralPath $packageCli -PathType Leaf) {
                $env:TRINITY_CODEX_EXE = $packageCli
            }
        }
    }
}
$agentVenv = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $agentVenv)) {
    $agentBundledPython = Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
    if (Test-Path -LiteralPath $agentBundledPython) {
        & $agentBundledPython -m venv .venv
    } elseif (Get-Command py -ErrorAction SilentlyContinue) {
        & py -3 -m venv .venv
    } else {
        & python -m venv .venv
    }
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.11+ installieren und erneut starten.' }
}
& $agentVenv -c 'from importlib.util import find_spec; import sys; sys.exit(any(find_spec(name) is None for name in (''fastapi'', ''uvicorn'', ''httpx'', ''yaml'', ''jsonschema'', ''pypdf'', ''fontTools'', ''bs4'', ''python_multipart'', ''truststore'')))'
if ($LASTEXITCODE -ne 0) {
    & $agentVenv -m pip install -r requirements.txt
    if ($LASTEXITCODE -ne 0) { throw 'Installation der Python-Abhängigkeiten fehlgeschlagen.' }
}
$listener = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue |
    Where-Object LocalAddress -in @('127.0.0.1', '0.0.0.0', '::') | Select-Object -First 1
if ($listener) {
    if (-not $Restart) { throw 'Port 8765 ist belegt. Verwende -Restart, um den Ellis-Server dieses Projekts neu zu starten.' }
    $activeEllis = Invoke-RestMethod -Uri 'http://127.0.0.1:8765/api/agent/files' -TimeoutSec 8
    $activeServer = $activeEllis.files | Where-Object name -eq 'server.py' | Select-Object -First 1
    $listenerProcess = Get-CimInstance Win32_Process -Filter ('ProcessId=' + $listener.OwningProcess)
    if ($activeServer.path -ine (Join-Path $PSScriptRoot 'server.py') -or
        $listenerProcess.CommandLine -notmatch 'uvicorn\s+server:app\s+--host\s+127\.0\.0\.1\s+--port\s+8765') {
        throw 'Port 8765 ist durch einen anderen oder nicht eindeutig zugeordneten Prozess belegt.'
    }
    Stop-Process -Id $listener.OwningProcess -ErrorAction Stop
    for ($attempt = 0; $attempt -lt 20; $attempt++) {
        if (-not (Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue)) { break }
        Start-Sleep -Milliseconds 100
    }
}
& $agentVenv -m uvicorn server:app --host 127.0.0.1 --port 8765
exit $LASTEXITCODE
