CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    need TEXT NOT NULL,
    harness TEXT NOT NULL,
    model TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS reports (
    session_id TEXT PRIMARY KEY REFERENCES sessions(id),
    report_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS feedback_log (
    id INTEGER PRIMARY KEY,
    session_id TEXT NOT NULL REFERENCES reports(session_id),
    rating INTEGER NOT NULL CHECK (rating IN (-1, 1)),
    note TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS search_turns (
    search_id TEXT NOT NULL REFERENCES reports(session_id),
    turn INTEGER NOT NULL,
    session_id TEXT NOT NULL UNIQUE REFERENCES reports(session_id),
    PRIMARY KEY(search_id, turn)
);
CREATE TABLE IF NOT EXISTS removed_pdfs (
    search_id TEXT NOT NULL REFERENCES reports(session_id),
    attachment_id TEXT NOT NULL,
    PRIMARY KEY(search_id, attachment_id)
);
