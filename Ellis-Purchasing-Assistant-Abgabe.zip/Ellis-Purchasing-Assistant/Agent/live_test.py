"""Repeatable live smoke test with synthetic offers and optional real web research."""
import argparse
import json
from tempfile import TemporaryDirectory

import httpx
from fastapi.testclient import TestClient

from server import create_app

NEED = (
    "Position Schrauben (Befestigungstechnik): 100 Stück nach Berlin. "
    "Muss: Werkstoff exakt A2. Soll-Qualitätsmerkmal: Verpackung exakt Karton. "
    "Position Versandkartons (Verpackung): 200 Stück nach Potsdam. "
    "Muss: Material exakt Wellpappe. Soll-Qualitätsmerkmal: Recyclinganteil mindestens 80 %. "
    "Die angehängten Angebote sind fiktive Testdaten. Bitte alle passenden Angebote prüfen. "
    "Für beide Positionen sind alle hier genannten Anforderungen vollständig. Weitere Maße und Toleranzen sind frei wählbar."
)
PAGES = [
    [
        "Testwerk Nord, Produkt NS-100 (Schrauben). Werkstoff A2. Verpackung Karton.",
        "100 Stück nach Berlin: Gesamtpreis netto 50,00 EUR inkl. aller Nebenkosten.",
        "Lieferzeit nach Berlin: 4 Kalendertage. Straßenentfernung nach Berlin: 80 km.",
    ],
    [
        "Testwerk Süd, Produkt SS-100 (Schrauben). Werkstoff A2. Verpackung Kunststoff.",
        "100 Stück nach Berlin: Gesamtpreis netto 60,00 EUR inkl. aller Nebenkosten.",
        "Lieferzeit nach Berlin: 2 Kalendertage. Straßenentfernung nach Berlin: 50 km.",
    ],
    [
        "Testwerk West, Produkt WS-100 (Schrauben). Werkstoff C1. Verpackung Karton.",
        "100 Stück nach Berlin: Gesamtpreis netto 30,00 EUR inkl. aller Nebenkosten.",
        "Lieferzeit nach Berlin: 1 Kalendertag. Straßenentfernung nach Berlin: 30 km.",
    ],
    [
        "Testwerk Ost, Produkt OS-100 (Schrauben). Werkstoff A2. Verpackung Karton.",
        "100 Stück nach Berlin: Gesamtpreis netto 35,00 EUR inkl. aller Nebenkosten.",
        "Straßenentfernung nach Berlin: 55 km. Lieferzeit auf Anfrage.",
    ],
    [
        "Testwerk Pack, Produkt VP-200 (Versandkartons). Material Wellpappe. Recyclinganteil 85 %.",
        "200 Stück nach Potsdam: Gesamtpreis netto 90,00 EUR inkl. aller Nebenkosten.",
        "Lieferzeit nach Potsdam: 5 Kalendertage. Straßenentfernung nach Potsdam: 72 km.",
    ],
]
PARTIAL_NEED = (
    "Aluminium EN AW-5754 (50 Stück, Lieferort Köln). Muss: Legierung exakt EN AW-5754. "
    "Maße und Toleranz sind noch offen. "
    "SPAX-Schrauben (1.000 Stück). Muss: Marke exakt SPAX. Lieferort noch offen. "
    "Die angebotenen Schraubenmaße sind für diesen Vergleich frei wählbar. "
    "Die angehängten Angebote sind fiktive Testdaten."
)
PARTIAL_PAGES = [
    [
        "Testwerk Rhein, Produkt AL-R50. Legierung EN AW-5754. Länge 100 mm. Stärke 2 mm.",
        "50 Stück: Warenpreis netto 120,00 EUR ohne Versand.",
    ],
    [
        "Testwerk Ruhr, Produkt AL-U50. Legierung EN AW-5754. Länge 200 mm. Stärke 3 mm.",
        "50 Stück: Warenpreis netto 150,00 EUR ohne Versand.",
    ],
    [
        "Testwerk Nord, Produkt SPAX N-1000. Marke SPAX.",
        "1000 Stück: Warenpreis netto 80,00 EUR ohne Versand.",
    ],
    [
        "Testwerk Süd, Produkt SPAX S-1000. Marke SPAX.",
        "1.000 Stück: Warenpreis netto 100,00 EUR ohne Versand.",
    ],
]


def example_pdf(pages=PAGES):
    """Create a small, searchable fixture in memory using PDF's standard WinAnsi font."""
    kids = " ".join(f"{4 + index * 2} 0 R" for index in range(len(pages)))
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        f"<< /Type /Pages /Kids [{kids}] /Count {len(pages)} >>".encode(),
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
    ]
    for index, lines in enumerate(pages):
        objects.append(
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 600 780] /Contents {5 + index * 2} 0 R "
            "/Resources << /Font << /F1 3 0 R >> >> >>".encode()
        )
        escaped = [line.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)") for line in lines]
        stream = ("BT /F1 11 Tf 40 730 Td 16 TL " + " T* ".join(f"({line}) Tj" for line in escaped) + " ET").encode("cp1252")
        objects.append(f"<< /Length {len(stream)} >>\nstream\n".encode() + stream + b"\nendstream")
    data = b"%PDF-1.4\n"
    offsets = []
    for index, obj in enumerate(objects, 1):
        offsets.append(len(data))
        data += f"{index} 0 obj\n".encode() + obj + b"\nendobj\n"
    xref = len(data)
    entries = "".join(f"{offset:010} 00000 n \n" for offset in offsets)
    return data + (
        f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n{entries}"
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n"
    ).encode()


def verify_live(client, web, model):
    files = client.get("/api/agent/files").json()
    assert files["codex_status"] == "ready", files["codex_message"]
    assert any(entry["name"] == "memory/migrations/001-initial.sql" for entry in files["files"])
    response = client.post("/api/agent/run", data={"need": NEED, "web": str(web).lower(), "model": model},
                           files=[("pdfs", ("Testangebote.pdf", example_pdf(), "application/pdf"))])
    response.raise_for_status()
    report = response.json()
    rows = {row["product"]: row for position in report["positions"] for row in position["offers"]}
    summary = {
        "model": report["model"],
        "positions": [position["name"] for position in report["positions"]],
        "offers": {key: [row["status"], row["score"]] for key, row in rows.items()},
        "pdf_pages": sum(source["kind"] == "pdf" for source in report["sources"]),
        "search_results": sum(source["kind"] == "search" for source in report["sources"]),
        "web_sources": sum(source["kind"] in {"web", "web_pdf"} for source in report["sources"]),
        "queries": [query for position in report["positions"] for query in position["queries"]],
        "questions": report["questions"] + [question for position in report["positions"] for question in position["questions"]],
        "warnings": report["warnings"],
    }
    print(json.dumps(summary, ensure_ascii=True, indent=2), flush=True)
    assert len(report["positions"]) == 2
    assert summary["pdf_pages"] == 5
    assert rows["NS-100"]["status"] == "geeignet" and rows["NS-100"]["score"] == 68.5
    assert rows["SS-100"]["status"] == "geeignet" and rows["SS-100"]["score"] == 66.67
    assert rows["WS-100"]["status"] == "abweichend" and rows["WS-100"]["score"] is None
    assert rows["OS-100"]["status"] == "geeignet" and rows["OS-100"]["score"] == 98.18
    assert rows["VP-200"]["score"] == 100
    if web:
        assert len(summary["queries"]) >= 3, "Gezielte Nachweisrecherche fehlt."
        assert summary["search_results"] > 0, "Keine tatsächlichen Webtreffer."
        assert summary["web_sources"] > 0, "Keine tatsächliche Webquelle abgerufen."
    session_id = report["session_id"]
    assert client.get(f"/api/agent/reports/{session_id}").json() == report
    assert client.post("/api/agent/feedback", json={"session_id": session_id, "rating": 1,
                                                   "note": "Live-Smoke-Test"}).status_code == 201
    print("OK: Modell, PDF, Kriterien, Rangfolge, Bericht und Feedback.", flush=True)


def verify_partial(client, web, model):
    files = client.get("/api/agent/files").json()
    assert files["codex_status"] == "ready", files["codex_message"]
    response = client.post("/api/agent/run", data={"need": PARTIAL_NEED, "web": str(web).lower(), "model": model},
                           files=[("pdfs", ("Teilangebote.pdf", example_pdf(PARTIAL_PAGES), "application/pdf"))])
    response.raise_for_status()
    report = response.json()
    summary = {
        "codex": files["codex_status"], "model": report["model"], "session_id": report["session_id"],
        "web_sources": sum(source["kind"] in {"web", "web_pdf"} for source in report["sources"]),
        "search_results": sum(source["kind"] == "search" for source in report["sources"]),
        "positions": [],
    }
    for position in report["positions"]:
        summary["positions"].append({
            "name": position["name"], "quantity": position["quantity"], "destination": position["destination"],
            "questions": position["questions"], "recommendation": position["recommendation"],
            "queries": position["queries"], "offer_count": len(position["offers"]),
            "offers": [{
                "product": row["product"], "status": row["status"], "net_price": row["metrics"].get("net_price"),
                "comparison": row["partial_score"], "specs": row["specs"],
            } for row in position["offers"] if row["product"] in {"AL-R50", "AL-U50", "SPAX N-1000", "SPAX S-1000"}],
        })
    print(json.dumps(summary, ensure_ascii=True, indent=2), flush=True)
    assert len(report["positions"]) == 2
    aluminum = next(position for position in report["positions"] if position["quantity"] == "50")
    spax = next(position for position in report["positions"] if position["quantity"] in {"1.000", "1000"})
    assert aluminum["destination"] == "Köln"
    questions = " ".join(aluminum["questions"]).casefold()
    assert "maß" in " ".join(aluminum["questions"]).lower() and "toleranz" in questions
    assert not spax["destination"]
    assert sum("geliefert" in question for question in spax["questions"]) == 1
    assert not any("menge" in question.casefold() or "stückzahl" in question.casefold() for question in spax["questions"])
    for position, expected in [(aluminum, [120, 150]), (spax, [80, 100])]:
        rows = position["offers"][:2]
        assert [row["metrics"]["net_price"]["value"] for row in rows] == expected
        assert all(row["status"] == "offen" and row["score"] is None for row in rows)
        assert all(row["partial_score"]["basis"] == {"net_price": 80} for row in rows)
        assert position["recommendation"].startswith("Vorläufige Empfehlung:")
    assert any(row["specs"] for row in aluminum["offers"])
    assert all({"total_price", "distance_km"}.isdisjoint(row["metrics"]) and "Versandkosten" in row["missing"]
               for row in spax["offers"])
    if web:
        assert all(position["queries"] for position in report["positions"])
        assert summary["search_results"] and summary["web_sources"]
    print("OK: Unvollständiger Bedarf, belegte Teilvergleiche und getrennte Rückfragen.", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--web", action="store_true", help="Zusätzlich mit tatsächlicher Lieferantenrecherche testen.")
    parser.add_argument("--model", default="", help="Optionales Codex-Modell.")
    parser.add_argument("--partial", action="store_true", help="Aluminium und SPAX bei unvollständigem Bedarf prüfen.")
    parser.add_argument("--url", help="Ein bereits gestartetes lokales Backend testen.")
    args = parser.parse_args()
    verify = verify_partial if args.partial else verify_live
    if args.url:
        with httpx.Client(base_url=args.url, timeout=550, trust_env=False) as client:
            verify(client, args.web, args.model)
    else:
        with TemporaryDirectory(prefix="trinity-live-") as memory, TestClient(create_app(memory)) as client:
            verify(client, args.web, args.model)
