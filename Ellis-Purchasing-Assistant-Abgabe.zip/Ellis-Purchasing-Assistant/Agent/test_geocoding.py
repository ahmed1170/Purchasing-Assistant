from concurrent.futures import ThreadPoolExecutor
from unittest.mock import patch

import httpx
import pytest

from geocoding import GeocodingError, mapped_with_scope, resolution_scope, resolve
from research import air_distance, route_distance


def place(name,lat,lon,kind="city",**properties):
    return {"names":[name],"point":(lat,lon),"kind":kind,"street":"","house":"","properties":properties}


def test_postcode_city_and_duplicate_locality_objects():
    candidates = [place("Teststadt",48.77,9.17,countrycode="DE",state="West"),
                  place("Teststadt",48.79,9.18,"administrative",countrycode="DE",state="West"),
                  place("Teststadt",48.8,9.19,"postcode",postcode="70188",countrycode="DE",state="West")]
    with patch("geocoding.request_candidates",return_value=(candidates,"https://places.example/result")):
        assert resolve("https://both.example/api","Teststadt")[2] == "city"
        assert resolve("https://both.example/api","70188 Teststadt")[0] == (48.8,9.19)


def test_international_address_and_fallback_to_town_and_country():
    city = place("Wien",48.2,16.37,countrycode="at",country="Österreich")
    address = dict(city,point=(48.19,16.36),street="Musterstraße",house="14",kind="house",
                   properties=city["properties"] | {"city":"Wien","postcode":"1010"})
    with patch("geocoding.request_candidates",return_value=([address],"address proof")):
        assert resolve("https://address.example/api","Musterstrasse 14, 1010 Wien, Austria") == ((48.19,16.36),"address proof","address")
    with patch("geocoding.request_candidates",side_effect=lambda _,query: ([city] if query=="Wien, Austria" else [],"city proof")):
        assert resolve("https://fallback.example/api","Musterstrasse 14, 1010 Wien, Austria") == ((48.2,16.37),"city proof","city")


def test_same_name_requires_region_when_country_is_insufficient(monkeypatch):
    monkeypatch.setenv("TRINITY_DEFAULT_COUNTRY","DE")
    rows = [place("Neustadt",49.3,8.1,state="West",country="Deutschland",countrycode="de"),
            place("Neustadt",52.5,9.4,state="Nord",country="Deutschland",countrycode="de")]
    with patch("geocoding.request_candidates",return_value=(rows,"source")):
        with pytest.raises(GeocodingError,match="Mehrere Orte"):
            resolve("https://ambiguous.example/api","Neustadt")
        assert resolve("https://ambiguous.example/api","Neustadt, Nord, Deutschland")[0]==(52.5,9.4)


def test_searching_for_a_city_does_not_match_outlying_boroughs_by_parent_name():
    from geocoding import select_location
    city = place("Teststadt",52.5,13.4,countrycode="DE")
    outlying = place("Westrand",52.5,13.1,"district",countrycode="DE")
    outlying["names"].append("Teststadt")
    assert select_location([city,outlying],"Teststadt") == (((52.5,13.4),"city"),False)
    assert select_location([city,outlying],"Westrand") == (((52.5,13.1),"city"),False)


def test_qualified_city_retains_country_when_shorter_lookup_is_used():
    intended = place("Nordstadt",53.2,6.5,countrycode="NL",country="Nederland",state="Nordstadt")
    foreign = place("Nordstadt",52.4,11.5,countrycode="DE",country="Deutschland")
    with patch("geocoding.request_candidates",side_effect=lambda _,query:
               ([foreign,intended] if query == "Nordstadt" else [],"source")):
        assert resolve("https://country.example/api","Nordstadt, Niederlande")[0] == (53.2,6.5)


def test_umlaut_and_default_country_only_resolve_documented_candidates(monkeypatch):
    monkeypatch.setenv("TRINITY_DEFAULT_COUNTRY","DE")
    rows = [place("Münster",51.96,7.63,countrycode="de"),place("Munster",48.04,7.13,countrycode="fr",country="France")]
    with patch("geocoding.request_candidates",return_value=(rows,"source")):
        assert resolve("https://umlaut.example/api","Muenster")[0]==(51.96,7.63)
        assert resolve("https://umlaut.example/api","Munster, France")[0]==(48.04,7.13)


def test_failover_single_target_resolution_and_persistent_success(tmp_path,monkeypatch):
    monkeypatch.setenv("TRINITY_GEOCODE_CACHE",str(tmp_path/"geocodes.sqlite3"))
    monkeypatch.setenv("TRINITY_GEOCODER_FALLBACK_URL","https://secondary.example")
    row = place("Lyon",45.76,4.84,countrycode="fr")
    def source(base,query):
        if "primary" in base:
            raise httpx.ConnectTimeout("unreachable")
        return [row],"alternate proof"
    @resolution_scope
    def run():
        with ThreadPoolExecutor(max_workers=4) as pool:
            return list(mapped_with_scope(pool,lambda _:resolve("https://primary.example/api","Lyon"),range(5)))
    with patch("geocoding.request_candidates",side_effect=source) as fetch:
        assert run() == [((45.76,4.84),"alternate proof","city")]*5
        assert fetch.call_count == 2
    with patch("geocoding._cache",{}), patch("geocoding.request_candidates",side_effect=AssertionError("persisted")):
        assert resolve("https://primary.example/api","Lyon")[0] == (45.76,4.84)


def test_failure_not_cached_across_runs_and_changed_target_gets_new_coords(monkeypatch):
    monkeypatch.delenv("TRINITY_GEOCODER_FALLBACK_URL",raising=False)
    primary = "https://recover.example/api"
    @resolution_scope
    def search(city):
        return resolve(primary,city)
    with patch("geocoding.request_candidates",side_effect=httpx.ConnectTimeout("temporary")):
        with pytest.raises(GeocodingError) as failed:
            search("Graz")
        assert failed.value.kind == "service"
    cities = {"Graz":place("Graz",47.07,15.44),"Linz":place("Linz",48.3,14.29)}
    with patch("geocoding.request_candidates",side_effect=lambda _,city:([cities[city]],"source")) as request:
        assert search("Graz")[0] != search("Linz")[0]
        assert request.call_count == 2


def test_router_failure_does_not_prevent_haversine(monkeypatch):
    monkeypatch.setenv("TRINITY_GEOCODER_URL","https://air.example/api")
    target = place("Brno",49.2,16.6)
    origin = place("Praha",50.08,14.42)
    @resolution_scope
    def run():
        assert route_distance("Praha","Brno") is None
        return air_distance("Praha","Brno")
    with patch("geocoding.request_candidates",side_effect=lambda _,q:([target if q=="Brno" else origin],"source")) as lookups, \
         patch("research.get_route",side_effect=httpx.ReadTimeout("router failed")):
        km,proof,_ = run()
        assert 180 < km < 200
        assert "Zielauflösung: city" in proof
        assert lookups.call_count == 2
