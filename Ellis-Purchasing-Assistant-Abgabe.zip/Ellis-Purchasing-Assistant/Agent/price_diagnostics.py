"""Explain missing prices using actual per-variant retrieval evidence."""
import re
from shop_evidence import canonical, conflicts_for_source
from purchasing import normalize


def diagnose_prices(rows, sources, warnings=()):
    source_map={source['id']:source for source in sources}
    for row in rows:
        identity=source_map.get(row['identity']['source_id'],{})
        target=canonical(identity.get('product_url') or identity.get('url',''))
        relevant=[source for source in sources if source.get('kind')=='web' and
                  canonical(source.get('product_url') or source.get('url',''))==target]
        records=[(source,record) for source in relevant for record in source.get('shop_products',[])
                 if canonical(record['product_url'])==target and normalize(record["name"]) == normalize(row["product"])]
        configured = any(re.search(
            r"zuschnitt konfigurieren|preis\w* (?:werden|wird).{0,95}im warenkorb|"
            r"länge.{0,60}(?:min\.|min:|mindestens).{0,130}breite|"
            r"(?:length|width).{0,60}(?:minimum|min:).{0,130}(?:width|length)",
            source["text"],re.I | re.S) for source in relevant)
        conflicts=conflicts_for_source(row['identity']['source_id'],source_map)
        if conflicts:
            row['reasons']['material_price']='Variantenbezug unklar: '+' '.join(dict.fromkeys(conflicts))
        elif row.get('listed_price'):
            listed=row['listed_price']
            source=source_map.get(listed['evidence']['source_id'],{})
            listed.update(source_url=source.get('url',''),retrieved_at=source.get('retrieved_at',''),
                          evidence_kind=next((r['kind'] for r in source.get('shop_products',[]) if r['name']==row['product']),'Web-/Dokumentbeleg'),
                          product_url=source.get('product_url') or source.get('url',''))
            if configured and not listed.get("goods_value"):
                row['reasons']['material_price']='Preis für die gewünschte Konfiguration nicht belegt. Der ausgewiesene Wert kann eine Voreinstellung oder ein Flächenpreis sein.'
            elif not listed.get('price_basis'):
                row['reasons']['material_price']='Variantenbezug oder Preisbezugsmenge unklar; ausgewiesener Preis bleibt sichtbar.'
            elif listed.get('goods_value') is None:
                row['reasons']['material_price']='Bedarfsmenge oder passende Mengeneinheit für die Hochrechnung fehlt.'
            elif listed.get('tax') == 'offen':
                row['reasons']['material_price']='Warenwert berechnet. Für Preispunkte fehlt der Beleg, ob der Preis netto oder brutto ist.'
        elif identity.get("kind") == "pdf" and not target:
            row['reasons']['material_price']='Im PDF ist für diesen Artikel kein bewertbarer Preis belegt.'
        elif records and all(record.get("price_from") for _,record in records):
            row['reasons']['material_price']='Öffentlicher Ab-Preis. Für den Warenwert wird der Preis einer konkreten Variante benötigt.'
        elif configured:
            row['reasons']['material_price']='Preis für die gewünschte Konfiguration nicht belegt. Maße im Anbieter-Konfigurator prüfen.'
        elif any(record.get('price') for _,record in records):
            row['reasons']['material_price']='Vorhandener Preis bei der Verarbeitung verloren gegangen: strukturierter Variantenpreis im Quellenbeleg vorhanden.'
        elif not relevant and any(identity.get('url','!') in warning and re.search(r'fehlgeschlagen|Zeitlimit',warning,re.I) for warning in warnings):
            row['reasons']['material_price']='Abruf fehlgeschlagen: Produktseite konnte nicht als Textbeleg geladen werden.'
        elif any(re.search(r'\d+[,.]\d{2}\s*(?:EUR|€)',source['text']) for source in relevant):
            row['reasons']['material_price']='Variantenbezug unklar: Preis im Seitentext lässt sich der konkreten Variante nicht sicher zuordnen.'
        else:
            row['reasons']['material_price']='Kein Preis veröffentlicht im abgerufenen Produkttext; ein nur dynamisch geladener Preis ist damit nicht ausgeschlossen.'
        if row['reasons'].get('material_price'):
            row['reasons']['total_price']=row['reasons']['material_price']
