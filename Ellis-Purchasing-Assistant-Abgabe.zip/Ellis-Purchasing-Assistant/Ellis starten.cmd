@echo off
setlocal
set "ELLIS_START=%~dp0Agent\start.ps1"
if not exist "%ELLIS_START%" (
  echo Bitte die ZIP vollstaendig entpacken und Ellis starten.cmd erneut ausfuehren.
  pause
  exit /b 1
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%ELLIS_START%" %*
set "ELLIS_EXIT=%ERRORLEVEL%"
if not "%ELLIS_EXIT%"=="0" (
  echo Ellis konnte nicht gestartet werden. Siehe Meldung oben.
  pause
)
exit /b %ELLIS_EXIT%
